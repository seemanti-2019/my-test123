import {TEST, GET_FILTER_OPTIONS, GET_FILTER_WIDGET, TRACIBILITY_DATA, GET_MY_VOLUME_DATA, GET_NEWS, GET_DOWNLOADS, GET_GRIEVANCES_LOCATION,
  GET_RISK_PER_MILL, GET_SUPPLY_CHAIN_WIDGET, GET_COUNTRY_VOLUME, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST,
  GET_GRIEVANCES_FILTER_OPTIONS, GET_GRIEVANCES_ORDER, GET_GRIEVANCE_DETAIL, GET_TIMELINE_TOP, GET_TIMELINE_BOTTOM,
  NAV_TAB, GET_NDPE_POLICY_DATA, GET_REFINERIES_COUNT, GET_SUPPLY_CHECKER_SEARCH_LIST, GET_URL,GET_FOOTPRINT_DATA,DRAW_FOOTPRINT_FLOW, GET_WORLD_MAP, 
  GET_GRIEVANCES_STATUS_COUNT, GET_CO_INVEST_DATA} from './types';
import Axios from 'axios';
import { loadModules } from 'esri-loader';
//import { feature } from "topojson-client"

let userFilterSelections=[];
let userAppliedFilters = {};
let selectedObj={};
let globalSelections = {};
let authToken = '';
let totallMillCount = 0;
let grievancesSortOrder = 'desc';
let grievancesList = [];
let timelineTop = [];
let productGrpParams='';
let productGrpCertifications='';
let productGrpDestinations='';
let clearFilter = false;
let initialGrivancesList = [];
let initialSearchItems = [];
let paramObj = {year:'2019',quarter:'Q2',product_group:productGrpParams,product_certification:productGrpCertifications,destination_market:productGrpDestinations}

export const changeName = () => {
    return (dispatch) => {
      dispatch({ type: TEST, payload: 'World' });
    };
  };

export const getFiltersOptions = () => {
  return (dispatch) => {
    let results = {
      product_group:[{name:'Palm Oil', param:'Palm', checked:false},{name:'Palm Kernel Oil',param:'Kernel' ,checked:false}], 
      rspo:[{name:'Mass Balance', param:'MB', checked:false},{name:'Segregated', param: 'SG', checked:false},{name:'Classic', param:'Classic', checked:false},{name:'ISCC', param:'ISCC',checked:false}], 
      year_quater:[{year:'2019', quater:'Q2'}], 
      destination:[{name:'Europe', param:'EUROPE', checked:false},{name:'Brazil', param:'BRAZIL', checked:false}], 
    };
    
    if((Object.keys(userAppliedFilters).length === 0 && userAppliedFilters.constructor === Object)){
      paramObj.product_group = '';
      paramObj.product_certification = '';
      paramObj.destination_market = '';
    }else{
      productGrpParams='';
      productGrpCertifications='';
      productGrpDestinations='';
      Object.keys(userAppliedFilters).map(key=>{
        userAppliedFilters[key].map(item=>{
          if((key === 'product_group') && (item.checked === true)){
            productGrpParams += item.param+',';
          }else if((key === 'rspo') && (item.checked === true)){
            productGrpCertifications += item.param+',';
          }else if((key === 'destination') && (item.checked === true)){
            productGrpDestinations += item.param+',';
          }
        })
      })
      paramObj.product_group = productGrpParams;
      paramObj.product_certification = productGrpCertifications;
      paramObj.destination_market = productGrpDestinations;

      results = JSON.parse(JSON.stringify(userAppliedFilters));
    }

    if(!userFilterSelections){
      userFilterSelections=[];
    }
    
    dispatch({ type: GET_FILTER_OPTIONS, payload: results });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
  };
};

export const updateUserOptions = (data, selection, value, key, param) => {
  return (dispatch) => {
    
    if(Object.keys(data).includes(key)){
      data[key].map((item) =>{
          if(item.name === selection){
              item.checked = value
          }
      })
    }

    if(value){
      selectedObj = {};
      selectedObj.key = key;
      selectedObj.selection = selection;
      selectedObj.param = param;
      userFilterSelections.push(selectedObj);
    }else{
      userFilterSelections = userFilterSelections.filter((item) => item.selection !== selection)
    }
    
    globalSelections = JSON.parse(JSON.stringify(data));

    if(userFilterSelections){
      productGrpParams = '';
      productGrpCertifications = '';
      productGrpDestinations = '';

      userFilterSelections.map((item) =>{
        if(item.key === 'product_group'){
          productGrpParams += item.param+',';
        }else if(item.key === 'rspo'){
          productGrpCertifications += item.param+',';
        }else{
          productGrpDestinations += item.param+',';
        }
      })

      paramObj.product_group = productGrpParams;
      paramObj.product_certification = productGrpCertifications;
      paramObj.destination_market = productGrpDestinations;

    }
    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
    dispatch(applyUserSelections(globalSelections));
    dispatch(getSupplyChainWidgetData());
    dispatch(getByCountryVolumes());
    dispatch(getRefineriesCount());
    dispatch(getTracibilityData());
    dispatch(getRiskPerMill());
    dispatch(getNdpe());
    dispatch(getGrievancesSupplierInfo());
    dispatch(getGrievancesLocation());
    dispatch(getGrievancesList());
    dispatch(getGrievancesStatus());
    dispatch(getGrievancesStatusCountData());
  };
};

export const clearUserOptions = (data) => {
  return(dispatch) => {
    Object.keys(data).map(key=>{
      data[key].map(item=>{
        if(item.hasOwnProperty('checked'))
        item.checked = false
      })
    })
    
    clearFilter = true;
    globalSelections = JSON.parse(JSON.stringify(data));
    paramObj.product_group = '';
    paramObj.product_certification = '';
    paramObj.destination_market = '';

    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
}

export const cancelUserOptions = (data) => {
  return(dispatch) => {
    if(Object.keys(userAppliedFilters).length === 0 && userAppliedFilters.constructor === Object){
      Object.keys(data).map(key=>{
        data[key].map(item=>{
          if(item.hasOwnProperty('checked'))
          item.checked = false
        })
      })
      userFilterSelections = [];
      paramObj.product_group = '';
      paramObj.product_certification = '';
      paramObj.destination_market = '';
      globalSelections = JSON.parse(JSON.stringify(data));

      dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    }else{
      let selectionsArr = [];
      Object.keys(userAppliedFilters).map(key=>{
        userAppliedFilters[key].map(item=>{
          userFilterSelections.map((coll => {
            if((item.name === coll.selection) && (item.checked)){
              selectionsArr.push(coll);
            }
          }))
          
        })
      })

      userFilterSelections = selectionsArr;

      userFilterSelections.map((item) =>{
        if(item.key === 'product_group'){
          productGrpParams += item.param+',';
        }else if(item.key === 'rspo'){
          productGrpCertifications += item.param+',';
        }else{
          productGrpDestinations += item.param+',';
        }
      })

      paramObj.product_group = productGrpParams;
      paramObj.product_certification = productGrpCertifications;
      paramObj.destination_market = productGrpDestinations;

      dispatch({ type: GET_FILTER_OPTIONS, payload: userAppliedFilters });
    }
    
    clearFilter = false;
    
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
  }
}

export const applyUserSelections = (data) => {
  return(dispatch) => {

    if(clearFilter){
      userFilterSelections = []
      clearFilter = false;
    }
    
    userAppliedFilters = JSON.parse(JSON.stringify(data));
    dispatch({ type: GET_FILTER_OPTIONS, payload: data });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
    
  }
}

export const editFilters = (data) => {
  return(dispatch) => {
  //    if(userFilterSelections.length === 0){
  //     Object.keys(data).map(key=>{
  //       data[key].map((item=>{
  //         if(item.hasOwnProperty('checked'))
  //         item.checked = true
  //       }))
  //     })

  //     Object.keys(data).map(key=>{
  //       data[key].map((item=>{
  //         let obj = {};
  //         obj.key = key;
  //         obj.selection = item.name;
  //         userFilterSelections.push(obj);
  //       }))
  //     })

      
    
  //   globalSelections = JSON.parse(JSON.stringify(data));
  //   dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
  // }

    if(userFilterSelections.length !== 0){
      userAppliedFilters = JSON.parse(JSON.stringify(data));
    }
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
} 

export const getTracibilityData = (getParms) => {
  return(dispatch) => {
    let queryParam = getParms?paramObj:{};

    const tracibilityURL = GET_URL + "traceability/mills";
    Axios.get(tracibilityURL, { params: queryParam, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {

      if(response.data.hasOwnProperty('Percentage')){
      let obj = {'mills':response.data.Percentage.percentage, 'plantation':48}
      dispatch({ type: TRACIBILITY_DATA, payload: obj });
      }
    })
    .catch(error => {
      console.log(error);
    })
    
  }
} 

export const getMyVolumeData = () => {
  return(dispatch) => {

    const riskPerMillURL = "https://api-dev.dev.dev-cglcloud.com/casceu/spapi/v1/apikey/palmwise/home/volumebyproductgroup?year=2019&quarter=Q2";
     
    Axios.get(riskPerMillURL, { headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
       if(response.data.hasOwnProperty('volume_by_load_country')){
         let filterdCollection = {};
         if(response.data.volume_by_load_country.hasOwnProperty('volume_uom') && response.data.volume_by_load_country.hasOwnProperty('product_classification_volumes')){
            response.data.volume_by_load_country.volume_uom.map((item) =>{
              if(item.product_group === 'Palm'){
                filterdCollection.palmMT = Math.round(item.value);
              }else{
                filterdCollection.kernalMT = Math.round(item.value);
              }
            })
            filterdCollection.productVolumes = response.data.volume_by_load_country.product_classification_volumes;
         }
        dispatch({ type: GET_MY_VOLUME_DATA, payload: filterdCollection });
      }
      })
      .catch(error => {
        console.log(error);
      })   
      }
}


export const getNewsData = () => {
  return(dispatch) => {
    let obj = [{'link':'https://www.cargill.com/2019/cargill-launches-independent-forest-protection-advisory-panel', 'name':'Cargill launches independent forest protection advisory panel'},
                {'link':'https://www.cargill.com/2019/palm-oil-industry-to-jointly-develop-radar-monitoring-technology', 'name':'Palm Oil Industry to Jointly Develop Radar Monitoring Technology to Detect Deforestation'},
                {'link': 'https://www.cargill.com/2019/cargill-supports-indonesian-smallholder-farmers-with-global', 'name':'Cargill supports Indonesian smallholder farmers with global sustainable palm oil certification'}]
    dispatch({ type: GET_NEWS, payload: obj });
  }
} 

export const getDownloadData = () => {
  return(dispatch) => {
    //{'link':'https://www.cargill.com/doc/1432155778288/cargill-palm-mill-list-q3-2019.pdf', 'name':'Cargill’s Mill List'},
    let obj = [
                {'link':'https://www.cargill.com/doc/1432076149492/palm-oil-policy-statement-pdf.pdf', 'name':'Cargill’s Policy on Sustainable Palm Oil'},
                {'link': 'https://www.cargill.com/doc/1432144706116/cargill-2018-palm-report.pdf', 'name':'Cargill Palm Oil Annual Report'}]
    dispatch({ type: GET_DOWNLOADS, payload: obj });
  }
}

export const getGrievancesLocation = () => {
  return (dispatch) => {
    const locationURL = GET_URL + "supplychain/grievanceIdAndCountry";
    Axios.get(locationURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let locationData = response.data;
        dispatch({ type: GET_GRIEVANCES_LOCATION, payload: locationData });
      })
      .catch(error => {
        console.log(error);
      })
  }
}

export const getRiskPerMill = () => {
  return(dispatch) => {
    
    const riskPerMillURL = GET_URL + "performance/riskpermill/";
    Axios.get(riskPerMillURL, { params: paramObj, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
       if(response.data.hasOwnProperty('risk_per_mill')){
        let sortRiskPerMill = response.data.risk_per_mill.sort((val1, val2) => val1.count - val2.count);
        let riskObj = {};
        sortRiskPerMill.map((item) =>{
            if(item.priority === "High"){
              riskObj.high = item.count;
            }else if(item.priority === "Medium"){
              riskObj.medium = item.count;
            }else{
              riskObj.low = item.count;
            }
        })
        
        dispatch({ type: GET_RISK_PER_MILL, payload: riskObj });
      }
    })
    .catch(error => {
      console.log(error);
    })

  }
} 

export const getNdpe = () => {
  return(dispatch) => {
    const ndpeURL = GET_URL + "performance/volume_covered_by_ndpe_policy";
     
    Axios.get(ndpeURL, { params: paramObj, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
       if(response.data.hasOwnProperty('Percentage')){
         dispatch({type: GET_NDPE_POLICY_DATA, payload: response.data.Percentage.percentage.toFixed(2)})
      }
    })
    .catch(error => {
      console.log(error);
    })
  }
}

export const getSupplyChainWidgetData = () => {
  return(dispatch) => {

    const millCountURL = GET_URL + "supplychain/thirdpartymills/count/";
     
    Axios.get(millCountURL, { params: paramObj, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
       if(response.data.hasOwnProperty('Count')){
        dispatch({ type: GET_SUPPLY_CHAIN_WIDGET, payload: response.data.Count})
      }
    })
    .catch(error => {
      console.log(error);
    })
    
  }
}

export const getRefineriesCount = () => {
  return(dispatch) => {
    const refineriesCountURL = GET_URL + "supplychain/thirdpartyrefineries/count/";

    Axios.get(refineriesCountURL, { params: paramObj, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
        if(response.data.hasOwnProperty('Count')){
          dispatch({ type: GET_REFINERIES_COUNT, payload: response.data.Count})
        }
    })
    .catch(error => {
      console.log(error);
    })
  }
}

export const getByCountryVolumes = () => {
  return(dispatch) => {
    const refineriesCountURL = GET_URL + "supplychain/volumebyloadcountry";

    Axios.get(refineriesCountURL, { params: paramObj, headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
        if(response.data.hasOwnProperty('volume_by_load_country')){
          dispatch({ type: GET_COUNTRY_VOLUME, payload: response.data.volume_by_load_country})
        }
    })
    .catch(error => {
      console.log(error);
    })
  }
}

export const getMapData = () => {
  return(dispatch) => {
    fetch("/world-110m.json")
      .then(response => {
        if (response.status !== 200) {
          console.log(`There was a problem: ${response.status}`)
          return
        }
        response.json().then(worlddata => {
          //const worldData = feature({worlddata, worlddata.objects.countries).features})
          //dispatch({ type: GET_WORLD_MAP, payload: worldData});
          //setGeographies(feature(worlddata, worlddata.objects.countries).features)
        })
      })
  }
}

export const getFootPrintData = () => {
  return(dispatch) => {
    const footPrintURL = GET_URL + "home/volumebydestination"

    Axios.get(footPrintURL, { headers : { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' }})
    .then( response => {
        if(response.data.hasOwnProperty('volume_by_load_country')){
          dispatch({ type: GET_FOOTPRINT_DATA, payload: response.data.volume_by_load_country})
          dispatch({type: DRAW_FOOTPRINT_FLOW, payload: response.data.volume_by_load_country})
        }
    })
    .catch(error => {
      console.log(error);
    })

  }
}

export const updateFootPrintFlow = (selection, listOfSelctions) => {
  return(dispatch) => {
    let filterdFlow =[];
    if(selection !== ''){
      filterdFlow = listOfSelctions.filter( (item) => {
        if((item.load_country === selection) || (item.destination_location === selection))
        {
          return item;
        }
      })
    }else{
      filterdFlow = listOfSelctions
    }
    dispatch({type: DRAW_FOOTPRINT_FLOW, payload: filterdFlow})
  }
}

export const getGrievancesSupplierInfo = () => {
  return (dispatch) => {
    const supplierInfoURL = GET_URL + "supplychain/getCountOfDirectSupplier";
    Axios.get(supplierInfoURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let linkWithSuppliers = response.data;
        dispatch({ type: GET_GRIEVANCES_SUPPLIER_INFO, payload: linkWithSuppliers });
      })
      .catch(error => {
        console.log(error);
      })
  }
} 

export const getGrievancesStatus = () => {
  return (dispatch) => {
    const grievanceStatusURL = GET_URL + "supplychain/grievancebycategory";
    Axios.get(grievanceStatusURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let grievanceStatus = response.data;
        dispatch({ type: GET_GRIEVANCES_STATUS, payload: grievanceStatus});
      })
      .catch(error => {
        console.log(error);
      });
  }
} 

export const getGrievancesList = () => {
  return(dispatch) => {
  const grievancesURL = GET_URL + "supplychain/totalGrievance";
    Axios.get(grievancesURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let lst = response.data;
        grievancesList = lst.grievance_details;
        initialGrivancesList = lst.grievance_details;
        dispatch({ type: GET_GRIEVANCES_LIST, payload: lst.grievance_details });
      })
      .catch(error => {
        console.log(error);
      });
  }
}
export const getGrievancesFiltersOptions = () => {
  return (dispatch) => {
    let results;
    results = {
      ventureItems: [
        { label: 'Lorem Ipsum', value: 'LI1' },
        { label: 'Lorem Ipsum', value: 'LI2' },
        { label: 'Lorem Ipsum', value: 'LI3' }
      ],
      statusItems: [
        { label: 'Investigation', value: 'Investigation' },
        { label: 'Verification', value: 'Verification' },
        { label: 'Developing Action Plan', value: 'Developing Action Plan' },
        { label: 'Monitoring Implementation', value: 'Monitoring Implementation' },
        { label: 'Closed', value: 'Closed' }
      ],
      countryItems: [
        { label: 'Indonesia', value: 'Indonesia' },
        { label: 'Malaysia', value: 'Malaysia' }
      ]
    };
    dispatch({ type: GET_GRIEVANCES_FILTER_OPTIONS, payload: results });
  };
};

export const getGrievancesSortOrder = () => {
  return (dispatch) => {
    dispatch({ type: GET_GRIEVANCES_ORDER, payload: grievancesSortOrder });
  };
};

export const applyGrievancesSorting = (order) => {
  return (dispatch) => {
    switch (order) {
      case 'asc': {
        grievancesList.sort((a, b) => (a.grievance_status_date > b.grievance_status_date) ? 1 : ((b.grievance_status_date > a.grievance_status_date) ? -1 : 0))
        break;
      }
      case 'desc': {
        grievancesList.sort((a, b) => (a.grievance_status_date < b.grievance_status_date) ? 1 : ((b.grievance_status_date < a.grievance_status_date) ? -1 : 0))
        break;
      }
      default:
        break;
    }

    dispatch({ type: GET_GRIEVANCES_ORDER, payload: order });
    dispatch({ type: GET_GRIEVANCES_LIST, payload: grievancesList });
  };
};

export const updateGrievancesFilter = (field, value) => {
  if(field === 'country'){
    field = 'country_of_violation';
  } else if (field === 'status'){
    field = 'grievance_current_status'
  }
  return () => {
    grievancesList = initialGrivancesList.filter((item) => item[field] === value)
  };
};

export const applyGrievancesFilter = () => {
  return (dispatch) => {
    dispatch({ type: GET_GRIEVANCES_LIST, payload: grievancesList });
  };
}

export const getGrievanceDetails = (id) => {

  return (dispatch) => {
    if(grievancesList.length> 0){
      let detailData = grievancesList.filter(data => data.grievance_id === id);
      detailData = detailData[0];
      dispatch({ type: GET_GRIEVANCE_DETAIL, payload: detailData });
    } else {
          const grievancesURL = GET_URL + "supplychain/totalGrievance";
          Axios.get(grievancesURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
          .then(response => {
            let lst = response.data;
            grievancesList = lst.grievance_details;
            let detailData = grievancesList.filter(data => data.grievance_id === id);
            detailData = detailData[0];
            dispatch({ type: GET_GRIEVANCE_DETAIL, payload: detailData });
          })
          .catch(error => {
            console.log(error);
          });
        }
    
    
  }
}

export const getTimelineTop = () => {
  return (dispatch) => {
    let timeline = [
      { id: 1, text: "Investigation", active: true, suspended: false, showTooltip: false, tooltipText: '' },
      { id: 2, text: "Verification", active: true, suspended: true, showTooltip: false, tooltipText: '' },
      { id: 3, text: "Developing Action Plan", active: true, suspended: true, showTooltip: false, tooltipText: '' },
      { id: 4, text: "Monitoring Implementation", active: true, suspended: true, showTooltip: false, tooltipText: '' },
      { id: 5, text: "Closed", active: true, suspended: false, showTooltip: false },
    ].reverse();
    timelineTop = [...timeline];
    dispatch({ type: GET_TIMELINE_TOP, payload: timeline });
  }
}

export const getTimelineBottom = () => {
  return (dispatch) => {
    let timeline = [
      { id: 1, text: "2017", active: false, suspended: false },
      { id: 2, text: "2018", active: false, suspended: false },
      { id: 3, text: "2019", active: false, suspended: false },
      { id: 4, text: "2020", active: true, suspended: false }
    ].reverse();
    dispatch({ type: GET_TIMELINE_BOTTOM, payload: timeline });
  }
}

export const showHideTimelineTooltip = (id) => {
  return (dispatch) => {
    let listData = timelineTop.map(item => {
      if (item.id === id) {
        item.showTooltip = !item.showTooltip;
      } else {
        item.showTooltip = false;
      }
      return item;
    });
    dispatch({ type: GET_TIMELINE_TOP, payload: listData });
  }
}


export const navigateSelections = (selection) => {
  return (dispatch) => {
    let navList = {
      home: 'hrActive',
      sply: 'hrInactive',
      grivn: 'hrInactive',
      coIn: 'hrInactive',
      fp: 'hrInactive',
    };
    if (selection === '/supplychain' || selection === '/supplychaindetails') {
      navList.home = 'hrInactive';
      navList.sply = 'hrActive';
    } else if (selection === '/grievances') {
      navList.home = 'hrInactive';
      navList.grivn = 'hrActive';
    } else if (selection === '/coinvest') {
      navList.home = 'hrInactive';
      navList.coIn = 'hrActive';
    } else if (selection === '/forestprotection') {
      navList.home = 'hrInactive';
      navList.fp = 'hrActive';
    }
    dispatch({ type: NAV_TAB, payload: navList });
  }
}

export const getKeys = () => {
  return(dispatch) => {

    loadModules(["esri/request"],{ css: true })
    .then(([esriRequest]) => {
      let options = {
        query: {
          f: "json",
          username: "palm_wise_portal",
          password: "palm_wise20",
          referer: "https://cargill.maps.arcgis.com/home"
        },
        responseType: "json"
      };

      let url = 'https://www.arcgis.com/sharing/generateToken';
      esriRequest(url, options).then(function(response) {
        // In this case, we simply print out the response to the page.
        authToken = response.data.token;
        //console.log(authToken);
        
      });
    })

  }
}

export const getMillCount =() => {
  return(dispatch) => {
    loadModules(["esri/request"],{ css: true })
    .then(([esriRequest]) => {
      // let options = {
      //   query: {
      //     where: '1%3D1',
      //     returnCountOnly: true,
      //     token: authToken,
      //     f: "json",
      //   },
      //   responseType: "json"
      // };

      // let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/';
      // esriRequest(url, options).then(function(response) {
        // In this case, we simply print out the response to the page.
        let url = "https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=1%3D1&returnCountOnly=true&token="+authToken+"&f=json";
        esriRequest(url).then(function(response) {
        totallMillCount = response.data.count;
    })
  })
  }
}

export const getMillInfo = () => {
  return(dispatch) => {
    // loadModules(["esri/request"],{ css: true })
    // .then(([esriRequest]) => {
    //     debugger
    //     let url = "https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=1=1&returnDistinctValues=true&groupByFieldsForStatistics=Validate&outStatistics=%5B%7B%0D%0A++++%22statisticType%22%3A+%22count%22%2C%0D%0A++++%22onStatisticField%22%3A+%22Validate%22%2C+%0D%0A++++%22outStatisticFieldName%22%3A+%22Count%22%0D%0A%7D%5D&returnExceededLimitFeatures=true&f=json&token=p91wIVfPZJ4Y3gZQRjZbBTZApU3wGrJgfUGQHC73rpMg-PGMWi4NAsUSxSJ0_5ONo4LzU6_YYe0q9h5O0lutymNUSTPT_eRbsXeiFPoHqLpwPcGXNWnQ3yWoy5WdbhnpkFidZnnJ2W39jCWpgSQ6YA3bJlbbSp73LAhG5pIImSaDuW9E2oTLaIL2wuuhHa9a"
    //     let url = "https://services3.arcgis.com/Ax6lXluGmqEBX6ju/arcgis/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=1%3D1&outfields=*&f=json&token=C605w0taMZmRPDSA137x39Spd3vYrH0LdBPs_ByEjh4asGL_PukCgH3yMkvTczbAYsost_0GyhEjNu1rvRZv8W4OQnHGMaMfPikWWFK1-WVWDoMthMFZ43nYXJdE6DJvhsBGmjkVLpPxEPAbmrAnX3LaUjSY_oaKySKkYrDEnwg-pvlr8VpCrtKRiVlb95nD"
    //     esriRequest(url).then(function(response){
    //       debugger
    //       let a = response.data.features.filter(({element}) => element.attributes.Validate === "with alerts");
    //       console.log(a);
          
    //     });
    //   });

  }
}

export const getTotalAreaOfDeforestation = () => {
  return (dispatch) => {
    let totalArea = [200, 210, 190, 220, 200, 240, 190, 220];
    //dispatch({ type: GET_TOTAL_AREA_OF_DEFORESTATION, payload: totalArea });
    totalArea = totalArea;
  }
}

export const getSupplyCheckerSearchData = () => {
  return(dispatch) => {
    const supplierCheckerURL = GET_URL + "supplychain/suppliermapping";
    Axios.get(supplierCheckerURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let searchData = response.data;
        initialSearchItems = searchData.supplier_mapping_list;
        dispatch({ type: GET_SUPPLY_CHECKER_SEARCH_LIST, payload: initialSearchItems });
      })
      .catch(error => {
        console.log(error);
      }) 
  }
}

export const getGrievancesStatusCountData = () => {
  return (dispatch) => {
    const statusCountURL = GET_URL + "supplychain/getCountOfGrievanceByStatus";
    Axios.get(statusCountURL, { params: paramObj, headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        let statusCountData = response.data;
        dispatch({ type: GET_GRIEVANCES_STATUS_COUNT, payload: statusCountData.grievance_count_by_status });
      })
      .catch(error => {
        console.log(error);
      })
  }
}

export const setSearchResult = (event) => {
  return (dispatch) => {
    let items = initialSearchItems;
      if (items) {
        items = items.filter((item) => {
          return item.transaction_supplier_name.toLowerCase().search(event.target.value.toLowerCase()) !== -1;
        });
      }
      const uniqueObjects = [ ...new Set( items.map( item => item.harmonized_supplier_name) ) ].map( harmonized_supplier_name=> { return items.find(item => item.harmonized_supplier_name === harmonized_supplier_name) } )
      dispatch({type:GET_SUPPLY_CHECKER_SEARCH_LIST, payload:uniqueObjects});
    }   
}

export const getCoInvestProgramData = () => {
  return (dispatch) => {
    let listData = [
      {
        id: 1,
        program: 'Labor and Human Rights Protection',
        details: [
          {
            activity: 'Set up of worker voice platform (Ulula)',
            countries: 'Indonesia, Malaysia, Guatemala',
            status: 'Implementation',
            objective: 'Enable scale-up implementation of Ulula\'s worker voice platform in additional suppliers\' operations to support progress on labor rights issue identification, management and remediation',
            customerValue: 'Enable progress in implementation of labor requirements in the supply chain',
            projectBudget: '$30,000',
          }
        ]
      },
      {
        id: 2,
        program: 'Traceability',
        details: [
          {
            activity: 'Development of village engagement program',
            countries: 'Indonesia, Malaysia, Latin America',
            status: 'Design',
            objective: 'Engage with a village to map farms and design an engagement program where the area is high risk to improve monitoring, protection and also raise awareness on best practices with local stakeholders',
            customerValue: 'Enabling increase of TTP % in their supply chain and demonstrate commitment to supporting capacity building with local stakeholders',
            projectBudget: '$20,000',
          }
        ]
      },
      {
        id: 3,
        program: 'Forest Protection',
        details: [
          {
            activity: 'Contibute to conservation of 10,000 ha high environmental value area(s) in progress',
            countries: 'Indonesia',
            status: 'Implementation',
            objective: 'Implementation and investment plans covering an estimated 10,000 ha (total) are developed in the Siak-Pelalawan landscape.Implementing partners, potential donors and additional financing options are all identified ',
            customerValue: 'Demonstrate commitment to implementing No Deforestation and Peat commitments.',
            projectBudget: '$1,00,000 ',
          }
        ]
      },
      {
        id: 4,
        program: 'Smallholder Inclusion',
        details: [
          {
            activity: 'Mapping Smallholders',
            countries: 'Indonesia',
            status: 'Implementation',
            objective: 'Identify and profile farmers and map their farms to understand capacity, gaps and achieve traceability as part of IDH\'s Verified Sourcing Program in Ketapang',
            customerValue: 'Achieve a better understanding of farmers in their supply chain; establish a baseline against which to measure progress/impact, and gain insights to developments in the VSA wider program.',
            projectBudget: '$60,000',
          },
          {
            activity: 'NDPE Outreach Extension Support for FFB Dealers and Smallholders',
            countries: 'Malaysia',
            status: 'Design',
            objective: 'Provide training and hands-on support on best practices to FFB Dealers and smallholders who do not have the resources, financial or human, to achieve compliance on their own and require training.',
            customerValue: 'Communication value of supporting FFB dealers and smallholders to drive compliance outside of concessions where there remains significant challenges and issues with deforestation and development on peat in particular. They can also support greater market access/inclusion for smallholders in their supply chains.',
            projectBudget: '$35,000',
          } 
        ]
      },
      {
        id: 5,
        program: 'Landscape Program',
        details: [
          {
            activity: 'Sungei Linau Production-Protection Program',
            countries: 'Indonesia',
            status: 'Implementation',
            objective: 'Implement a co-developed production-protection program with the Sungei Linau community to prevent further deforestation, improve community land permitting and livelihoods through training on GAP.',
            customerValue: 'Be a part of ground-breaking and monumental work on solutions that balance conservation and smallholder livelihoods; demonstrate thought leadership as well as ongroud commitment',
            projectBudget: '$40,000'
          }
        ]   
      },
      {
        id: 6,
        program: 'Industry Transformation',
        details: [
          {
            activity: 'Facilitation of "Deforestation Outside of Concessions" Working Group',
            countries: 'Indonesia, Malaysia',
            status: 'Implementation',
            objective: 'Fund the time of technical organizations on the review, collection and analysis of data to facilitate development of approaches to manage deforestation outside concessions (smallholders, communities).',
            customerValue: 'Communication about enabling the identification and roll out of solutions to pressing issues impacting the pace and effectiveness of NDPE implementation',
            projectBudget: '$1,00,000'
          }
        ]
      },
    ];
    dispatch({type:GET_CO_INVEST_DATA, payload: listData});
  }
}

export const downloadMillList = () => {
  return (dispatch) => {
    const statusCountURL = "https://api-dev.dev.dev-cglcloud.com/casceu/spapi/v1/apikey/palmwise/milllist/download?year=2019&quarter=Q2";
    //const statusCountURL = "https://api-dev.dev.dev-cglcloud.com/casceu/spapi/v1/apikey/palmwise/milllist/base64/download?year=2019&quarter=Q2"
    Axios.get(statusCountURL, {  headers: { 'apikey': 'HHwwZgTyB8hWR9tjRH6BydREYTxNnPWp' } })
      .then(response => {
        console.log(response);
        //const linkSource = `data:application/pdf;base64,${response.data}`
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'milllist.pdf');
        document.body.appendChild(link);
        link.click();
      })
      .catch(error => {
        console.log(error);
      })
  }
  }
