import { NAV_TAB } from '../actions/types';

let location = window.location.pathname;
let home = 'hrInactive';
let sply = 'hrInactive';
let grivn = 'hrInactive';
let coIn = 'hrInactive';
let fp = 'hrInactive';

if (location === '/home') {
    home = 'hrActive';
}
else if (location === '/supplychain') {
    sply = 'hrActive';
}
else if (location === '/grievances' || location === '/grievancesoverview') {
    grivn = 'hrActive';
}
else if (location === '/coinvest') {
    coIn = 'hrActive';
}
else if (location === '/forestprotection') {
    fp = 'hrActive';
}
const INITIAL_STATE = {
    navSelection: {
        home: home,
        sply: sply,
        grivn: grivn,
        coIn: coIn,
        fp: fp,
    },
};

export default (state = INITIAL_STATE, action) => {


    switch (action.type) {
        case NAV_TAB:
            return { ...state, navSelection: action.payload };
        default:
            return state;

    }
}