import { combineReducers } from 'redux';
import HomeReducer from './HomeReducer';
import FilterReducer from './FilterReducer';
import GrievancesReducer from './GrievancesReducer';
import SupplyChainReducer from './SupplyChainReducer';
import CoInvestReducer from './CoInvestReducer';
import NavigationReducer from './RootReducer';

export default combineReducers({
    home:HomeReducer,
    filters:FilterReducer,
    grievances:GrievancesReducer,
    supplychain:SupplyChainReducer,
    selection: NavigationReducer,
    coinvest: CoInvestReducer
  })