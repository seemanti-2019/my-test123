import {
    GET_GRIEVANCES_LOCATION, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST,
    GET_GRIEVANCES_FILTER_OPTIONS, GET_GRIEVANCES_ORDER, GET_GRIEVANCE_DETAIL, GET_TIMELINE_TOP, GET_TIMELINE_BOTTOM, GET_GRIEVANCES_STATUS_COUNT
} from '../actions/types';


const INITIAL_STATE = {
    location: {"total_count": 0,"grievance_details":[]},
    pieChart: { "number_of_direct_supplier": 0, "number_of_indirect_supplier": 0 },
    status: {},
    list: [],
    filterOptions: {
        ventureItems: [],
        statusItems: [],
        countryItems: [],
    },
    sortOrder: 'desc',
    selectedGrievance: {},
    timelineTop: [],
    timelineBottom: [],
    statusCountData: {}
};

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {
        case GET_GRIEVANCES_LOCATION:
            return { ...state, location: action.payload };
        case GET_GRIEVANCES_SUPPLIER_INFO:
            return { ...state, pieChart: action.payload };
        case GET_GRIEVANCES_STATUS:
            return { ...state, status: action.payload };
        case GET_GRIEVANCES_LIST:
            return { ...state, list: action.payload };
        case GET_GRIEVANCES_FILTER_OPTIONS:
            return { ...state, filterOptions: action.payload };
        case GET_GRIEVANCES_ORDER:
            return { ...state, sortOrder: action.payload };
        case GET_GRIEVANCE_DETAIL:
            return { ...state, selectedGrievance: action.payload };
        case GET_TIMELINE_TOP:
            return { ...state, timelineTop: action.payload };
        case GET_TIMELINE_BOTTOM:
            return { ...state, timelineBottom: action.payload };
        case GET_GRIEVANCES_STATUS_COUNT:
            return { ...state, statusCountData: action.payload };
        default:
            return state;

    }
}