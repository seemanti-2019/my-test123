import { GET_CO_INVEST_DATA } from '../actions/types';


const INITIAL_STATE = {
    programData: [],
};

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {
        case GET_CO_INVEST_DATA:
            return { ...state, programData: action.payload };
        default:
            return state;
    }
}