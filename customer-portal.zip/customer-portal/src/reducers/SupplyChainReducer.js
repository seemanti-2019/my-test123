import { GET_RISK_PER_MILL, GET_SUPPLY_CHAIN_WIDGET, GET_COUNTRY_VOLUME, GET_REFINERIES_COUNT,GET_NDPE_POLICY_DATA } from '../actions/types';


const INITIAL_STATE = {
    risk: {high:0,medium:0,low:0},
    millcount:{total_count:0,thirdparty_mills_count:0},
    volumes:[],
    refineriesCount:{total_count:0,thirdparty_refineries_count:0},
    ndpe:0,
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
    case GET_RISK_PER_MILL:
    return {...state, risk: action.payload };
    case GET_SUPPLY_CHAIN_WIDGET:
    return {...state, millcount: action.payload };
    case GET_COUNTRY_VOLUME:
    return {...state, volumes: action.payload };
    case GET_REFINERIES_COUNT:
    return {...state, refineriesCount: action.payload };
    case GET_NDPE_POLICY_DATA:
 return {...state, ndpe:action.payload};
default:
    return state;

}
}