import { GET_FILTER_OPTIONS, GET_FILTER_WIDGET, GET_SELECTED_FILTER, CLEAR_SELECTED_FILTER } from '../actions/types';


const INITIAL_STATE = {
    options: {
        product_group:[],
        rspo:[] ,
        year_quater:[] ,
        destination:[] ,
    },
    filterWidget: false,
    userSelections:[],
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
case GET_FILTER_OPTIONS:
return {...state, options: action.payload };
case GET_FILTER_WIDGET:
return {...state, filterWidget: action.payload };
case GET_SELECTED_FILTER:
return {...state, userSelections: action.payload };
case CLEAR_SELECTED_FILTER:
return {...state, userSelections: action.payload };
default:
return state;

}
}