import { TEST, TRACIBILITY_DATA, GET_MY_VOLUME_DATA, GET_NEWS, GET_DOWNLOADS, GET_SUPPLY_CHECKER_SEARCH_LIST, GET_FOOTPRINT_DATA, DRAW_FOOTPRINT_FLOW,GET_WORLD_MAP } from '../actions/types';


const INITIAL_STATE = {
name: 'Hello',
tracibility:{'mills':10, 'plantation':0},
volumes:{'productVolumes':[],'kernalMT':'','palmMT':''},
news:[],
downloads: [],
searchData: [],
footPrint: [],
footPrintFlow: [],
worldMapData:{},
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
case TEST:
 return {...state, name: action.payload };
 case TRACIBILITY_DATA:
 return {...state, tracibility: action.payload };
 case GET_MY_VOLUME_DATA:
 return {...state, volumes: action.payload };
 case GET_NEWS:
 return {...state, news: action.payload };
 case GET_DOWNLOADS:
 return {...state, downloads: action.payload };
 case GET_SUPPLY_CHECKER_SEARCH_LIST:
 return {...state, searchData: action.payload};
 case GET_FOOTPRINT_DATA:
     return{...state, footPrint: action.payload};
 case DRAW_FOOTPRINT_FLOW:
     return {...state, footPrintFlow: action.payload};
 case GET_WORLD_MAP:
     return {...state, worldMapData: action.payload};
default:
return state;

}
}