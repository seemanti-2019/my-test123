import React from 'react';
import { Card } from 'react-bootstrap';

function SupplyChainHeader() {
  
  return <Card style={{ width: '100%' }}>
          <Card.Body>
            <h1><strong>My Supply Chain</strong></h1>
            <p>
            This dashboard represent your selection from filtering.
            </p>
            </Card.Body></Card>
}
export default SupplyChainHeader;