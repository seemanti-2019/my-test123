import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, Button} from 'react-bootstrap';
import { getRiskPerMill, getNdpe } from '../../actions/index'
// import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { FaInfoCircle } from 'react-icons/fa';
import C3Chart from 'react-c3js';
import 'c3/c3.css';


class PerformanceWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
      debugger
    this.props.getRiskPerMill();
    this.props.getNdpe();
  }

  drawRiskPerMill(){
        return this.props.risk.map((item, i) => {

            if((item.priority === "High") || (item.priority === "Low")){
                return (
                    <Row sm={12} key={i}>
                    <Col sm={2}></Col>
                    <Col sm={3}>
                        <div style={{width:item.size, height: item.size, borderRadius: '50%', fontSize: '14px',color: '#fff', textAlign: 'center',
                        background: item.priority === "High"?'#A22B2F':'#628C1C', lineHeight:item.size}}>
                            <strong>{item.count}</strong>
                        </div>
                    </Col>
                    <Col sm={4}>
                        <hr style={{marginTop:item.priority === "High"?'3.3em':'3em'}}></hr>
                    </Col>
                    <Col sm={3}>
                        <div style={{display:'table-cell', height:item.priority === "High"?'100px':'75px',verticalAlign:'middle'}}>{item.priority === "High"?'High':'Low'}</div>
                    </Col>
                </Row>
                 )
            }else{
                return (
                    <Row sm={12} key={i}>
                            <Col sm={3}></Col>
                            <Col sm={3}>
                                <div style={{width:item.size, height: item.size, borderRadius: '50%', fontSize: '14px',color: '#fff', textAlign: 'center',background: '#DDAA01', lineHeight:item.size}}>
                                    <strong>{item.count}</strong>
                                </div>
                            </Col>
                            <Col sm={3}>
                                <hr style={{marginTop:'2.8em'}}></hr>
                            </Col>
                            <Col sm={3}>
                                <div style={{display:'table-cell', height:'90px',verticalAlign:'middle'}}>Medium</div>
                            </Col>
                    </Row>
                 )
            }
        })
  }
  


  render() {

    const dataPie = {
        columns: [
          ['Low', this.props.risk.low],
          ['Medium', this.props.risk.medium],
          ['High', this.props.risk.high],
        ],
        type: 'donut',
      };
  
      const legendPie = {
        position: 'right',
        item: {
          onclick: function () { }
        }
      };
      const colorPie = {
        pattern: ['#ABAD25', '#DAAA00', '#CF7F00']
      };
      const sizePie = {
        height: 240,
        width: 460
      };
  
      const tooltipPie = {
        show: false
      };
      const donut = {
        label: {
          format: function (value, ratio, id) {
            return value
          },
          gauge: {
            width: 10
          }
        }
      };
    
    return (
        <Card sm={12} style={{boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0}}>
            <Card.Body>
            <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
                <Col sm={10} style={{ fontSize: '1.5em' }}>Risk per mill</Col>
                <Col sm={2} style={{textAlign:'right'}}>
                <Button variant="light">
                    <FaInfoCircle size="1.3rem" />
                </Button>
                </Col>
            </Row>

                <Row sm={12} style={{padding:'1em 0 1em 0'}}>
                    {/* <Col sm={2}></Col> */}
                    <Col  style={{ padding: '1em' }} >
                        <C3Chart data={dataPie} legend={legendPie} color={colorPie} size={sizePie} tooltip={tooltipPie} donut={donut} />
                    </Col>
                    {/* <Col sm={1}></Col> */}
                        {/* <span >
                            <strong>Risk per mill</strong>
                        </span> */}
                        {/* <span style={{ paddingLeft:'2em'}}>
                            <OverlayTrigger
                            key={'top'}
                            placement={'top'}
                            overlay={
                            <Tooltip id="">
                                Risk classification is only applicable to mills that have been assessed by Global Forrest Watch.
                            </Tooltip>
                            }>
                            <FaInfoCircle size={22}></FaInfoCircle>
                            </OverlayTrigger>
                        </span>
                        <br></br> */}
                        {/* <p>Global Forest Watch classifies mills in <a href="https://www.wri.org/publication/palmriskmethodology" target="blank">risk categories</a>  that Cargill uses as priority for engagement.</p> */}
                        {/* {this.drawRiskPerMill()} */}
                
                    
                    {/* <Col sm={6}>
                        <p><strong>Volume covered by NDPE policy</strong></p>
                        <p>We require our suppliers to have a policy on No Deforestation, No Peat, No Exploitation of people.</p>
                        <Col sm={8}  style={{ width: "18em", padding:'1em' }}>
                        <CircularProgressbarWithChildren value={this.props.ndpe} styles={buildStyles({ pathTransition: "none", strokeLinecap: "butt",
                            pathColor: "#ABAD25", })} strokeWidth={3}>
                                <div style={{ margin: 0 }}>
                                    <strong style={{ fontFamily: 'Impact,Charcoal', fontSize: 42 }}>{`${Math.round(this.props.ndpe)}%`}</strong>
                                    <div style={{ fontSize: '14', textAlign: 'center' }}>Volume</div>
                                    <div style={{ fontSize: '14', textAlign: 'center' }}>covered</div>
                                </div>
                            </CircularProgressbarWithChildren>
                        </Col>
                    </Col> */}
                </Row>
                <hr></hr>
                    <Row>
                        <Col style={{ textAlign: 'center', paddingTop: '0.4rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }}>Sustainability performance details</Col>
                    </Row>
            </Card.Body>
            
        </Card>
      
    );
  }
}


const mapStateToProps = state => {
  return {
    risk: state.supplychain.risk,
    ndpe: state.supplychain.ndpe,
  };
}

export default connect(mapStateToProps, { getRiskPerMill, getNdpe })(PerformanceWidget);
