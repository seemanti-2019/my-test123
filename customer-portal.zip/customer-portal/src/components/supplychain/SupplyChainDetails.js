import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, CardDeck, Button } from 'react-bootstrap';
import history from '../header/history'
import { getMillCount, navigateSelections } from '../../actions/index'
import SupplierSearch from '../supplierchecker/SearchComponent';
import { FaChevronRight } from 'react-icons/fa';



class SupplyChainDetails extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
   // this.props.getMillCount();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   navigateToSelected = (navTo) => {
    this.props.navigateSelections(navTo);
    history.push(navTo);
  }

  


  render() {
    return (
      <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
        
        <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
          <Col>
            <Row>
            <Button variant="link" style={{color: '#000', fontSize: '20px'}} onClick={(e)=> this.navigateToSelected('/home')}>Home</Button>
            <div style={{marginTop:'9px'}}><FaChevronRight size={13}/></div>
            <Button variant="link" style={{color: '#000', fontSize: '20px'}}onClick={(e)=> this.navigateToSelected('/supplychain')}>My Supply Chain</Button>
            <div style={{marginTop:'9px'}}><FaChevronRight size={13}/></div>
            <Button variant="link" style={{color: '#977000', fontSize: '20px'}}>Supply Chain Details</Button></Row>
          </Col>
          <Col md="auto"></Col>
          <Col xs lg="2"><SupplierSearch/></Col>
        </Row>
        <Col style={{paddingLeft:'2em', paddingRight:'1.5em'}}><hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr></Col>
        <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
          This Page is under construction
        </CardDeck>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { getMillCount, navigateSelections })(SupplyChainDetails);
