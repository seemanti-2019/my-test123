import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, CardDeck, Button } from 'react-bootstrap';
import history from '../header/history'
import { getMillCount, navigateSelections } from '../../actions/index'
import TracebilityWidget from '../home/Tracebility';
import SCWidget from './SupplyChainWidget';
import SPerformance from './PerformanceWidget';
import SupplierSearch from '../supplierchecker/SearchComponent';
import FilterHeader from '../filters/FilterWidget';
import { FaChevronRight } from 'react-icons/fa';
import NdpeWidget from './NdpeWidget';


class SupplyChain extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
   // this.props.getMillCount();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

  navigateToSelected = () => {
    this.props.navigateSelections('/home');
    history.push('/home');
  }

  render() {
    return (
      // <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
      //   <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
      //     <Col>
      //       <Row>
      //         <Button variant="link" style={{color: '#000', fontSize: '20px'}} onClick={(e)=> this.navigateToSelected()}>Home</Button>
      //         <div style={{marginTop:'9px'}}><FaChevronRight size={13}/></div>
      //         <Button variant="link" style={{color: '#977000', fontSize: '20px'}} >My Supply Chain</Button>
      //       </Row>
      //     </Col>
      //     <Col md="auto"></Col>
      //     <Col xs lg="2"><SupplierSearch/></Col>
      //   </Row>
      //   <Col style={{paddingLeft:'2em', paddingRight:'1.5em'}}><hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr></Col>
      //   <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
      //   <FilterHeader></FilterHeader>
      //   </CardDeck>
      //   {/* <CardDeck style={{padding:'1.5em'}}>
      //     <SCHeader/>
      //   </CardDeck>     */}
      //   <CardDeck style={{padding:'1.5em'}}>
      //     <SCWidget/>
      //     <TracebilityWidget filter={true}/>
      //   </CardDeck>
      //   <div style={{paddingLeft:'1em', paddingRight:'1em', fontSize: '1.5em'}}>Sustanability performance details
      //     <hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr>
      //   </div>
      //   <CardDeck style={{padding:'1.5em'}}>
      //     <SPerformance/>
      //     <NdpeWidget/>
      //   </CardDeck>
      //   <SubscriptionAndFAQ source="supplyChain" />
      // </div>

      // <Row style={{backgroundColor:'black'}}> 
      //   <Col sm={2} style={{backgroundColor:'black', color:'white'}}>
      //     <div class="sidenav">
      //       <a href="#about">About</a>
      //       <a href="#services">Services</a>
      //       <a href="#clients">Clients</a>
      //       <a href="#contact">Contact</a>
      //     </div>
      //   </Col>
      //   <Col sm={10} style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>

      //     <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
      //       <Col>
      //         <Row>
      //           <Button variant="link" style={{color: '#000', fontSize: '20px'}} onClick={(e)=> this.navigateToSelected()}>Home</Button>
      //           <div style={{marginTop:'9px'}}><FaChevronRight size={13}/></div>
      //           <Button variant="link" style={{color: '#977000', fontSize: '20px'}} >My Supply Chain</Button>
      //         </Row>
      //       </Col>
      //       <Col md="auto"></Col>
      //       <Col xs lg={3}><SupplierSearch/></Col>
      //     </Row>

      //     <Col style={{paddingLeft:'2em', paddingRight:'1.5em'}}><hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr></Col>
      //       <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
      //       <FilterHeader></FilterHeader>
      //       </CardDeck>
    
      //       <CardDeck style={{padding:'1.5em'}}>
      //         <SCWidget/>
      //         <TracebilityWidget filter={true}/>
      //       </CardDeck>

      //       <div style={{paddingLeft:'1em', paddingRight:'1em', fontSize: '1.5em'}}>Sustanability performance details
      //         <hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr>
      //       </div>

      //       <CardDeck style={{padding:'1.5em'}}>
      //         <SPerformance/>
      //         <NdpeWidget/>
      //       </CardDeck>

      //       <SubscriptionAndFAQ source="supplyChain" />
      //   </Col>
      // </Row>
      <div class="wrapper">
        <FilterHeader/>
   
    <div id="content">

        {/* <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <i class="fas fa-align-left"></i>
                    <span>Toggle Sidebar</span>
                </button>

            </div>
        </nav> */}

        <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
             <Col>
               <Row>
                 <Button variant="link" style={{color: '#000', fontSize: '20px'}} onClick={(e)=> this.navigateToSelected()}>Home</Button>
                 <div style={{marginTop:'9px'}}><FaChevronRight size={13}/></div>
                 <Button variant="link" style={{color: '#977000', fontSize: '20px'}} >My Supply Chain</Button>
               </Row>
             </Col>
             <Col md="auto"></Col>
             <Col xs lg={3}><SupplierSearch/></Col>
           </Row>

           <Col style={{paddingLeft:'2em', paddingRight:'1.5em'}}><hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr></Col>
             {/* <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
             <FilterHeader></FilterHeader>
             </CardDeck> */}
    
           <CardDeck style={{padding:'1.5em'}}>
               <SCWidget/>
               <TracebilityWidget filter={true}/>
             </CardDeck>

             <div style={{paddingLeft:'1em', paddingRight:'1em', fontSize: '1.5em'}}>Sustanability performance details
               <hr style={{height:'1px', borderWidth:'0px', color: '#000', backgroundColor: '#000'}}></hr>
             </div>

             <CardDeck style={{padding:'1.5em'}}>
               <SPerformance/>
               <NdpeWidget/>
             </CardDeck>

             {/* <SubscriptionAndFAQ source="supplyChain" /> */}
    </div>
</div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { getMillCount, navigateSelections })(SupplyChain);
