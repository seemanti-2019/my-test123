import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history';
import { Row, Col, Button, Card, CardDeck } from 'react-bootstrap';
import SupplierSearch from '../supplierchecker/SearchComponent';
import { FaInfoCircle, FaPager } from 'react-icons/fa';
 
class SustainabilityPerformance extends React.PureComponent {

    constructor(props) {
        super(props);
        this.textInput = React.createRef();        
    }
    test1 = () => {
        this.props.navigateSelections('/home');
        history.push('/home');
    }

    test2 = () => {
        this.props.navigateSelections('/supplychain');
        history.push('/supplychain');
    }

    test3 = () => {
        this.props.navigateSelections('/supplychain');
        history.push('/sustainabilty-performance');
    }


    render() {
        return(
            <div style={{ padding: '1em', backgroundColor: '#F5F5F5',minHeight: '790px' }}>
                <Row style={{ paddingTop: '1em', paddingLeft: '4em',paddingRight: '4rem' }}>
                    <Col>
                        <Row>
                            <Button variant="link" style={{ color: '#000', fontSize: '22px' }} onClick={(e) => this.test1()}>Home</Button>
                            <div style={{ marginTop: '10px' }}>></div>
                            <Button variant="link" style={{ color: '#000', fontSize: '22px' }} onClick={(e) => this.test2()}>My Supply Chain</Button>
                            <div style={{ marginTop: '10px' }}>></div>
                            <Button variant="link" style={{ color: '#AD7029', fontSize: '22px' }} >Sustainability Performance</Button></Row>
                    </Col>
                    <Col md="auto"></Col>
                    <Col xs lg="2"><SupplierSearch /></Col>
                </Row>
                <div style={{width: '92%',borderBottom: '1px solid', marginTop: '1em', marginLeft: '4em' }}></div>
                <div style={{width: '100%', paddingLeft: '4em'}}>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block' }}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>Mill And Refinery KPIs</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem',width: '33%',display:'inline-block' }}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>Direct mill KPIs</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block'}}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>High risk mills</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block'}}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={8}>Refinery action plan</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block' }}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>Traders action plan</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block' }}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>Volume covered by Group Policy Plan</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                    <CardDeck style={{ paddingTop: '1.5em',marginRight:'.4rem', width: '33%',display:'inline-block' }}>
                        <Card>
                            <Card.Body>
                                <Card.Title>
                                    <Row>
                                        <Col md={10}>Reporting Score</Col>
                                        <Col md={2}>
                                            <Button variant="light">
                                                <FaInfoCircle size="1.3rem"/>
                                            </Button>
                                        </Col>
                                    </Row>
                                </Card.Title>
                            </Card.Body>
                        </Card>
                    </CardDeck>
                </div>
            </div>    
        );
    }

}



const mapStateToProps = state => {
    console.log(state);
    return {
        
    };
}

export default connect(mapStateToProps, {})(SustainabilityPerformance);
