import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, Button} from 'react-bootstrap';
import { getRiskPerMill, getNdpe } from '../../actions/index'
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { FaInfoCircle } from 'react-icons/fa';


class NdpeWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getRiskPerMill();
    this.props.getNdpe();
  }

  


  render() {
    
    return (
        <Card sm={6} style={{boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0}}>
            <Card.Body>
            <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
                <Col sm={10} style={{ fontSize: '1.5em' }}>Volume covered by NDPE policy</Col>
                <Col sm={2} style={{textAlign:'right'}}>
                <Button variant="light">
                    <FaInfoCircle size="1.3rem" />
                </Button>
                </Col>
            </Row>
                
                <Row sm={12} style={{padding:'1em 0 1em 0'}}>
                    <Col sm={3}></Col>
                    <Col sm={8}>
                        <Col sm={8}  style={{ width: "18em", padding:'1em' }}>
                        <CircularProgressbarWithChildren value={this.props.ndpe} styles={buildStyles({ pathTransition: "none", strokeLinecap: "butt",
                            pathColor: "#ABAD25", })} strokeWidth={3}>
                                <div style={{ margin: 0 }}>
                                    <strong style={{ fontFamily: 'Impact,Charcoal', fontSize: 42 }}>{`${Math.round(this.props.ndpe)}%`}</strong>
                                    <div style={{ fontSize: '14', textAlign: 'center', }}>Volume</div>
                                    <div style={{ fontSize: '14', textAlign: 'center', }}>covered</div>
                                    
                                </div>
                            </CircularProgressbarWithChildren>
                        </Col>
                    </Col>
                    <Col sm={1}></Col>
                </Row>
                <hr></hr>
                <Row>
                    <Col style={{ textAlign: 'center', paddingTop: '0.4rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }}>Sustainability performance details</Col>
                </Row>
                
            </Card.Body>
            
        </Card>
      
    );
  }
}


const mapStateToProps = state => {
  return {
    risk: state.supplychain.risk,
    ndpe: state.supplychain.ndpe,
  };
}

export default connect(mapStateToProps, { getRiskPerMill, getNdpe })(NdpeWidget);
