import React from 'react';
import { connect } from 'react-redux';
import {  Row, Col, Card, ProgressBar, Button } from 'react-bootstrap';
import { getSupplyChainWidgetData, getByCountryVolumes, getRefineriesCount, navigateSelections } from '../../actions/index';
import history from '../header/history';
import { FaInfoCircle } from 'react-icons/fa';

class SupplyChainWidget extends React.PureComponent {

  componentDidMount() {
    this.props.getSupplyChainWidgetData();
    this.props.getByCountryVolumes();
    this.props.getRefineriesCount();
  }

  navigateToSupplyChainDetails = () => {
    this.props.navigateSelections('/supplychaindetails');
    history.push('/supplychaindetails');
  }

  renderVolumesByOrigin(item, index){
    let progressOpacity;
      if(index === 0){
        progressOpacity = 'SCProgress'
      }else if( index === 1){
        progressOpacity = 'SCProgress1'
      }else if (index===2){
        progressOpacity = 'SCProgress2'
      }else{
        progressOpacity = 'SCProgress3'
      }
      return(
        <ProgressBar style={{height:'1.5rem',backgroundColor: '#fff'}}>
            <ProgressBar  variant={progressOpacity} now={Math.round(item.percentage)} />
            <span style={{ marginLeft: '5px', fontSize: 16 }}><b>{`${Math.round(item.percentage)}%`}</b></span>
        </ProgressBar>
        )
  }

  render() {   
    return (
                    <Card style={{ width: '100%', boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0}}>
                        <Card.Body>
                        <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
                          <Col sm={10} style={{ fontSize: '1.5em' }}>Supply Chain</Col>
                          <Col sm={2} style={{textAlign:'right'}}>
                            <Button variant="light">
                              <FaInfoCircle size="1.3rem" />
                            </Button>
                          </Col>
                        </Row>
                            {/* <br></br>
                            <p style={{fontWeight:'16', paddingBottom:'0.5em'}}>Number of mills and origin refineries in your supply chain.</p> */}
                            
                            <Row style={{paddingTop:'0.5em'}}>
                                
                                <Col sm={2}><strong style={{ fontFamily: 'Impact,Charcoal', fontSize: 36, color:'#DAAA00' }}>{this.props.millcount.cargill_owned_mills_count}</strong></Col>
                                <Col sm={3}><strong style={{ fontFamily: 'Impact,Charcoal', fontSize: 36, color:'#DAAA00' }}>{this.props.millcount.thirdparty_mills_count}</strong></Col>
                                <Col sm={1} style={{borderLeft:'1px solid lightgray', paddingTop:'5px'}}></Col>
                                <Col sm={3}><strong style={{fontFamily: 'Impact,Charcoal', fontSize: 36, color:'#ABAD25'}}>{this.props.refineriesCount.cargill_owned_refineries_count}</strong></Col>
                                <Col sm={3}><strong style={{fontFamily: 'Impact,Charcoal', fontSize: 36, color:'#ABAD25'}}>{this.props.refineriesCount.thirdparty_refineries_count}</strong></Col>
                                
                            </Row>
                            <Row style={{paddingBottom:'0.5em', fontSize:'12px', borderBottom: '1px solid #dee2e6', paddingLeft: '1rem 0', paddingRight: '1rem 0', paddingTop: '1rem 0'   }}>
                                <Col sm={2}><p style={{fontSize:'12px'}}>Cargill Mills</p></Col>
                                <Col sm={3}><p style={{fontSize:'12px'}}>Third Party Mills</p></Col>
                                <Col sm={1} style={{borderLeft:'1px solid lightgray'}}></Col>
                                <Col sm={3}><p style={{fontSize:'12px'}}>Cargill Refineries</p></Col>
                                <Col sm={3}><p style={{fontSize:'12px'}}>Third Party Refineries</p></Col>
                            </Row>
                            <br></br>
                            <p style={{fontSize:'16px'}}>Volumes by country of origin</p>
                            
                                <Col sm={12} style={{padding:'1em'}} >
                                {this.props.volumes.map((item, index) => (
                                  <Row style={{padding:'5px'}} key={index}>
                                      <Col md={3} style={{marginTop: '-3px'}}>{item.load_country}</Col>
                                      <Col md={{ span: 9, offset: 0 }}>
                                        {this.renderVolumesByOrigin(item,index)}
                                      </Col>
                                  </Row>))}
                                </Col>
                                <hr></hr>
                                <Row>
                                  <Col style={{ textAlign: 'center', paddingTop: '0.4rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }} onClick={(e)=> this.navigateToSupplyChainDetails()}>Supply Chain Details</Col>
                                </Row>
                        </Card.Body>
                    </Card>
                
            
        
    );
  }
}


const mapStateToProps = state => {
  return {
    millcount: state.supplychain.millcount,
    volumes: state.supplychain.volumes,
    refineriesCount: state.supplychain.refineriesCount,
  };
}

export default connect(mapStateToProps, { getSupplyChainWidgetData, getByCountryVolumes, getRefineriesCount, navigateSelections })(SupplyChainWidget);
