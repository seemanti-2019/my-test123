import React from 'react';
import { connect } from 'react-redux';
import { getMillInfo } from '../../actions/index';
import C3Chart from 'react-c3js';
import 'c3/c3.css';
import { Col, Card, Form } from 'react-bootstrap';


class DeforestationFreeMills extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getMillInfo();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
      //  this.props.changeName();
  }
  


  render() {

    const dataPie = {
      columns: [
          ['Deforestation free', 88.84],
          ['Non deforestation free', 9.58],
          ['Unknown', 1.56],
      ],
      type: 'donut',
      
  };

  const legendPie = {
      position: 'right',
      item: {
          onclick: function () { }
      }
  };
  const colorPie = {
      pattern: ['#638C1C', '#A22B2F', '#64656A']
  };
  const sizePie = {
      height: 240,
      width: 480
  };

  const tooltipPie = {
      show: false
  };
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Deforestation free % of mills</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'16px'}}>
              In 2019 - Q2
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
            <C3Chart data={dataPie} legend={legendPie} color={colorPie} size={sizePie} tooltip={ tooltipPie} />
          </Col>

        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { getMillInfo })(DeforestationFreeMills);
