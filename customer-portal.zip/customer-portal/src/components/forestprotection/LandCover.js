import React from 'react';
import { connect } from 'react-redux';
import { changeName } from '../../actions/index';
import C3Chart from 'react-c3js';
import 'c3/c3.css';
import { Col, Card, Form } from 'react-bootstrap';
import { loadModules } from 'esri-loader';


class LandCover extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    loadModules(["esri/request"],{ css: true })
    .then(([esriRequest]) => {
        debugger
        let options = {
            query: {
              f: "json",
            //   token: "24mmjp4GRADlpoaGbLJO5cmpsBDNrSs2TXTsCor9X9_WSpTK6p7YsJL_RUu0-EdhkXyxbo2-W5l20Uf9aY5ZdTzV03VopMnrNt8hhO3tVshhBr5uiEah05zTclWTiyGZQILTHfxjHKxGbQYrFNGS4aOsEcuUYVP3fhCJ2mhchBCfvY85V35k4a1GNqAECSZi",
             //  PF_ID: "1517"
            },
            responseType: "json"
          };

          
         
          //let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/arcgis/rest/services/PW_Reuters_concessions_processed/FeatureServer/0/query?where=PF_ID=1000&outfields=*';
          let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/arcgis/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=PF_ID=1000&outfields=*'
          //let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/arcgis/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=1%3D1&outfields=*'
          //let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/PW_Palm_Mills_Buffer_50km/FeatureServer/0/query?where=1%3D1&returnCountOnly=true&token=1HlcfgCohz8Cwc8L_pKpSYDEEEWEJAMz1oMyrT2-UShJ1zosEBOIOHfzdL-7iFaQcMXSzwwI7o2IASsOAXFIQkgUj3LKnCPKNiAUMbhd94_LHJy5_XpmzKz8eMFxUq_geA5SOAW03PQd4iIa-SKCrKP0jjjBARvKm_CYnOOrFyYMsOV7HuoQ6O2IQqwAUyPgR3yAQhqoEo88tUxoScyeNBCtakakXdw5yATryv5tWk4mH4yn9eipoI6mglev7PYD';
          //let url = 'https://services3.arcgis.com/Ax6lXluGmqEBX6ju/arcgis/rest/services/PW_Reuters_Glads_Alerts/FeatureServer/0/query?where=PF_ID=1000&outfields=*'

          esriRequest(url, options).then(function(response) {
            // In this case, we simply print out the response to the page.
            debugger
            let responseJSON = JSON.stringify(response, null, 2);
            console.log(response);
           console.log(responseJSON);
          });
  });
 }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
      //  this.props.changeName();
  }
  


  render() {

    const dataPie = {
      columns: [
          ['Primary Forest', 5.95],
          ['Peatland', 5.07],
          ['Palm', 51.51],
          ['Primary and Intact Forest',5.56],
          ['Other', 31.91],
      ],
      type: 'donut',
  };

  const legendPie = {
      position: 'right',
      item: {
          onclick: function () { }
      }
  };
  const colorPie = {
      pattern: ['#19988B', '#DDAA02', '#ABAD25', '#C2531C', '#64656A']
  };
  const sizePie = {
      height: 240,
      width: 480
  };

  const tooltipPie = {
      show: false
  };
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Land cover</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'16px'}}>
              In 2019 - Q2
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
            <C3Chart data={dataPie} legend={legendPie} color={colorPie} size={sizePie} tooltip={ tooltipPie} />
          </Col>

        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(LandCover);
