import React from 'react';
import { connect } from 'react-redux';
import { changeName, navigateSelections } from '../../actions/index';
import history from '../header/history';
import { Row, Col, CardDeck, Button } from 'react-bootstrap';
import LandCover from './LandCover';
import FreeMills from './DeforestationFreeMills';
import Map from './ForestProtectionMap';
import TotalArea from './TotalAreaOfDeforestation';

class ForestProtection extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
    this.props.navigateSelections('/home');
    history.push('/home');
  }
  


  render() {
    
    return (
      <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
        <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
          <Col>
            <Row>
            <Button variant="link" style={{color: '#A5A5A5', fontSize: '18px', fontWeight: '600'}} onClick={(e)=> this.test1()}>Home</Button>
            <div style={{borderLeft: '3px solid lightgray', height: '30px', marginTop:'5px'}}></div>
            <Button variant="link" style={{color: '#000', fontSize: '18px', fontWeight: '600'}}>Forest Protection</Button></Row>
          </Col>
        </Row>
        <CardDeck style={{padding:'1.5em'}}>
          <FreeMills/>
          <LandCover/>
          <TotalArea/>
        </CardDeck>
        <CardDeck style={{padding:'1.5em'}}>
          <Map/>
        </CardDeck>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName, navigateSelections })(ForestProtection);
