import React from 'react';
import C3Chart from 'react-c3js';
import { connect } from 'react-redux';
import { getTotalAreaOfDeforestation } from '../../actions/index';


import { Col, Card, Form } from 'react-bootstrap';



class TotalAreaOfDeforestation extends React.PureComponent {
    //chartData.unshift('data1');
    constructor(props) {
        super(props);
        this.state = {
          isLoading: false,
        }
    
      }
    
      componentDidMount() {
        this.props.getTotalAreaOfDeforestation();
    }
    
    render() {
  
    // let chartColumn = ['data1'];
    // this.props.TotalAreaOfDeforestation.map((item)=> {
    //     chartColumn.push(item)
    // });
    const data = {
        columns: [
            ['data1', 200, 210, 190, 220, 200, 240, 190, 220],
        ],
        color: {
            data1: 'black',
        }
    };
    const size = {
        height: 300,
        width: 400
    }
    const point = {
        r: 6,
    }
    const tooltip = {
        show: false
    }
    const legend = {
        show: false,
    }
    const padding = {
        top: 100,
    }
    const axis = {
        x: {
            label: {
                text: 'Time',
                position: 'outer-middle',
            },            
        },
        y: {
            label: {
                text: 'Surface(ha)',
                position: 'outer-middle'
            },
            tick: {
                values: [100, 150, 200, 250, 300, 350],
            },
            padding: {
                top: 150,
                bottom: 150
            },

        }
    }
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Total area of deforestation (Verified alerts)</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'16px'}}>
              In 2019 - Q2
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
          <C3Chart data={data} tooltip={tooltip} axis={axis} legend={legend} point={point} size={size} padding={padding}></C3Chart>
          </Col>

        </Card.Body>
        </Card>

        // <C3Chart data={data} tooltip={tooltip} axis={axis} legend={legend} point={point} size={size} padding={padding}></C3Chart>
    );

}
}

const mapStateToProps = state => {
    return {
      name: state.home.name,
    };
  }
  
export default connect(mapStateToProps, { getTotalAreaOfDeforestation })(TotalAreaOfDeforestation);


