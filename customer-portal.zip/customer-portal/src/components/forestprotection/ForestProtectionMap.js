import React from 'react';
import { connect } from 'react-redux';
import { loadModules } from 'esri-loader';
import { changeName } from '../../actions/index';
import { Col, Card, Form } from 'react-bootstrap';


class ForestProtectionMap extends React.PureComponent {

  constructor(props) {
    super(props);
    this.mapRef = React.createRef();
  }

  componentDidMount() {
    
    // lazy load the required ArcGIS API for JavaScript modules and CSS
    loadModules(['esri/Map', 'esri/views/MapView','esri/layers/FeatureLayer', 'esri/identity/OAuthInfo','esri/identity/IdentityManager'], { css: true })
    .then(([ArcGISMap, MapView, FeatureLayer, OAuthInfo, esriId]) => {

      // var info = new OAuthInfo({
      //   appId: "afK3xSvrDWPsYpXq",
      //   popup: false
      // });
    
      // esriId.registerOAuthInfos([info]);

      
      // esriId.checkSignInStatus(info.appId + "/sharing")
      //     .then(function() {
      //       alert('logged in')
      //     })
      //     .catch(function(){
      //       alert('login with')
      //     });

      const map = new ArcGISMap({
        basemap: 'hybrid'
      });

      this.view = new MapView({
        container: this.mapRef.current,
        map: map,
        center: [-118, 34],
        zoom: 8,
        extent: {
          xmin: 10619103.2138008,
          ymin: -567029.558444957,
          xmax: 15620662.5107728,
          ymax: 572201.801096851,
          spatialReference: 102100,
        }
      });

      let template = {
        // autocasts as new PopupTemplate()
        title: "{PF_millname} in {PF_country} ID {PF_ID}",
        content: populationChange,
      };

      let renderer = {
        type: "simple",
        field: "mag",
        symbol: {
          type: "simple-marker",
          color: "#2CBAF2",
          outline: {
            color: "white"
          }
        },}
//SUS_ASIA_PALM_Mills
      let featureLayer = new FeatureLayer({
        url:
          "https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/PW_World_Mills/FeatureServer/0?token=C6shePbL4SM0nS_iujrgA_pyeJBp5VxalIyz153elMLaTKnUJ7AfWListl46Mjf42xj0YNGWh3yEgGg6qBr2oFYf62gVCi_08DabsBxh2D7Wef2N4r8yixDH25UaEJ-4et9uQ_z6zjK4N8rjOawEG-Inv7YkQ3GwHTXa9o85yB4i05AhUkakCiyC0yHCrxy9",
          popupTemplate: template,
          renderer: renderer
      });

    //   let featureLayer = new FeatureLayer({
    //     url:"https://services3.arcgis.com/Ax6lXluGmqEBX6ju/ArcGIS/rest/services/SUS_PALM_CONCESSIONS/FeatureServer/0?token=GPUWzlXW3HWABsCu-DKVhB0jeQosQy4kURC_dUqO01jbSgLj_4abzdV7C3E8-GsL0hlBE8rI4_VkbX3mVeZ_xnpSCrWbTUYJV2iViSdMvYQ5XV3eSM3QRzbH-jgY-yTosqrfZKBN3n9lVxXIssMp76VSBeHNNBkEwgqc0O5tkP6gqCSnMVtTMiOAOrzUWie5&f=json&PF_ID=1676",
    //     popupTemplate: template
    //   })
      map.add(featureLayer)

    //   this.view.when(function() {
    //       var query = featureLayer.createQuery();
    //       featureLayer.queryFeatures(query)
    //       featureLayer.definitionExpression = "PF_ID = 1676";
    //   })

      function populationChange (feature) {
   
      //  alert(feature.graphic.attributes.PF_ID)
        
        // this.view.when(function() {
        //   var query = featureLayer.createQuery();
        //   featureLayer.queryFeatures(query)
        //   featureLayer.definitionExpression = "PF_ID = 1575";
        //   var wellsGeometries = feature.map(function(feature1) {
        //     return feature1.geometry;
        //   });

        // })
        
        
      }

      
    });

    
  }

  componentWillUnmount() {
    if (this.view) {
      // destroy the map view
      this.view.container = null;
    }
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
      //  this.props.changeName();
  }
  


  render() {
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Forest Map</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'14px'}}>
              The map below allows you to monitor land development around the mills in your supply chain. You can see mills and refineries and select relevant land covers.
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
            <div className="webmap" ref={this.mapRef} />
          </Col>

        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(ForestProtectionMap);
