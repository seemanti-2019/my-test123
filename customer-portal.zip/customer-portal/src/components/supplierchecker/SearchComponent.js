import React from 'react';
import { connect } from 'react-redux';
import { IconContext } from 'react-icons';
import { InputGroup, FormControl, Modal, Button } from 'react-bootstrap';
import SupplyChecker from './supplyChecker';
import { getSupplyCheckerSearchData, setSearchResult } from '../../actions/index';
import { IoMdSearch } from 'react-icons/io';



class SearchExampleStandard extends React.PureComponent {
  constructor(props) {
    super(props)
    this.state = {
      isLoading: false,
      show: false,
      supplierName: false,
      showSearchItem: false
    }
  }

  componentDidMount() {
    this.props.getSupplyCheckerSearchData();
  }

  showSearch = () => {
    this.setState({ showSearchItem: true });
  }
  hideSearch = () => {
    this.setState({ showSearchItem: false });
  }
  clickedItem = (item) => {
    this.setState({ supplierName: item });
    this.showModal();
    this.setState({ isLoading: false });
  }

  renderResults = () => {
    return this.props.searchData.map((item, index) => {
      return <li key={index} className="search-item" onClick={() => this.clickedItem(item.harmonized_supplier_name)}>{item.harmonized_supplier_name}</li>
    })
  }

  setFilter = (event) => {
    if (event.target.value.length > 2) {
      this.props.setSearchResult(event);
      this.setState({ isLoading: true });
    } else {
      this.setState({ isLoading: false });
    }
  }
  showModal = () => {
    this.refs.input.value = '';
    this.setState({ show: true })
  }
  closeModal = () => {
    this.setState({ show: false })
  }


  handleClick = () => {
    if (!this.state.showSearchItem) {
      document.addEventListener('click', this.handleOutsideClick, false);
    } else {
      document.removeEventListener('click', this.handleOutsideClick, false);
    }
    this.setState(prevState => ({
      showSearchItem: !prevState.showSearchItem,
    }));
  }

  handleOutsideClick = (e) => {
    if(this.node){
    if (this.node.contains(e.target)) {
      return;
    }}
    this.setState({ isLoading: false });
    this.handleClick();
  }

  render() {
    if (this.props.searchData.length === 0) {
      this.setState({ isLoading: false });
    }
    return (
      <div>
        <div ref={node => { this.node = node }}>
        {(!this.state.showSearchItem) ?
          <div style={{ backgroundColor: 'white', padding: '.8rem', borderRadius: '5px', boxShadow: '0 5px 10px -6px #33333359', cursor: 'pointer',float: 'right' }} onClick={this.handleClick} >
            <IoMdSearch size="1.5em" /><span style={{ paddingLeft: '1rem' }}>Find Your Supplier</span>
          </div>:''
        } 
        {(this.state.showSearchItem) ?
          <div style={{ boxShadow: '0 5px 15px -6px #33333359', backgroundColor: 'white', zIndex: '99', width: '60%', float: 'right',}}>

            <InputGroup style={{ height: '3.3rem', padding: '.3rem 0 0 .4rem' }}>
              <FormControl style={{ border: 'none' }} aria-describedby="basic-addon1" ref="input" placeholder="Find Your Supplier" onChange={this.setFilter} />
              <InputGroup.Prepend>
                <div style={{ padding: '6px' }}>
                  <IconContext.Provider value={{ size: '25px' }}>
                    <div>
                      <IoMdSearch size="1.5em" />
                    </div>
                  </IconContext.Provider></div>
              </InputGroup.Prepend>
            </InputGroup>
            {(this.state.isLoading) ?
              <div className="filter-list"  style={{width: '100%'}}>
                <ul className="search-container">{this.renderResults()}</ul>
              </div> : ""}
          </div> : ''
        }
        </div>
        <div className="modal-container" style={{ width: "800px" }}>
          <Modal
            size="xl"
            show={this.state.show}
            onHide={() => this.closeModal()}
            aria-labelledby="contained-modal-title"
          >
            <Modal.Header closeButton>
              <Modal.Title id="contained-modal-title">Supply Checker</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <SupplyChecker supplierName={this.state.supplierName} />
            </Modal.Body >
            <Modal.Footer>
              <Button variant="outline-dark" onClick={() => this.closeModal()}>Close</Button>
            </Modal.Footer>
          </Modal>
        </div>
      </div>
    )
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
    searchData: state.home.searchData
  };
}

export default connect(mapStateToProps, { getSupplyCheckerSearchData, setSearchResult })(SearchExampleStandard);
