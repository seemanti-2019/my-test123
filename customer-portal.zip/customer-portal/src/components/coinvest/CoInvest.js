import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Button, Card, CardDeck } from 'react-bootstrap'
import { changeName, navigateSelections, getCoInvestProgramData } from '../../actions/index';
import history from '../header/history';



class CoInvest extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false
    }
  }

  componentDidMount() {
    this.props.getCoInvestProgramData();
  }

  showHome = () => {
    this.props.navigateSelections('/home');
    history.push('/home');
  }

  showDetails = (val) => {
    history.push(`/coinvestdetails/${val.id}`);
  }

  render() {
    return (
      <div style={{ padding: '1em 1rem 7rem 1rem', backgroundColor: '#F5F5F5' }}>
        <Row style={{ paddingTop: '1em', paddingLeft: '2em', paddingRight: '1.5em' }}>
          <Col>
            <Row>
              <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.showHome()}>Home</Button>
              <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
              <Button variant="link" style={{ color: '#000', fontSize: '18px', fontWeight: '600' }}>CoInvest</Button></Row>
          </Col>
        </Row>
        <Row style={{ marginLeft: '5px',marginRight: '-100px'}}>
        {
          this.props.coinvest.map((item,i) => {
            return (
              <CardDeck key={i} style={{ padding: '1.5em',width: '33%', float: 'left',minHeight: '300px'}}>
                <Card>
                  <Card.Body>
                    <Col sm={12} style={{ padding: '4rem 3rem', textAlign: "center", verticalAlign: "middle", fontSize: "1.4em", cursor: 'pointer' }} >
                      <span onClick={() => this.showDetails(item)}>{item.program}</span>
                    </Col>
                  </Card.Body>
                </Card>
              </CardDeck>
              )
          })
        }
        </Row>
      </div >
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
    coinvest: state.coinvest.programData,
  };
}

export default connect(mapStateToProps, { changeName, navigateSelections, getCoInvestProgramData })(CoInvest);
