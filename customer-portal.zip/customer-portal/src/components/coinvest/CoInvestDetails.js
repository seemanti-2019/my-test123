import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Button, Card, CardDeck } from 'react-bootstrap'
import { changeName, navigateSelections, getCoInvestProgramData } from '../../actions/index';
import history from '../header/history';

class CoInvest extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
        }
    }
    componentDidMount() {
        this.props.getCoInvestProgramData();

    }
    test1 = () => {
        this.props.navigateSelections('/home');
        history.push('/home');
    }

    render() {
        let currentData= this.props.coinvest.filter((item) => item.id === +this.props.id);
        currentData = currentData[0];
        return (
            <div style={{ padding: '1em 1rem 12rem 1rem', backgroundColor: '#F5F5F5' }}>
                <Row style={{ paddingTop: '1em', paddingLeft: '2em', paddingRight: '1.5em' }}>
                    <Col>
                        <Row>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test1()}>Home</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#000', fontSize: '18px', fontWeight: '600' }}>CoInvest</Button>
                        </Row>
                    </Col>
                </Row>
                <Row style={{ padding: '2.6rem' }}>
                    <h1>{(currentData)?(currentData.program):''}</h1>
                </Row>
                <Row style={{ padding: '0 2.6rem' }}>
                    <h3>Specific Activities</h3>
                </Row>
                {(currentData)? (currentData.details.map(item => {
                return (
                <CardDeck>
                    <Card style={{ margin: '1rem 2.6rem', padding: "1em" }}>
                        <Card.Body>
                            <Row>
                                <Col md={4}>
                                    <h4 style={{ marginBottom: "4rem", paddingRight: "6rem" }}>{item.activity}</h4>
                                    <p style={{ marginBottom: "1rem" }}>
                                        <strong>Country :</strong>
                                        <span style={{ paddingLeft: '1rem' }}>{item.countries}</span>
                                    </p>
                                    <p style={{ marginTop: "0", marginBottom: "1rem" }}>
                                        <strong>Status :</strong>
                                        <span style={{ paddingLeft: '1rem' }}>{item.status}</span>
                                    </p>
                                    <Row>
                                        <Button variant="dark" style={{margin:'3px'}}>See project</Button>
                                        <Button variant="dark" style={{margin:'3px'}}>Download statement</Button>
                                        <Button variant="dark" style={{margin:'3px'}}>Contact</Button>
                                    </Row>
                                </Col>
                                <Col md={6}>
                                    <strong>Objective</strong>
                                    <p>{item.objective}</p>
                                    <strong>Benefit</strong>
                                    <p>{item.customerValue}</p>
                                </Col>
                                <Col md={2} style={{ textAlign: "right" }}>
                                    <strong>{item.projectBudget}</strong>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                 </CardDeck>
                )   
                })
                ):''}
            </div>
        )
    }

}
const mapStateToProps = state => {
    return {
        name: state.home.name,
        coinvest: state.coinvest.programData
    };
}

export default connect(mapStateToProps, { changeName, navigateSelections, getCoInvestProgramData })(CoInvest);
