import React from 'react';
import { connect } from 'react-redux';
import { Card, Row, Col, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { changeName, navigateSelections } from '../../actions/index';
import history from '../header/history';
import { FaInfoCircle } from 'react-icons/fa';
import { FiArrowUpRight } from 'react-icons/fi';



class Infowidget extends React.PureComponent {

    navToCoinvest = () => {
        this.props.navigateSelections('/coinvest');
        history.push('/coinvest');
    }

    render() {

        return (
            <Card style={{height: 'fit-content',boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0 }}>
                <Card.Body>
                    <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
                        <Col>
                            <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>How Cargill is taking action</div>
                            <div style={{ float: 'right' }}>
                                <Button variant="light">
                                    <OverlayTrigger
                                        key={'top'}
                                        placement={'top'}
                                        overlay={
                                            <Tooltip id="">
                                                Tackling deforestation through Landscape Approaches.
                                        </Tooltip>
                                        }>
                                        <FaInfoCircle size="1.3rem" />
                                    </OverlayTrigger>
                                </Button>
                            </div>
                        </Col>
                    </Row>
                    <div style={{ paddingTop: '10px' }}>
                        <Row>
                            <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1rem 0'}}>
                                <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}><FiArrowUpRight size="1.5em" color="DDAA01" /></div>
                                <div style={{display:"inline",float:"left",width:"60%" }}>Cargill Initiative
                                <p style={{ fontSize: 12,color: 'grey', paddingTop: '.6rem' }}>April 22,2020</p>
                                </div>
                                <div style={{display:"inline",float:"right",width:"20%",textAlign: "center" }}>&gt;</div>
                            </Col>
                        </Row>
                        <Row>
                            <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1rem 0'}}>
                                <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}><FiArrowUpRight size="1.5em" color="DDAA01" /></div>
                                <div style={{display:"inline",float:"left",width:"60%" }}>Cargill Initiative
                                <p style={{ fontSize: 12,color: 'grey', paddingTop: '.6rem' }}>April 22,2020</p>
                                </div>
                                <div style={{display:"inline",float:"right",width:"20%",textAlign: "center" }}>&gt;</div>
                            </Col>
                        </Row>
                        <Row>
                            <Col style={{ padding: '1rem 0'}}>
                                <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}><FiArrowUpRight size="1.5em" color="DDAA01" /></div>
                                <div style={{display:"inline",float:"left",width:"60%" }}>Cargill Initiative
                                <p style={{ fontSize: 12,color: 'grey', paddingTop: '.6rem' }}>April 22,2020</p>
                                </div>
                                <div style={{display:"inline",float:"right",width:"20%",textAlign: "center" }}>&gt;</div>
                            </Col>
                        </Row>
                    </div>
                    <Row style={{ borderTop: '1px solid #dee2e6' }}>
                        <Col style={{ textAlign: 'center', paddingTop: '1rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }} onClick={this.navToCoinvest}>View all initiatives</Col>
                    </Row>
                </Card.Body>
            </Card>
        );
    }
}


const mapStateToProps = state => {
    return {
        name: state.home.name,
    };
}

export default connect(mapStateToProps, { changeName, navigateSelections })(Infowidget);
