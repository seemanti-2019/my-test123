import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { getDownloadData, downloadMillList } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';
import { MdFileDownload } from "react-icons/md";

class Downloads extends React.PureComponent {

  componentDidMount() {
    this.props.getDownloadData();
  }


  downloadMillList = (e) => {
    e.preventDefault();
    this.props.downloadMillList();
  }

  render() {
    return (
      <Card style={{ height: 'fit-content',boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
          <Col>
              <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>Downloads</div>
              <div style={{ float: 'right' }}>
              <Button variant="light" style={{ marginRight: '.2rem' }}>
                <MdFileDownload size="1.5em" onClick={(e) => this.downloadMillList(e)}/>
              </Button>
              <Button variant="light">
              <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                     Downloads
                    </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
              </div>
            </Col>
          </Row>
          <div style={{ paddingTop: '10px' }}>
                <Row>
                  <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1rem 0'}}>
                    <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}>
                      <a style={{ color: 'black',cursor: 'pointer' }} rel="noopener noreferrer" onClick={(e) => this.downloadMillList(e)}>
                          <MdFileDownload size="1.5em" color="DDAA01" />
                      </a>
                    </div>
                    <div style={{display:"inline",float:"left",width:"70%" }}>
                      <a style={{ color: 'black',cursor: 'pointer' }} rel="noopener noreferrer" onClick={(e) => this.downloadMillList(e)}>
                        Cargill’s Mill List 2019 - Quarter 2
                      </a>
                      <p style={{ fontSize: 12, color: 'grey', paddingTop: '.6rem' }}>Aug 2,2019</p>
                    </div>
                  </Col>
                </Row>
            {this.props.downloads.map((item, index) => (
              <div key={index}>
                <Row>
                  <Col style={(index < 1) ? { borderBottom: "1px solid #dee2e6",  padding: '1rem 0' } : {  padding: '1rem 0'}}>
                    <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}>
                      <a style={{ color: 'black' }} rel="noopener noreferrer" href={item.link} target="_blank">
                        <MdFileDownload size="1.5em" color="DDAA01" />
                      </a>
                    </div>
                    <div style={{ display: "inline", float: "left", width: "70%" }}>
                      <a style={{ color: 'black' }} rel="noopener noreferrer" href={item.link} target="_blank">{item.name}</a>
                      <p style={{ fontSize: 12, color: 'grey', paddingTop: '.6rem' }}>April 22,2020</p>
                    </div>
                  </Col>
                </Row>
                </div>
                ))}
             </div>
          <Row style={{ borderTop: '1px solid #dee2e6' }}>
            <Col style={{ textAlign: 'center', paddingTop: '1rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }}>View all downloads</Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    downloads: state.home.downloads,
  };
}

export default connect(mapStateToProps, { getDownloadData, downloadMillList })(Downloads);
