import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, OverlayTrigger, Tooltip, ProgressBar,Button } from 'react-bootstrap';
import { getMyVolumeData } from '../../actions/index';
import { FaInfoCircle, FaPercent } from 'react-icons/fa';
import { MdFileDownload } from "react-icons/md";



class VolumeWidget extends React.PureComponent {

  componentDidMount() {
    this.props.getMyVolumeData();
  }
  
  renderPalm(data){
    return data.map((item, i) => {
      if((item.hasOwnProperty('product_group')) && (item.product_group  === 'Palm')){
      return (
        <div key={i} style={{ paddingTop: '0.5em', paddingBottom: '0.5em' }}>
         <ProgressBar style={{ height: '1.5rem', fontWeight: 'bold' }}>
          <ProgressBar variant="customProgress2" style={{ height: '1.5rem' }} key={i} now={Math.round(item.value)} label={(Math.round(item.value) > 20) ? Math.round(item.value) + '%' : ''} />
          {(Math.round(item.value) <= 20) ? (<span style={{ paddingLeft: '5px' }}>{`${Math.round(item.value)}%`}</span>) : ''} 
        </ProgressBar>
        </div>
      )} else {
        return ('');
      }
    })
  }

  renderKernal(data){
    return data.map((item, i) => {
      if((item.hasOwnProperty('product_group')) && (item.product_group  === 'Kernel')){
      return (
        <div  key={i} style={{paddingTop:'0.5em', paddingBottom:'0.5em'}}>
          <ProgressBar style={{ height: '1.5rem', fontWeight: 'bold' }}>
            <ProgressBar variant="customProgress" style={{height:'1.5rem'}} key={i}  now={Math.round(item.value)} label={(Math.round(item.value) > 20) ? Math.round(item.value) + '%' : ''}  />
            {(Math.round(item.value) <= 20) ? (<span style={{ paddingLeft: '5px' }}>{`${Math.round(item.value)}%`}</span>) : ''}
          </ProgressBar>
        </div>
      )} else {
        return ('');
      }}
    )
  }

renderVolumesData(){
   return this.props.volumes.productVolumes.map((item, i) => {
    return (
      <Row key={i}>
        <Col>
          <div style={{display:"inline",float:"left",width:"37%"}}>{this.renderPalm(item.volume)}</div>
          <div style={{display:"inline",float:"left",width:"26%",padding:'0.3em 0 0.2em 0',textAlign:"center"}}>{item.product_classification}</div>
          <div style={{display:"inline",float:"right",width:"37%"}}>{this.renderKernal(item.volume)}</div>
        </Col>
      </Row>
    )}
   )
}

  render() {    
    return (
        <Card style={{ width: '100%', height: 'fit-content',boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0  }}>
          <Card.Body style={{marginBottom:'.8rem'}}>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col>
              <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>Volume</div>
              <div style={{ float: 'right' }}>
                <Button variant="light" style={{ marginRight: '.2rem' }}>
                  <FaPercent size="1em" />
                </Button>
                <Button variant="light" style={{ marginRight: '.2rem' }}>
                  <MdFileDownload size="1.5em" />
                </Button>
                <Button variant="light">
                  <OverlayTrigger
                    key={'top'}
                    placement={'top'}
                    overlay={
                      <Tooltip id="111">
                        The proportion of volumes sold to you by Cargill by certification types
                    </Tooltip>
                    }>
                    <FaInfoCircle size="1.3rem" />
                  </OverlayTrigger>
                </Button>
              </div>
            </Col>
          </Row>
          <Row style={{ paddingBottom: '2rem', marginTop: '2.3rem' }}>
            <Col>
              <div style={{ display: "inline", width: "60%", float: "left", paddingLeft: ".5rem" }}>
                <span style={{
                  height: '12px',
                  width: '12px',
                  backgroundColor: '#DDAA01',
                  borderRadius: '50%',
                  display: 'inline-block', marginRight: '1rem'
                }}></span>
                 Palm %
                <p style={{ margin: '.5rem 0 0 1.5rem ', color: 'grey', fontSize: 14 }}>
                  {this.props.volumes.palmMT.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} metric ton
                </p>
              </div>
              <div style={{ float: "left", width: "40%", paddingLeft: ".5rem" }}>
                <span style={{
                  height: '12px',
                  width: '12px',
                  backgroundColor: '#b3b300',
                  borderRadius: '50%',
                  display: 'inline-block', marginRight: '1rem'
                }}></span>
                  Kernel %
                <p style={{ margin: '.5rem 0 0 1.5rem ', color: 'grey', fontSize: 14 }}>
                  {this.props.volumes.kernalMT.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} metric ton
                </p>
              </div>
            </Col>
          </Row>
            {this.renderVolumesData()}
           </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    volumes: state.home.volumes,
  };
}

export default connect(mapStateToProps, { getMyVolumeData })(VolumeWidget);
