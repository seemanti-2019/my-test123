import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, OverlayTrigger, Tooltip, Image } from 'react-bootstrap';
import { getFootPrintData, updateFootPrintFlow, getMapData, getRefineriesCount, getSupplyChainWidgetData } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';
import { BsArrowRight } from 'react-icons/bs';
import { FiZoomIn, FiZoomOut } from 'react-icons/fi';
import { MdMyLocation } from 'react-icons/md';
import {
  ComposableMap,
  Geographies,
  Geography,
  Line, Marker, ZoomableGroup,
} from "react-simple-maps";
import { scaleQuantize } from "d3-scale";

const colorScale = scaleQuantize()
  .domain([1, 10])
  .range([
    "#DBDCDD",
    "#ffcec5",
    "#ffad9f",
    "#ff8a75",
    "#ff5533",
    "#e2492d",
    "#be3d26",
    "#9a311f",
    "#DBDCDD"
  ]);


class Footprint extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      displayLines: false,
      zoom: 1
    }
  }

  componentDidMount() {
    this.props.getMapData();
    this.props.getFootPrintData();
    this.props.getRefineriesCount();
    this.props.getSupplyChainWidgetData();
  }

  onCountryClick = (selection) => {
    this.props.updateFootPrintFlow(selection, this.props.footprint);
    if (this.state.displayLines) {
      this.setState({ displayLines: false })
    } else {
      this.setState({ displayLines: true })
    }
  }

  visulaizeDataFlow = () => {
    this.props.updateFootPrintFlow('', this.props.footprint);
    if (this.state.displayLines) {
      this.setState({ displayLines: false })
    } else {
      this.setState({ displayLines: true })
    }
  }

  renderLoadCountries(colorCode) {

    return this.props.footprint.map((item, i) => {
      return (
        <OverlayTrigger
          key={i}
          placement={'top'}
          overlay={
            <Tooltip id={i}>
              <div style={{ padding: '.5rem', textAlign: 'left', fontSize: '.8em' }}>
                <p style={{ marginBottom: '.5rem' }}>{item.load_location}</p>
                <div style={{ width: '100%', borderBottom: '1px solid lightgrey', marginBottom: '.5rem' }}></div>
                <p>{item.load_country}</p>
              </div>
            </Tooltip>
          }>
          <Marker key={i} coordinates={[item.load_location_longitude, item.load_location_latitude]} onClick={() => this.onCountryClick(item.load_country)}>
            <circle r={8} fill="#DDAA01" stroke='#fff' strokeWidth={2} />
          </Marker>
        </OverlayTrigger>
      )
    }
    )
  }

  renderDestinationCountries() {

    return this.props.footprint.map((item, i) => {
      var sourceCountries = [];
      for (var j = 0; j < this.props.footprint.length; j++) {
        if (this.props.footprint[j].destination_location === item.destination_location) {
          sourceCountries[j] = this.props.footprint[j].load_country;
        }
      }
      return (
        <OverlayTrigger
          key={i}
          placement={'top'}
          overlay={
            <Tooltip id={i}>
              <div style={{ padding: '.5rem', textAlign: 'left', fontSize: '.8em' }}>
                <p style={{ fontWeight: 'bold', marginBottom: '.5rem' }}>{item.destination_location} refinery</p>
                <div style={{ width: '100%', borderBottom: '1px solid lightgrey', marginBottom: '.5rem' }}></div>
                <p style={{ fontWeight: 'bold' }}>Origin source:</p>
                {sourceCountries.map(country => {
                  return (
                    <p>{country}</p>
                  )
                })}
                <div style={{ width: '100%', borderBottom: '1px solid lightgrey', marginBottom: '.5rem' }}></div>
                <p style={{ fontWeight: 'bold' }}>RSPO certified refinery</p>
              </div>
            </Tooltip>
          }>
          <Marker key={i} coordinates={[item.destination_location_longitude, item.destination_location_latitude]} onClick={() => this.onCountryClick(item.destination_location)}>
            <circle r={8} fill="#b3b300" stroke='#fff' strokeWidth={2} />
          </Marker>
        </OverlayTrigger>
      )
    }
    )
  }

  drawFlow(display) {
    if (display) {
      return this.props.footprintflow.map((item, i) => {
        return (
          <Line
            key={i}
            from={[item.load_location_longitude, item.load_location_latitude]}
            to={[item.destination_location_longitude, item.destination_location_latitude]}
            stroke="black"
            strokeWidth={2}
            strokeLinecap="round"
            markerEnd={(item.destination_Market !== item.load_country) ? 'url(#head)' : ''}
          />
        )
      }
      )
    }
  }

  handleZoomIn = () => {
    this.setState({
      zoom: this.state.zoom * 1.2,
    });
  }
  handleZoomOut = () => {
    this.setState({
      zoom: this.state.zoom / 1.2,
    });
  }

  render() {

    return (
      <Card className="footprint" style={{ heigth: 'fit-content', width: '100%', boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col>
              <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>My Footprint</div>
              <div style={{ float: 'right' }}>
                <Button variant="light">
                  <OverlayTrigger
                    key={'top'}
                    placement={'top'}
                    overlay={
                      <Tooltip id="">
                        Select your destination markets to see flows in your supply chain
                    </Tooltip>
                    }>
                    <FaInfoCircle size="1.3rem" />
                  </OverlayTrigger>
                </Button>
              </div>
            </Col>
          </Row>
          <Row style={{ paddingTop: '1rem' }}>
            <Col style={{ textAlign: "right" }}>
              <span className='black-legend'></span>
              <span style={{ paddingLeft: '10px', paddingRight: '35px' }}>Cargill refineries</span>
              <span className='blue-legend'></span>
              <span style={{ paddingLeft: '10px', paddingRight: '35px' }}>Origin countries</span>
              <BsArrowRight size="2em" />
              <span style={{ paddingLeft: '10px', paddingRight: '35px' }}>Palm flow</span>
            </Col>
          </Row>
          {/* <div style={{ width: '15%', border: 0, borderRadius: 0, verticalAlign: 'center', position: 'absolute', top: '20%' }}>
            <Row>
              <Col sm={4} style={{ textAlign: 'right', paddingTop: '.5rem' }}><Image src={require("../../assets/Icon_Mill.png")} style={{ cursor: 'pointer' }} /></Col>
              <Col sm={4} style={{ paddingLeft: 0 }}>
                <span style={{ fontFamily: 'Impact,Charcoal', fontSize: '2.4vw', color: '#DDAA01' }}>{this.props.millcount.total_count}</span>
              </Col>
            </Row>
            <Row>
              <Col sm={4}></Col>
              <Col sm={4} style={{ borderBottom: '1px solid lightgrey', paddingLeft: 0, paddingBottom: '1em' }}>Mills</Col>
            </Row>
            <Row >
              <Col sm={4} style={{ textAlign: 'right', paddingTop: '.5rem' }}><Image src={require("../../assets/Icon_Refinery.png")} style={{ cursor: 'pointer' }} /></Col>
              <Col sm={5} style={{ paddingLeft: 0 }}>
                <span style={{ fontFamily: 'Impact,Charcoal', fontSize: '2.4vw', color: '#0b8e4d' }}>{this.props.refineriesCount.total_count}</span>
              </Col>
            </Row>
            <Row>
              <Col sm={4}></Col>
              <Col sm={5} style={{ paddingLeft: 0 }}>Refineries</Col>
            </Row>
          </div> */}
          <Row>
            <div style={{
              border: 0, borderRadius: 0,
              verticalAlign: 'center', position: 'absolute', top: '20%', padding: '1rem', lineHeight: 3, left: '1rem',zIndex: 1
            }}>
              <Row>
                <Col>
                  <div style={{ display: "inline", float: "left" }}><Image src={require("../../assets/Icon_Mill.png")} style={{ cursor: 'pointer' }} /></div>
                  <div style={{ display: "inline", float: "left",lineHeight:1,paddingTop:".5em" }}>
                    <p style={{ fontFamily: 'Impact,Charcoal', fontSize: '2.4vw', color: '#DDAA01' }}>{this.props.millcount.total_count}</p>
                    <p style={{ borderBottom: '1px solid lightgrey' }}>Mills</p>
                  </div>
                </Col>
              </Row>
              <Row>
                <Col>
                  <div style={{ display: "inline", float: "left" }}><Image src={require("../../assets/Icon_Refinery.png")} style={{ cursor: 'pointer' }} /></div>
                  <div style={{ display: "inline", float: "left",lineHeight:1,paddingTop:".5em"  }}>
                    <p style={{ fontFamily: 'Impact,Charcoal', fontSize: '2.4vw', color: '#0b8e4d' }}>{this.props.refineriesCount.total_count}</p>
                    <p>Refineries</p>
                  </div>
                </Col>
              </Row>
            </div>
            <Col>
              <ComposableMap style={{ height: '550px', width: '100%', top: '0px' }} data-tip="" projectionConfig={{ scale: 220 }} viewBox="60 10 750 600">

                {/* this.props.worldMap */}
                <ZoomableGroup zoom={this.state.zoom}>

                  <Geographies geography={"https://raw.githubusercontent.com/zcreativelabs/react-simple-maps/master/topojson-maps/world-10m.json"}>

                    {({ geographies }) => geographies.map((geography, index) => (
                      <Geography
                        key={index}
                        geography={geography}
                        fill={colorScale("eee")}
                        style={{
                          default: {
                            fill: "#D6D6DA",
                            outline: "none"
                          },
                          hover: {
                            fill: "#6C757C",
                            outline: "none"
                          },
                          pressed: {
                            fill: "#E42",
                            outline: "none"
                          }
                        }}
                      />
                    ))}
                  </Geographies>
                  {this.renderLoadCountries(this.state.displayLines)}
                  {this.renderDestinationCountries()}
                  <marker id="head" viewBox="0 0 60 60" refX="45" refY="30" markerUnits="strokeWidth" markerWidth="8" markerHeight="10" orient="auto">
                    <path d="M 0 0 L 50 30 L 0 60 z" fill="black" />
                  </marker>
                  {this.drawFlow(this.state.displayLines)}
                </ZoomableGroup>
              </ComposableMap>
            </Col>
            <div style={{
              boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0,
              verticalAlign: 'center', position: 'absolute', top: '40%', width: '3rem', padding: '1rem', lineHeight: 3, right: '1rem'
            }}>
              <Row>
                <Col><MdMyLocation /> </Col>
              </Row>
              <Row>
                <Col onClick={this.handleZoomIn}><FiZoomIn /></Col>
              </Row>
              <Row>
                <Col onClick={this.handleZoomOut}><FiZoomOut /></Col>
              </Row>
            </div>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  console.log('home', state.home);
  return {
    footprint: state.home.footPrint,
    footprintflow: state.home.footPrintFlow,
    worldMap: state.home.worldMapData,
    millcount: state.supplychain.millcount,
    refineriesCount: state.supplychain.refineriesCount,
  };
}

export default connect(mapStateToProps, { getFootPrintData, updateFootPrintFlow, getMapData, getRefineriesCount, getSupplyChainWidgetData })(Footprint);
