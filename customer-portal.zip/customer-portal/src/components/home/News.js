import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history';
import { Row, Col, Card, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { getNewsData } from '../../actions/index';
import { FiBarChart2 } from 'react-icons/fi';
import { FaInfoCircle } from 'react-icons/fa';


class News extends React.PureComponent {

  componentDidMount() {
    this.props.getNewsData();
  }

  render() {
    let currentPage = history.location.pathname;
    return (
      <Card style={(currentPage === '/home')?{ width: '100%', height: 'fit-content',boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0,marginBottom:'2rem' }:
      { width: '32%', height: 'fit-content',boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0,marginTop:'2rem' }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col>
              <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>Related news</div>
              <div style={{ float: 'right' }}>
                <Button variant="light">
                  <OverlayTrigger
                    key={'top'}
                    placement={'top'}
                    overlay={
                      <Tooltip id="">
                        Related news
                    </Tooltip>
                    }>
                    <FaInfoCircle size="1.3rem" />
                  </OverlayTrigger>
                </Button>
              </div>
            </Col>
          </Row>
          <div style={{ paddingTop: '10px' }}>
            {this.props.news.map((item, index) => (
              <div key={index}>
                <Row>
                  <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1.7rem 0'}}>
                    <div style={{display:"inline",float:"left",width:"20%",textAlign:"center" }}><FiBarChart2 size="1.4em" color="#DDAA01" /></div>
                    <div style={{display:"inline",float:"left",width:"60%" }}><a style={{ color: 'black', cursor: 'pointer'}} rel="noopener noreferrer" href={item.link} target="_blank" >{item.name}</a></div>
                    <div style={{display:"inline",float:"right",width:"20%",textAlign: "center" }}><a style={{ color: 'black' }} rel="noopener noreferrer" href={item.link} target="_blank">&gt;</a></div>
                  </Col>
                </Row>
              </div>
            ))}
          </div>
          <Row style={{ borderTop: '1px solid #dee2e6' }}>
            <Col style={{ textAlign: 'center', paddingTop: '1rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }}>View all articles</Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    news: state.home.news,
  };
}

export default connect(mapStateToProps, { getNewsData })(News);