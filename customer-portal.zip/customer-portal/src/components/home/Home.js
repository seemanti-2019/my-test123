import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, CardDeck } from 'react-bootstrap';
import { getKeys } from '../../actions/index';
import TracebilityWidget from './Tracebility';
import SupplierSearch from '../supplierchecker/SearchComponent';
import Grievances from '../grievances/GrievancesWidget';
import Volumes from './VolumeWidget';
import Footprints from './Footprint';
import Downloads from './Downloads';
import News from './News';
import InfoWidget from './InfoWidget';

class Home extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }
  }

  componentDidMount() {
    this.props.getKeys();
  }

  render() {
    
    return (
        <div style={{padding:'2em 5em', backgroundColor:'#F5F5F5'}}>
          <Row>
            <Col>
              <h2 style={{fontFamily: 'Impact, Charcoal, sans-serif'}}>Welcome Jane doe</h2>
              <div>Last login: 17-02-2020</div>
            </Col>
            <Col xs lg="4" md="4"><SupplierSearch /></Col>
          </Row>
          <hr style={{border: '.5px solid grey',marginBottom: '2rem'}}></hr>
          <CardDeck className="home" style={{paddingBottom:'1.5em'}}>
            <TracebilityWidget filter={false}/>
            <Volumes/>
            <Grievances/>
          </CardDeck>
          <CardDeck className="home" style={{paddingBottom:'1.5em'}}>
            <Footprints/>
          </CardDeck >
          <CardDeck className="home" style={{paddingBottom:'1.5em'}}>
            <News/>
            <Downloads/>
            <InfoWidget/>
          </CardDeck>
        </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { getKeys })(Home);
