import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, OverlayTrigger, Tooltip, Image} from 'react-bootstrap';
import { changeName, getTracibilityData, navigateSelections } from '../../actions/index';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import history from '../header/history';
import 'react-circular-progressbar/dist/styles.css';
import { easeQuadInOut } from "d3-ease";
import ChangingProgressProvider from './ChangingProgressProvider';
import { FaInfoCircle } from 'react-icons/fa';


class Tracebility extends React.PureComponent {

  componentDidMount() {
    this.props.getTracibilityData(this.props.filter);
  }

  navigateToSupplyChain = () => {
    this.props.navigateSelections('/supplychain');
    history.push('/supplychain');
  }

  render() {
    let currentPage = history.location.pathname;
    return (
      <Card style={{height: 'fit-content', boxShadow:  '0 5px 15px -6px #33333359',border:0, borderRadius:0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
              <Col>
              <div style={{ fontSize: '1.2em',display:'inline',float:"left" }}>Traceability</div>
              <div style={{float:'right'}}><Button variant="light">
                <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                      Calculation by volume
                            </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
              </div>
            </Col>
          </Row>
          {(currentPage !== '/home') ?
            <Row>
              <Col>
                <p style={{ paddingTop: '2rem' }}>
                  The traceability scores to mill and plantation level based on volume calculation. Cargill aims to the plantation level in <a href="https://www.cargill.com/page/traceability" target="blank">high risk area.</a>
                </p>
              </Col>
            </Row> : ''
          }
          <Row style={{ borderBottom: '1px solid #dee2e6', padding: '1rem 0' }}>
            <Col style={(currentPage === '/home') ? { padding: '1rem 1.5rem' } : { padding: '1rem 5rem' }}>
              <ChangingProgressProvider
                valueStart={0}
                valueEnd={this.props.tracibility.mills}
                duration={1.4}
                easingFunction={easeQuadInOut}
              >
                {value => {
                  const roundedValue = Math.round(value);
                  return (

                    <CircularProgressbarWithChildren value={value} styles={buildStyles({
                      pathTransition: "none", strokeLinecap: "butt",
                      pathColor: "#DDAA01"
                    })} strokeWidth={3}>
                      <div style={{textAlign: 'center' }}>
                        <div style={{width:'100%'}}><Image src={require("../../assets/Icon_Mill.png")} style={{  cursor: 'pointer' }} /></div>
                        <strong style={{ fontFamily: 'Impact,Charcoal', fontSize: '3vw' }}>{`${roundedValue}%`}</strong>
                        <div style={{ fontSize: '14', textAlign: 'center' }}>Mill</div>
                      </div>
                    </CircularProgressbarWithChildren>
                  )
                }}
              </ChangingProgressProvider>
            </Col>
            <Col style={(currentPage === '/home') ? { padding: '1rem 1.5rem', borderLeft: '1px solid #dee2e6' } : { padding: '1rem 5rem', borderLeft: '1px solid #dee2e6' }}>
              <ChangingProgressProvider
                valueStart={0}
                valueEnd={48}
                duration={1.4}
                easingFunction={easeQuadInOut}

              >
                {value => {
                  const roundedValue = Math.round(value);
                  return (

                    <CircularProgressbarWithChildren value={value} styles={buildStyles({
                      pathTransition: "none", strokeLinecap: "butt",
                      pathColor: "#b3b300",
                    })} strokeWidth={3}>
                      <div style={{textAlign: 'center' }}>
                        <div style={{width:'100%'}}><Image src={require("../../assets/Icon_Plantation.png")} style={{  cursor: 'pointer' }} /></div>
                        <div style={{ marginLeft: '1em' }}>
                          <strong style={{ fontFamily: 'Impact,Charcoal', fontSize: '3vw' }}>{`${roundedValue}%`}</strong>
                        </div>
                        <div style={{ fontSize: '14', textAlign: 'center' }}>Plantation</div>
                      </div>
                    </CircularProgressbarWithChildren>
                  )
                }}
              </ChangingProgressProvider>
            </Col>
          </Row>
          <Row>
            <Col style={{ textAlign: 'center', paddingTop: '1rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }}>Read More About tracebility</Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    tracibility: state.home.tracibility,
  };
}

export default connect(mapStateToProps, { changeName, getTracibilityData, navigateSelections })(Tracebility);
