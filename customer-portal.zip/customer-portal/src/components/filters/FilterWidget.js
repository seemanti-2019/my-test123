import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Dropdown, DropdownButton } from 'react-bootstrap';
import { getFiltersOptions, updateUserOptions, clearUserOptions, applyUserSelections, editFilters, cancelUserOptions,
   getSupplyChainWidgetData, getByCountryVolumes, getRefineriesCount, getTracibilityData, getRiskPerMill, getNdpe, getGrievancesSupplierInfo, getGrievancesLocation, getGrievancesList, getGrievancesStatus,getGrievancesStatusCountData} from '../../actions/index';

class FilterWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      defaultSelection: false,
      spTextColor:'#BDBCBC',
      spBackgroundColor:'#E3E2E2',
      cglTextColor:'#fff',
      cglBackgroundColor:'#638C1C',
      selectionType : 'Cargill Supply Chain',
      filterType:'Cargill Supply Chain'
    }

  }

  componentDidMount() {
    this.props.getFiltersOptions();
  }

  clearSelction = () => {
    this.props.clearUserOptions(this.props.options);
  }

  cancelSelction = () => {
    this.props.cancelUserOptions(this.props.options);
  }

  applyUserFilters = () => {
    this.props.applyUserSelections(this.props.options);
    this.props.getSupplyChainWidgetData();
    this.props.getByCountryVolumes();
    this.props.getRefineriesCount();
    this.props.getTracibilityData();
    this.props.getRiskPerMill();
    this.props.getNdpe();
    this.props.getGrievancesSupplierInfo();
    this.props.getGrievancesLocation();
    this.props.getGrievancesList();
    this.props.getGrievancesStatus();
    this.props.getGrievancesStatusCountData();
    // this.setState({
    //   filterType: this.state.selectionType,
    // })
  }

  editFilters =() => {
    this.props.editFilters(this.props.options);
  }

  handleCheck=(key,event) => {
    let name = key.split('-');
    this.props.updateUserOptions(this.props.options, name[1], event.currentTarget.checked, name[0], event.currentTarget.name )
  }


  renderProductGroup(){
    return  this.props.options.product_group.map((item, i) => {
        return (
          <label class="container"><p style={{paddingLeft:'1rem'}}>{item.name}</p>
            <input lass="custCheck" type="checkbox" name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('product_group-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}/>
            <span class="checkmark"></span>
          </label>
            // <Row key={i} style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
            //   <input class="custCheck" type="checkbox" name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('product_group-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
            //   <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            // </Row>
        )
    })
  }

  renderSelectedProductGroup(){
    return this.props.options.product_group.map((item, i) => {
      if(item.checked === true){
      return (
        <p>{item.name}</p>
      )} else {
        return ('');
      }
  })
}

  renderRSPO(){
    return  this.props.options.rspo.map((item, i) => {
        return (
          <label class="container"><p style={{paddingLeft:'1rem'}}>{item.name}</p>
            <input lass="custCheck" type="checkbox" name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('rspo-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}/>
            <span class="checkmark"></span>
          </label>
            // <Row key={i} style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
            //   <input class="custCheck" type="checkbox" name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('rspo-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
            //   <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            // </Row>
        )
    })
  }

  renderSelectedRSPO(){
    return  this.props.options.rspo.map((item, i) => {
      if(item.checked === true){
      return (
          <p>{item.name}</p>
      )} else {
        return ('');
      }
  })
  }

  renderYearQuater(){
    return  this.props.options.year_quater.map((item, i) => {
        return (
            <Dropdown.Item key={i}>{item}</Dropdown.Item>
        )
    })
  }

  renderYearQuaterDropDowns(){
    return  this.props.options.year_quater.map((item, i) => {
        return (
          <Row>
            <Col>
              <Dropdown.Item key={i}>{item.year}</Dropdown.Item>
            </Col>
          </Row>
        )
    })
  }

  renderSelectedYearQuater(){
    return  this.props.options.year_quater.map((item, i) => {
      return (
      <p key={i}>{item}</p>
      )
  })
  }

  renderDestination(){
    return  this.props.options.destination.map((item, i) => {
        return (
            <Row style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
              <input class="custCheck" type="checkbox" name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('destination-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
              <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            </Row>
        )
    })
  }

  renderDestinationMarket(){
    return this.props.options.destination.map((item, i) => {
      return (
        <div>
            <Row style={{paddingLeft:'1rem', paddingRight:'1rem'}}>
              <Col style={{paddingLeft:'1rem'}}>
                <input type="checkbox"name={item.param} checked={item.checked} onChange={(e) => this.handleCheck('destination-'+item.name, e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
                <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
              </Col>
            </Row>
            <Dropdown.Divider />
            </div>
      )
    })
  }

  renderSelectedDestination(){
    return  this.props.options.destination.map((item, i) => {
      if(item.checked === true){
      return (
          
            <p>{item.name}</p>
          
      )} else {
        return ('');
      }
  })
  }

  supplyChainSelction = (userSelection) => {
    if(userSelection){
      this.setState({
        spTextColor:'#fff',
        spBackgroundColor:'#638C1C',
        cglTextColor:'#BDBCBC',
        cglBackgroundColor:'#E3E2E2',
        defaultSelection: false,
        selectionType: 'My Supply Chain',
      })
    }else{
      this.setState({
        spTextColor:'#BDBCBC',
        spBackgroundColor:'#E3E2E2',
        cglTextColor:'#fff',
        cglBackgroundColor:'#638C1C',
        defaultSelection: true,
        selectionType: 'Cargill Supply Chain'
      })
    }
  }
  
  renderFilterLayer(){
    if (this.props.widgetStatus === true){
      return(
        <div>  
        <Row style={{margin:'0px'}}>
            <div sm={2}>
              <Row sm={12} style={{padding:'0px',margin:'0px',borderTopLeftRadius: '10px', height:'110px',backgroundColor:this.state.cglBackgroundColor, cursor:'pointer'}}
                onClick={() => this.supplyChainSelction(false)}>
                    <p style={{color:this.state.cglTextColor, padding:'0.8em', lineHeight:3}}><strong>Cargill Supply Chain</strong></p>
              </Row>
              <Row sm={12} style={{padding:'0px',margin:'0px',borderTopLeftRadius: '0px', height:'110px',backgroundColor:this.state.spBackgroundColor, cursor:'pointer'}}
                 onClick={() => this.supplyChainSelction(true)}>
                    <p style={{color:this.state.spTextColor, padding:'0.8em', lineHeight:3}}><strong>My Supply Chain</strong></p>
              </Row>
            </div>
            <Col sm={10} >
                <Row>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Product Group</strong>
                    {this.renderProductGroup()}
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>RSPO Certification</strong>
                    {this.renderRSPO()}
                </Col>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Year Quater</strong>
                    <DropdownButton
                        variant="outline-secondary"
                        size="sm"
                        title="In 2019-Q2"
                        id="input-group-dropdown-2"
                        style={{paddingTop:'0.5em'}}
                        >
                        {this.renderYearQuater()}
                    </DropdownButton>
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Destination Market</strong>
                    {this.renderDestination()}
                </Col>
                </Row>
            </Col>                                   
        </Row>
        <Row style={{paddingBottom:'1em'}}>
            <Col sm={6}></Col>
            <Col sm={2}>
                <Button variant="dark" style={{width:'135px'}} onClick={this.applyUserFilters}>Apply Filters</Button>
            </Col>
            <Col sm={2}>  
                <Button variant="dark" style={{width:'135px'}} onClick={this.clearSelction}>Clear</Button>
            </Col>
            <Col sm={2}>  
                <Button variant="dark" style={{width:'135px'}} onClick={this.cancelSelction}>Cancel</Button>
            </Col>
        </Row>
        </div>

      )
    }else{
        return(
          <div>
            <Row>
            <Col sm={2}>
              <p style={{ padding:'0.8em'}}><strong>{this.state.filterType}</strong></p>
            </Col>
            <Col sm={10} >
                <Row>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Product Group</strong>
                    {this.renderSelectedProductGroup()}
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>RSPO Certification</strong>
                    {this.renderSelectedRSPO()}
                </Col>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Year Quater</strong>
                   
                        {this.renderSelectedYearQuater()}
  
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Destination Market</strong>
                    {this.renderSelectedDestination()}
                </Col>
                </Row>
            </Col>              
            </Row>
            <Row style={{paddingBottom:'1em'}}>
              <Col sm={10}></Col>
              <Col sm={2}>  
                  <Button variant="dark" style={{width:'135px'}} onClick={this.editFilters}>Edit Filters</Button>
              </Col>
            </Row>
          </div>
        )
    }
  }


  render() {
    
    return (
      
      // <Card style={{ width: '100%', borderRadius: '10px' }}>
      //     <Card.Body style={{padding:'0px'}}>
      //           {this.renderFilterLayer()}
      //     </Card.Body>
      // </Card>
      <nav id="sidebar">
        {/* <div class="sidebar-header">
            
        </div> */}
        <div sm={12} style={{padding:'1rem'}} className="list-unstyled components dropdown-toggle">
          <p style={{fontSize:'15px', padding:'0.5rem'}}>Supply Chain</p>
          <div class="radio-item">
              <input type="radio" id="msc" name="sc" value=""/>
              <label for="msc">FoodCorp Inc.</label>
          </div>
          <div class="radio-item">
              <input type="radio" id="csc" name="sc" value="" checked/>
              <label for="csc">Cargill</label>
          </div>
          <hr style={{background:'white', paddingLeft:'2rem', paddingRight:'1rem'}}></hr>
        </div>

        <div sm={12} style={{padding:'0.5rem'}} className="list-unstyled components">
          <p style={{fontSize:'15px', padding:'0.5rem'}}>Year and quater</p>
          <Row>
            <Col sm={6}>
              <DropdownButton id="dropdown-basic-button" variant="secondry" title="2019">
                <Dropdown.Item variant="secondry">2019</Dropdown.Item>
              </DropdownButton>
            </Col>
            <Col sm={6}>
              <DropdownButton id="dropdown-basic-button" variant="secondry" style={{color:'#fff !important'}} title="Q2">
                <Dropdown.Item variant="secondry">Q2</Dropdown.Item>
              </DropdownButton>
            </Col>
          </Row>
          
          <hr style={{background:'white', paddingLeft:'2rem', paddingRight:'1rem'}}></hr>
        </div>

        <div sm={12} style={{padding:'1rem'}} className="list-unstyled components dropdown-toggle">
          <p style={{fontSize:'15px', padding:'0.5rem'}}>Product Group</p>
          {this.renderProductGroup()}
          <hr style={{background:'white', paddingLeft:'2rem', paddingRight:'1rem'}}></hr>
        </div>

        <div sm={12} style={{padding:'1rem'}} className="list-unstyled components dropdown-toggle">
          <p style={{fontSize:'15px', padding:'0.5rem'}}>Certification</p>
          {this.renderRSPO()}
          <hr style={{background:'white', paddingLeft:'2rem', paddingRight:'1rem'}}></hr>
        </div>

        <div sm={12} style={{padding:'1rem'}} className="list-unstyled components dropdown-toggle">
          <p style={{fontSize:'15px', padding:'0.5rem'}}>Destination Market</p>
          <DropdownButton id="dropdown-basic-button" variant="secondry" title="Multiple Selected">
          {this.renderDestinationMarket()}
          </DropdownButton>
          <hr style={{background:'white', paddingLeft:'2rem', paddingRight:'1rem'}}></hr>
        </div>


        {/* <ul class="list-unstyled components"> */}
            {/* <li class="active">
                <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="fas fa-home"></i>
                    Home
                </a>
                <ul class="collapse list-unstyled" id="homeSubmenu">
                    <li>
                        <a href="#">Home 1</a>
                    </li>
                    <li>
                        <a href="#">Home 2</a>
                    </li>
                    <li>
                        <a href="#">Home 3</a>
                    </li>
                </ul>
            </li> */}
            {/* <li>
                <a href="#">
                    <i class="fas fa-briefcase"></i>
                    About
                </a>
                <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="fas fa-copy"></i>
                    Pages
                </a>
                <ul class="collapse list-unstyled" id="pageSubmenu">
                    <li>
                        <a href="#">Page 1</a>
                    </li>
                    <li>
                        <a href="#">Page 2</a>
                    </li>
                    <li>
                        <a href="#">Page 3</a>
                    </li>
                </ul>
            </li> */}
        {/* </ul> */}

    </nav>
        
    );
  }
}


const mapStateToProps = state => {
  return {
    options: state.filters.options,
    widgetStatus: state.filters.filterWidget,
  };
}

export default connect(mapStateToProps, { getFiltersOptions, updateUserOptions, clearUserOptions, applyUserSelections, editFilters, cancelUserOptions,
getSupplyChainWidgetData, getByCountryVolumes, getRefineriesCount, getTracibilityData, getRiskPerMill, getNdpe, getGrievancesSupplierInfo, getGrievancesLocation,getGrievancesList, getGrievancesStatus,getGrievancesStatusCountData})(FilterWidget);
