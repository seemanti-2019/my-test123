import React from 'react';
import { Button, Col, Row } from 'react-bootstrap';


class SubscriptionAndFAQ extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            isSubscribed :false,
        }
    }
    handleClick = (e) => {
        console.log(e);
        this.setState({isSubscribed: true});
        console.log(this.props.source);
    }
    render() {           
        return(
            <Row style={{marginBottom: '2rem'}}>
                <Col md={8}></Col>
                <Col md={4}>
                    <Row>
                        <Col md={2}></Col>
                        <Col md={6} style={{textAlign: "right"}}>
                            <Button variant={(this.state.isSubscribed)?"outline-dark":"dark"} style={{ border: '1px solid black', width: "100%"}} onClick={(this.state.isSubscribed)?undefined:(e)=> this.handleClick(e)} >{(this.state.isSubscribed)?"Subscribed":"Subscribe"}</Button>
                        </Col>
                        <Col md={4} style={{textAlign: "right"}}>
                            <Button variant="outline-dark" style={{ border: '1px solid black', width: "100%"}}>FAQ'S</Button>
                        </Col>
                    </Row>
                </Col>                         
            </Row>
        )
    }
}

export default SubscriptionAndFAQ;