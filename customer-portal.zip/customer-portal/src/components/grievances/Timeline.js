import React from 'react';
import { Col } from 'react-bootstrap';

const Timeline = ({timelineData, type, statusFlag, showTooltip,status}) => {
    return (
        <Col>
            <section className={"main-timeline-section " + (type !== 'year'? 'top': '')} >
                <div className={"conference-center-line-bottom " + (type !== 'year'? 'top': '')}></div>
                <div className="conference-timeline-content">
                    {
                    timelineData.map(data => {  
                        if(status === data.text)
                        {
                            statusFlag = "false";
                        }
                        return (
                            <div key={data.id} className="timeline-article timeline-article-top" style={{ minHeight: type === 'year' ? "160px" : "" }}>
                                {
                                (data.suspended && statusFlag === "false" && status !== 'Closed') ? (
                                (data.text === status)? (<div className="content-data">
                                    <span className="author">Suspended</span>
                                    <div id="circle"></div>
                                    <div className="vertical-line"></div>
                                </div>):'') : ('')
                                }
                                <div className={"meta-data" + ((data.active === false || statusFlag === "true") ? "-grey" : "")} style={{ cursor: type === 'year' ? "" : "pointer" }} onClick={type !== 'year' ? () => showTooltip(data.id) : undefined}>
                                    <div className="meta-separator"></div>
                                </div>
                                <div className="content-title">
                                    {data.text}
                                </div>
                                {
                                ((type === 'timeline' && statusFlag === "false") && data.text !== 'Closed' && data.tooltipText !== '') ? (
                                <div className="content-box" style={{ display: data.showTooltip === true ? "block" : "none" }}>
                                    <div style={{ fontSize: '16px', textAlign: 'center' }}>Status: {data.text}</div>
                                    <div style={{ fontSize: '11px', textAlign: 'center' }}>Action Cargill has taken</div>
                                    <p>{data.tooltipText}</p>
                                </div>) : ('')
                                }
                            </div>    
                        );
                    }) 
                    }
                </div>
            </section>
        </Col>
    )
}
export default Timeline;