import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history'
import { Button, Row, Col, Card, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { changeName, navigateSelections, getGrievancesStatusCountData } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';
import { TiArrowSync } from 'react-icons/ti';
import { AiTwotoneFlag } from 'react-icons/ai';
import { IoMdRefresh } from 'react-icons/io';

class GrievancesWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesStatusCountData();
  }

  navToGreviences = () => {
    this.props.navigateSelections('/grievances');
    history.push('/grievances');
  }

  test1 = () => {
    this.props.navigateSelections('/grievances');
    history.push('/grievancesoverview');
  }

  render() {

    return (
      <Card style={{ width: '100%', boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col>
              <div style={{ fontSize: '1.2em', display: 'inline', float: "left" }}>Grievances</div>
              <div style={{ float: 'right' }}><Button variant="light">
                <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                      Grievances are complaints or concerns associated with Cargill's palm policy. Cargill carefully tracks and manages these grievances.
                    </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
              </div>
            </Col>
          </Row>
          <Row>
            <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1.7rem 0' }}>
              <div style={{ display: "inline", float: "left", width: "20%", textAlign: "center" }}><TiArrowSync size="1.5em" /></div>
              <div style={{ display: "inline", float: "left", width: "65%" }}><a style={{ color: 'black', cursor: 'pointer' }} rel="noopener noreferrer" onClick={this.navToGreviences} >{this.props.statusCount.total_active_grievance} Active grievances</a></div>
              <div style={{ display: "inline", float: "right", color: 'black', cursor: 'pointer', width: "15%" }} onClick={this.navToGreviences}>&gt;</div>
            </Col>
          </Row>
          <Row>
            <Col style={{ borderBottom: "1px solid #dee2e6", padding: '1.7rem 0' }}>
              <div style={{ display: "inline", float: "left", width: "20%", textAlign: "center" }}><AiTwotoneFlag size="1.5em" color="#e68a00" /></div>
              <div style={{ display: "inline", float: "left", width: "65%" }}><a style={{ color: 'black', cursor: 'pointer' }} rel="noopener noreferrer" >{this.props.statusCount.total_new_grievance} Unread grievances</a></div>
              <div style={{ display: "inline", float: "right", color: 'black', cursor: 'pointer', width: "15%" }}>&gt;</div>
            </Col>
          </Row>
          <Row>
            <Col style={{ padding: '2rem 0' }}>
              <div style={{ display: "inline", float: "left", width: "20%", textAlign: "center" }}><IoMdRefresh size="1.5em" /></div>
              <div style={{ display: "inline", float: "left", width: "65%" }}><a style={{ color: 'black', cursor: 'pointer' }} rel="noopener noreferrer" >{this.props.statusCount.total_updated_grievance} Updated grievances</a></div>
              <div style={{ display: "inline", float: "right", color: 'black', cursor: 'pointer', width: "15%" }}>&gt;</div>
            </Col>
          </Row>
          <Row style={{ borderTop: '1px solid #dee2e6' }}>
            <Col style={{ textAlign: 'center', paddingTop: '1rem', color: '#9E7025', cursor: 'pointer', fontSize: 18 }} onClick={(e) => this.test1()} >View all grievances</Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
    statusCount: state.grievances.statusCountData
  };
}

export default connect(mapStateToProps, { changeName, navigateSelections, getGrievancesStatusCountData })(GrievancesWidget);
