import React from 'react';
import { connect } from 'react-redux';
import { Button, Card } from 'react-bootstrap';
import history from '../header/history'
import { changeName,getGrievancesStatusCountData, navigateSelections } from '../../actions/index';

class GrievancesHeader extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesStatusCountData();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

  test1 = () => {
    this.props.navigateSelections('/grievances');
    history.push('/grievancesoverview');
    //  this.props.changeName();
  }
  


  render() {
    
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <h1><strong>Grievances Cargill</strong></h1>
            <p>
            Grievances are complaints or concerns associated with Cargill's palm policy. Cargill carefully tracks and manages these grievances.
            </p>
            <div style={{padding:'10px 0px 15px 0px'}}>There are {this.props.statusCount.total_active_grievance} grievances in your supply chain</div>
            <Button onClick={(e)=> this.test1()} variant="outline-dark"> Show Grievances </Button>
            </Card.Body></Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
    statusCount: state.grievances.statusCountData
  };
}

export default connect(mapStateToProps, { changeName,getGrievancesStatusCountData, navigateSelections })(GrievancesHeader);
