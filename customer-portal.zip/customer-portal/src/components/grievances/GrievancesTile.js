import React from 'react';
import { Row, Col, Card, Button } from 'react-bootstrap';


const GrievancesTile = ({ grievance,textInput,handleClick,exportCSV }) => {
    const formatDate = (string) => { 
        var options = { year: 'numeric', day: 'numeric', month: 'short' };
        return new Date(string).toLocaleDateString([],options);
    }
    var dateString = grievance.grievance_status_date;
    let dt = formatDate(dateString);
    
    return (
        <Card style={{ marginTop: '2rem', marginBottom: '1rem',padding: "1em" }}>
            <Card.Body>
                <Row>
                    <Col md={10}>
                        <h3 style={{ paddingBottom: '5px' }}>{grievance.grievance_sub_category}</h3>
                        <p style={{ marginTop: "0", marginBottom: "1rem" }}>
                            <strong>Entity </strong>
                            <span style={{paddingLeft: '1rem'}}>{grievance.supplier_name}</span>
                        </p>
                        <p style={{ marginTop: "0", marginBottom: "1rem" }}>
                            <strong>Status </strong>
                            <span style={{paddingLeft: '1rem'}}>{grievance.grievance_current_status}</span>
                        </p>
                        <Row>
                            <Col md={3}>
                                <Button variant="light" style={{ border: '1px solid black', width: "100%" }} onClick={() => handleClick(grievance.grievance_id)}>See Grievances</Button>
                            </Col>
                            <Col md={9}>
                                <a style={{ display: 'none' }} href='empty' ref={textInput}>ref</a>
                                <Button variant="dark" onClick={()=> exportCSV()}>Download statement</Button>
                            </Col>
                        </Row>
                    </Col>
                    <Col md={2} style={{textAlign: "right"}}>
                        {dt}
                    </Col>
                </Row>
            </Card.Body>
        </Card>
    )
}

export default GrievancesTile;