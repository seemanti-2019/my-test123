import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, CardDeck, Card } from 'react-bootstrap';
import history from '../header/history'
import { changeName, navigateSelections } from '../../actions/index';
import FilterHeader from '../filters/FilterWidget';
import LocationWidget from '../grievances/LocationWidget';
import SupplierWidget from '../grievances/SupplierWidget';
import StatusWidget from '../grievances/GrievancesStatusWidget';
import SupplierSearch from '../supplierchecker/SearchComponent';
import Grievances from '../grievances/GrievancesWidget';
import News from '../home/News';


import { FaChevronRight } from 'react-icons/fa';

class GrievancesWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      showAnalyticsDiv: true,
    }
  }

  navigateToSelected = () => {
    this.props.navigateSelections('/home');
    history.push('/home');
  }

  showAnalytics = () => {
    this.setState({ 'showAnalyticsDiv': true });
  }

  showLog = () => {
    this.setState({ 'showAnalyticsDiv': false });
  }

  render() {
    return (
      <div class="wrapper">
        <FilterHeader/>
        <div id="content">
      <div style={{ padding: '1em 1em', backgroundColor: '#F5F5F5' }}>
        <Row style={{ paddingTop: '1em' }}>
          <Col style={{ paddingBottom: '1em' }}>
            <Row>
              <Button variant="link" style={{ color: '#000', fontSize: '20px' }} onClick={(e) => this.navigateToSelected()}>Home</Button>
              <div style={{ marginTop: '9px' }}><FaChevronRight size={13} /></div>
              <Button variant="link" style={{ color: '#977000', fontSize: '20px' }} >My grievances</Button>
            </Row>
          </Col>
          <Col xs lg="4" md="4"><SupplierSearch /></Col>
        </Row>
        <hr style={{ border: '.5px solid grey', marginBottom: '2rem' }}></hr>
        {/* <CardDeck style={{ padding: '1em 0' }}>
          <FilterHeader></FilterHeader>
        </CardDeck> */}
        <Row>
          <Col sm={6}>
            <Row >
              <Col sm={2}><span style={(this.state.showAnalyticsDiv) ? { borderBottom: '2px solid #DDAA01', paddingBottom: '.4em', cursor: 'pointer' } : { cursor: 'pointer' }} onClick={(e) => this.showAnalytics()}>Analytics</span></Col>
              <Col sm={3}><span style={(!this.state.showAnalyticsDiv) ? { borderBottom: '2px solid #DDAA01', paddingBottom: '.4em', cursor: 'pointer', textAlign: 'left' } : { cursor: 'pointer', textAlign: 'left' }} onClick={(e) => this.showLog()}>Log</span></Col>
              <Col></Col>
            </Row>
          </Col>
          <Col sm={6}></Col>
        </Row>
        {(this.state.showAnalyticsDiv) ? (
          <div>
            <CardDeck style={{ marginTop: '2rem' }}>
              <LocationWidget />
              <SupplierWidget />
              <Grievances />
            </CardDeck>
            <StatusWidget />
            <News />
          </div>) : (
            <div>
              <CardDeck style={{ marginTop: '2rem', height: '500px' }}>
                <Card>
                  <Card.Body>
                    This page is under construction...
                </Card.Body>
                </Card>
              </CardDeck>
            </div>)
        }
      </div>
      </div>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName, navigateSelections })(GrievancesWidget);
