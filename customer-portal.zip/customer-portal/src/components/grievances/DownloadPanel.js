import React from 'react';
import DownloadImage from '../../assets/download_icon.png';
import { Row, Col, Image } from 'react-bootstrap';
import { FaLongArrowAltDown } from 'react-icons/fa';

const Download = ({textInput,exportCSV}) => {
    return (
        <Row>
            <Col md={3} style={{ backgroundColor: '#519230e6', height: '6rem', borderRadius: '5px 0 0 5px' }}>
                <Row style={{ paddingLeft: '40%', color: 'white', paddingTop: '2%' }}>
                    <span>Downloads</span>
                </Row>
                <Row style={{ paddingLeft: '45%', color: 'white', paddingTop: '2%' }}>
                    <Image src={DownloadImage} height="40" width="40" alt="download"></Image>
                </Row>
            </Col>
            <Col md={4}>
                <a style={{ display: 'none' }} href='empty' ref={textInput}>ref</a>
                <div style={{ textAlign: "center", marginTop: "28px", cursor: "pointer" }} onClick={() => exportCSV()}>
                    <FaLongArrowAltDown style={{marginRight: "10px"}} />
                    Cargill statement
                </div>
            </Col>
            <Col md={5}>
                <a style={{ display: 'none' }} href='empty' ref={textInput}>ref</a>
                <div style={{ marginTop: "28px", cursor: "pointer" }} onClick={() => exportCSV()}>
                    <FaLongArrowAltDown style={{marginRight: "10px"}} />
                     Grievance report
                </div>
            </Col>
        </Row>        
    )
}

export default Download;



