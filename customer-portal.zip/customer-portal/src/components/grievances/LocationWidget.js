import React from 'react';
import { connect } from 'react-redux';
import { ProgressBar, Row, Col, Card, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { getGrievancesLocation, getGrievancesStatusCountData } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';

class LocationWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesLocation();
    this.props.getGrievancesStatusCountData();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }


  render() {
    let arr = this.props.location;
    let colorCode = ['#DDAA01', '#ebc247'];
    return (
      <Card style={{ width: '100%', height: 'fit-content', boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col sm={6} style={{ fontSize: '1.2em' }}>Grievances Location</Col>
            <Col sm={6} style={{ textAlign: 'right' }}>
              <Button variant="light">
                <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                      Calculation by location
                            </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
            </Col>
          </Row>
          <Row>
            <Col style={{ paddingTop: '1em', marginLeft: '0' }}>Total number of grievances related to the supply chain</Col>
          </Row>
          <Row>
            <Col style={{ fontSize: 24, fontFamily: 'Impact,Charcoal', color: '#DDAA01' }}>{this.props.statusCount.total_active_grievance}</Col>
          </Row>
          <Row>
            <Col>
              <hr style={{ height: '2px', color: '#dee2e6' }}></hr>
            </Col>
          </Row>
          <Row><Col style={{ fontWeight: 'bold' }}>Location of grievances</Col></Row>
          <Row>
            <Col sm={12} style={{ padding: '1em' }} >
              {(arr.grievance_details) ?
                arr.grievance_details.map((item, index) => (
                  <Row style={{ padding: '5px' }} key={index}>
                    <Col sm={8} style={{ paddingLeft: '.5rem' }} >
                      <ProgressBar style={{ height: '24px', backgroundColor: '#fff' }} max={arr.total_count}>
                        <ProgressBar now={item.grievance_id_count} max={arr.total_count} style={{ height: '24px', backgroundColor: colorCode[index] }} />
                        <span style={{ marginLeft: '5px', fontSize: 16 }}><b>{`${item.grievance_id_count}  `}</b></span>
                      </ProgressBar>
                    </Col>
                    <Col sm={4} style={{ marginTop: '-3px' }}>{item.country_of_violation}</Col>

                  </Row>)) : ''}
            </Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    location: state.grievances.location,
    statusCount: state.grievances.statusCountData
  };
}

export default connect(mapStateToProps, { getGrievancesLocation, getGrievancesStatusCountData })(LocationWidget);
