import React from 'react';
import { connect } from 'react-redux';
import { Col, Card, Row, Button, OverlayTrigger, Tooltip, ProgressBar } from 'react-bootstrap';
import { getGrievancesStatus } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';

class GrievancesStatusWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }
  }

  componentDidMount() {
    this.props.getGrievancesStatus();
  }

  componentWillReceiveProps(nextProps) {
  }

  render() {
    this.statusNames = ['Investigation', 'Verification', 'Developing Action Plan', 'Monitoring Implementation', 'Suspended', 'Closed'];
    let colorCodes = ['#DDAA01', '#b3b300', '#cc7a00'];
    let totalCount = -1;
    let dataList = this.props.grievances.grievance_count_by_action_status;
    totalCount = this.props.grievances.total_count;
    return (
      <Card style={{ width: '66%', float: 'left', margin: '2rem 1.7rem 2rem 0', boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col sm={6} style={{ fontSize: '1.2em' }}>Grievances status</Col>
            <Col sm={6} style={{ textAlign: 'right' }}>
              <Button variant="light">
                <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                      We hold ourselves and our suppliers accountable to respond to grievances, set time-bound action plans to ensure progress and close the grievances in a timely manner as agreed to by the complainant. Cargill's Palm Grievances Procedure provides a transparent, open and robust process for dealing with grievances.
                  </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
            </Col>
          </Row>
          <Row style={{ paddingTop: '1rem' }}>
            <Col sm={3}><span style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#DDAA01', display: 'inline-block', marginRight: '1rem' }}></span>Social Non-compliance</Col>
            <Col sm={4}><span style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#b3b300', display: 'inline-block', marginRight: '1rem' }}></span>Environmental Non-compliance</Col>
            <Col sm={5}><span style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#cc7a00', display: 'inline-block', marginRight: '1rem' }}></span>Legal Non-compliance</Col>
          </Row>
          <Row style={{ padding: '1rem ' }}>
            <Col>
              {
                this.statusNames.map((item, index) => {
                  if (dataList) {
                    const filteredItem = dataList.filter(data => data.action_status === item);
                    if (filteredItem.length > 0) {
                      return (<Row key={index} style={{ paddingTop: '1rem' }}>
                        <Col sm={4} style={{ textAlign: 'right' }}>{item}</Col>
                        <Col sm={8}>
                          <ProgressBar style={{ height: '24px', backgroundColor: '#fff', fontWeight: 'bold' }}>
                            {
                              filteredItem[0].grievance_count_by_category.map((data2, index2) => {
                                const now = data2.grievance_count;
                                if (data2.grievance_category === 'Social Non-Compliance') {
                                  return (
                                    <ProgressBar style={{ backgroundColor: colorCodes[index2], borderTopLeftRadius: '0', borderBottomLeftRadius: '0' }} now={now} max={totalCount} key={1} label={`${now}`} />
                                  )
                                } else if (data2.grievance_category === 'Environmental Non-Compliance') {
                                  return (
                                    <ProgressBar style={{ backgroundColor: colorCodes[index2], borderTopLeftRadius: '0', borderBottomLeftRadius: '0' }} now={now} max={totalCount} key={1} label={`${now}`} />
                                  )
                                } else if (data2.grievance_category === 'Environmental Legal') {
                                  return (
                                    <ProgressBar style={{ backgroundColor: colorCodes[index2], borderTopLeftRadius: '0', borderBottomLeftRadius: '0' }} now={now} max={totalCount} key={1} label={`${now}`} />
                                  )
                                }
                                else {
                                  return ('');
                                }
                              })
                            }
                          </ProgressBar>
                        </Col>
                      </Row>)
                    } else {
                      return (<Row key={index} style={{ paddingTop: '1rem' }}>
                        <Col sm={4} style={{ textAlign: 'right' }}>{item}</Col>
                      </Row>)
                    }
                  } else {
                    return (<Row key={index} style={{ paddingTop: '1rem' }}>
                      <Col sm={4} style={{ textAlign: 'right' }}>{item}</Col>
                    </Row>)
                  }
                })
              }
            </Col>
          </Row>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.status,
  };
}

export default connect(mapStateToProps, { getGrievancesStatus })(GrievancesStatusWidget);
