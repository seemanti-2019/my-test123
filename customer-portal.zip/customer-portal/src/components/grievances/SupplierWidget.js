import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { getGrievancesSupplierInfo } from '../../actions/index';
import { FaInfoCircle } from 'react-icons/fa';
import C3Chart from 'react-c3js';
import 'c3/c3.css';

class LocationWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {

    this.props.getGrievancesSupplierInfo();
  }

  render() {
    const dataDonut = {
      columns: [
        ['Direct', this.props.grievances.number_of_direct_supplier],
        ['Indirect', this.props.grievances.number_of_indirect_supplier],
      ],
      type: 'donut',

    };

    const legendDonut = {
      hide: true
    };

    const colorDonut = {
      pattern: ['#DDAA01', '#b3b300']
    };

    const sizeDonut = {
      height: '240',
    };

    const tooltipDonut = {
      show: false
    };
    const donut = {
      label: {
        format: function (value) {
          return value
        }
      },
    };


    return (

      <Card style={{ width: '100%', height: 'fit-content', boxShadow: '0 5px 15px -6px #33333359', border: 0, borderRadius: 0 }}>
        <Card.Body>
          <Row style={{ borderBottom: '1px solid #dee2e6', paddingBottom: '1rem' }}>
            <Col sm={6} style={{ fontSize: '1.2em' }}>Direct/Indirect</Col>
            <Col sm={6} style={{ textAlign: 'right' }}>
              <Button variant="light">
                <OverlayTrigger
                  key={'top'}
                  placement={'top'}
                  overlay={
                    <Tooltip id="">
                      Direct/Indirect suppliers
                  </Tooltip>
                  }>
                  <FaInfoCircle size="1.3rem" />
                </OverlayTrigger>
              </Button>
            </Col>
          </Row>
          <Row style={{ paddingTop: '1em' }}>
            <Col sm={8} >Risk per mill</Col>
            <Col sm={4} >
              <Row><Col><span style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#DDAA01', display: 'inline-block', marginRight: '1rem' }}></span>Direct</Col></Row>
              <Row><Col><span style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#b3b300', display: 'inline-block', marginRight: '1rem' }}></span>Indirect</Col></Row>
            </Col>
          </Row>
          <Col sm={12}>
            <C3Chart data={dataDonut} legend={legendDonut} color={colorDonut} size={sizeDonut} tooltip={tooltipDonut} donut={donut} />
          </Col>
        </Card.Body>
      </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.pieChart,
  };
}

export default connect(mapStateToProps, { getGrievancesSupplierInfo })(LocationWidget);
