import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Dropdown, CardDeck } from 'react-bootstrap';
import history from '../header/history'
import { getGrievancesList, getGrievancesFiltersOptions, getGrievancesSortOrder, applyGrievancesSorting, updateGrievancesFilter, applyGrievancesFilter, navigateSelections } from '../../actions/index';
import GrievanceTile from './GrievancesTile';
import { FaSortAmountDown, FaSortAmountUp } from 'react-icons/fa';

class GrievancesOverview extends React.PureComponent {

    constructor(props) {
        super(props);
        this.textInput = React.createRef();
        this.state = {
            isLoading: false,
            status: 'Status',
            country: 'Country'
        }
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.textInput;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }
    handleClick = (id) => {
        this.props.navigateSelections('/grievances');

        history.push(`/grievance-details/${id}`);
    }

    setFilter = (field, value) => {
        console.log(field);
        switch (field) {
            case "status":
                this.setState({ status: value })
                break;
            case "country":
                this.setState({ country: value })
                break;
            default:
                break;
        }
        this.props.updateGrievancesFilter(field, value);
    }
    applyFilter = () => {
        this.props.applyGrievancesFilter();
    }
    sortDatewise = (order) => {
        this.props.applyGrievancesSorting(order);
    }
    componentDidMount() {
        this.props.getGrievancesList();
        this.props.getGrievancesFiltersOptions();
        this.props.getGrievancesSortOrder();
    }   

    test1 = () => {
        this.props.navigateSelections('/home');
        history.push('/home');
    }

    test2 = () => {
        this.props.navigateSelections('/grievances');
        history.push('/grievances');
    }

    renderVentureItems = () => {
        return this.props.filterOptions.ventureItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }

    renderStatusItems = () => {
        return this.props.filterOptions.statusItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }
    renderCountryItems = () => {
        return this.props.filterOptions.countryItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }
    renderSortButton = () => {
        return (this.props.sortOrder === 'desc') ?
            (
                <Button variant="outline-dark" onClick={() => this.sortDatewise('asc')}>
                    <FaSortAmountDown />
                </Button>
            ) : (
                <Button variant="outline-dark" onClick={() => this.sortDatewise('desc')}>
                    <FaSortAmountUp />
                </Button>
            )
    }
    render() {
        return (
            <div style={{ padding: '1em', backgroundColor: '#F5F5F5' }}>
                
                <Row style={{ paddingTop: '1em', paddingLeft: '2em' }}>
                    <Col>
                        <Row>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test1()}>Home</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test2()}>My grievances</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#000', fontSize: '18px', fontWeight: '600' }} >Grievances Overview</Button>
                        </Row>
                    </Col>
                </Row>
                {/* <CardDeck style={{ paddingTop: '1em', paddingLeft: '1.4em', paddingRight: '1.3em' }}>
                    <FilterHeader></FilterHeader>
                </CardDeck> */}
                <CardDeck style={{ padding: '1.5em' }}>
                    <Card style={{ width: '100%', padding: '1em' }}>
                        <Card.Body>
                            <h1><strong>Grievances Overview.</strong></h1>
                            <Row style={{ marginTop: "2rem" }}>
                                {/*<Col md={3}>
                                    <Dropdown>
                                         <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%", textAlign: "left" }}>
                                            Felda Global Ventures
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                            {this.renderVentureItems()}
                                        </Dropdown.Menu>
                                    </Dropdown> 
                                </Col>*/}
                                <Col md={3}>
                                    <Dropdown onSelect={(e) => this.setFilter('status', e)}>
                                        <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: '100%', textAlign: "left" }}>
                                            {this.state.status}
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                            {this.renderStatusItems()}
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                                <Col md={3}>
                                    <Dropdown onSelect={(e) => this.setFilter('country', e)}>
                                        <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%", textAlign: "left" }}>
                                            {this.state.country}
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                            {this.renderCountryItems()}
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                                <Col md={3}>
                                    <Button variant="dark" onClick={() => this.applyFilter()}>Apply Filter</Button>
                                </Col>
                                <Col md={3}></Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </CardDeck>
                <Row style={{ paddingTop: "1rem", paddingLeft: '2em', paddingRight: '2em' }}>
                    <Col md={2}>
                        {(this.props.grievanceList)?this.props.grievanceList.length: 0}  results
                    </Col>
                    <Col md={10} style={{ textAlign: "right" }}>
                        {this.renderSortButton()}
                    </Col>
                </Row>
                {(this.props.grievanceList)?
                    this.props.grievanceList.map(grievance => {
                        return (
                            <CardDeck style={{ padding: '0 1.5em' }} key={grievance.grievance_id}>
                                <GrievanceTile
                                    grievance={grievance}
                                    key={grievance.grievance_id}
                                    exportCSV={this.exportCSV}
                                    textInput={this.textInput}
                                    handleClick={this.handleClick}
                                />
                            </CardDeck>
                        );
                    }):''
                }
            </div>
        );
    }
}


const mapStateToProps = state => {
    return {
        grievanceList: state.grievances.list,
        filterOptions: state.grievances.filterOptions,
        sortOrder: state.grievances.sortOrder
    };
}

export default connect(mapStateToProps, { getGrievancesList, getGrievancesFiltersOptions, getGrievancesSortOrder, applyGrievancesSorting, updateGrievancesFilter, applyGrievancesFilter, navigateSelections })(GrievancesOverview);
