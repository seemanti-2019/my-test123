import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history';
import { Row, Col, Form, Button, Card } from 'react-bootstrap';
import { getKeys } from '../../actions/index';


class Login extends React.PureComponent {


handleSubmit = () => {
    history.push('/home');
}

render() {    
    return (
        <Row className="justify-content-md-center">
            
            <Col md="auto" className="Login">
            <Card style={{width:'24em'}}>
                <Card.Body>
                    <Card.Title>PalmWise Login</Card.Title>
                    <Form onSubmit={(e)=> this.handleSubmit()}>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Email address</Form.Label>
                            <Form.Control type="email" placeholder="Enter email" />
                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="Password" />
                        </Form.Group>
                        <Button style={{color:'#fff', backgroundColor:'#638C1B', border:'none'}} type="submit">
                            Login
                        </Button>
                    </Form>
                </Card.Body>
            </Card>
            </Col>
            
        </Row>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { getKeys })(Login);
