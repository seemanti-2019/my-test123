import React from 'react';
import { connect } from 'react-redux';
import { Router, Switch, Route, Link } from 'react-router-dom';
import history from './history'
import { Navbar, Nav, Image} from 'react-bootstrap';
import Login from '../login/Login';
import Home from '../home/Home';
import SupplyChain from '../supplychain/Supplychain';
import Grievances from '../grievances/Grievances';
import OverView from '../grievances/GrievancesOverview';
import CoInvest from '../coinvest/CoInvest';
import ForestProtection from '../forestprotection/Forestprotection';
import GrievanceDetails from '../grievances/GrienvanceDetails';
import { navigateSelections } from '../../actions/index';
import CoinvestDetails from '../coinvest/CoInvestDetails';
import SupplyChainDetails from '../supplychain/SupplyChainDetails';

class RootNavigator extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }
  }

  navigateToHome = () => {
    this.props.navigateSelections('/home');
    history.push('/home')
  }

  handleUserSelection = event => {
    this.props.navigateSelections(event.target.pathname);
  }

  loadHeader(){
    if(window.location.pathname !== '/'){
    return(
      <Router history={history}>
        <Navbar sticky="top" expand="lg" style={{ background:'white', backgroundColor: 'white !important',boxShadow:  '0 5px 15px -6px #33333359',paddingBottom:0}}>
          <Navbar.Brand >
            < Image src={require("../../assets/Logo-2.png")} style={{ marginLeft: '1.7em', cursor: 'pointer' }} onClick={this.navigateToHome}/>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav" >
            <Nav className="ml-auto" >
              <Link className="custTag cust1" to="/home" onClick={this.handleUserSelection} >Home<hr className={this.props.selection.home}></hr></Link>
              <Link className="custTag cust1" to="/supplychain" onClick={this.handleUserSelection}>My Supply Chain<hr className={this.props.selection.sply}></hr></Link>
              <Link className="custTag cust1" to="/grievances" onClick={this.handleUserSelection}>My Grievances<hr className={this.props.selection.grivn}></hr></Link>
              <Link className="custTag cust1" to="/forestprotection" onClick={this.handleUserSelection}>Forest Protection<hr className={this.props.selection.fp}></hr></Link>
              {/* <Link className="custTag cust1" to="#">Human Rights</Link> */}
              <Link className="custTag cust1" to="/coinvest" onClick={this.handleUserSelection}>Co-Invest<hr className={this.props.selection.coIn}></hr></Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <Switch>
          <Route exact path="/home" component={Home} />
          <Route path="/supplychain" component={SupplyChain} />
          <Route path="/supplychaindetails" component={SupplyChainDetails} />
          <Route path="/grievances" component={Grievances} />
          <Route path="/grievancesoverview" component={OverView} />
          <Route path="/coinvest" component={CoInvest} />
          <Route path="/forestprotection" component={ForestProtection} />
          <Route path="/grievance-details/:id" render={
            ({ match }) => (
              <GrievanceDetails id={match.params.id} />
            )
          } />
          <Route path="/coinvestdetails/:id" render={
            ({ match }) => (
              <CoinvestDetails id={match.params.id} />
            )
          } />
        </Switch>
      </Router>
      )
    }else{
      return(
        <Login/>
      )
    }
  }

  render() {
    return (
      <div>
        {this.loadHeader()}
      </div>
      
    );
  }
}


const mapStateToProps = state => {
  return {
    selection: state.selection.navSelection,
  };
}

export default connect(mapStateToProps, { navigateSelections })(RootNavigator);