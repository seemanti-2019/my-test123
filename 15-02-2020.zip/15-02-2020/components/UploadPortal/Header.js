import React from 'react';

class Header extends React.Component {
  
  render() {
    return (
      <div className="row align-items-center my-5">
        <div className="col-md-2">
          <div className="custom-file">
            <label className="custom-file-upload" style={{ width: "100%" }}>
              <input type="file" style={{ display: "none" }} multiple onChange={this.props.onChangeHandler} />
              Add Files
            </label>
          </div>
        </div>
        <div className="col-md-2">
          <select className="custom-select" name="fileType" onChange={this.props.handleSelectChange}>
            <option defaultValue>File Type</option>
            <option value="CRTT">CRTT</option>
            <option value="Shipping">Shipping</option>
          </select>
        </div>
        <div className="col-md-2">
          <select className="custom-select" name="quarter" onChange={this.props.handleSelectChange}>
            <option defaultValue>Quarter</option>
            <option value="Q1">Quarter 1</option>
            <option value="Q2">Quarter 2</option>
            <option value="Q3">Quarter 3</option>
            <option value="Q4">Quarter 4</option>
          </select>
        </div>
        <div className="col-md-2">
          <select className="custom-select" name="year" onChange={this.props.handleSelectChange}>
            <option defaultValue>Year</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
          </select>
        </div>
        <div className="col-md-2">
          <select className="custom-select" name="destination" onChange={this.props.handleSelectChange}>
            <option defaultValue>Destination</option>
            <option value="Europe">Europe</option>
            <option value="Brazil">Brazil</option>
          </select>
        </div>
        <div className="col-md-2">
          <button type="button" className="btn btn-outline-secondary" style={{ width: "100%" }} onClick={this.props.onClickHandler}>Upload</button>
        </div>
      </div>
    )
  }
}

export default Header;