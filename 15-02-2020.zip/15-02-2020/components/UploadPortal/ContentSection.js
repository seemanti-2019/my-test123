import React from 'react';
import Header from './Header';
import MainBody from './MainBody';
import FileList from '../fileList.json';
import axios from 'axios';

class ContentSection extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fileData: FileList,
            checked: false,
            firstText: 0,
            selectedFiles: null,
            fileType: null,
            quarter: null,
            year: null,
            destination: null
        }
        this.state.fileData.map(item => {
            item.showError = false;
            return item;
        });
        console.log(this.state);
    }

    showHideError = id => {
        let fileData = [...this.state.fileData];
        fileData.map(item => {
            if (item.id === id) {
                item.showError = !item.showError;
            } else {
                item.showError = false;
            }
            return item;
        });
        return this.setState({ fileData });
    }

    /* sorting list based on fields like - quarter*/
    /* TO BE ADDED LATER */
    sortFileList = () => {
        this.setState({
            fileData: this.state.fileData.sort((a, b) => (a.quarter > b.quarter) ? 1 : ((b.quarter > a.quarter) ? -1 : 0))
        });
    }

    handleSelectChange = (e) => {
        const { name, value } = e.target;
        this.setState({
            [name]: value
        });
        console.log(this.state);
    }


    deleteFileData = deletePostId => {
        let r = window.confirm("Are you sure you want to delete!");
        if (r === true) {
            this.setState({
                fileData: this.state.fileData.filter(item => item.id !== deletePostId)
            })
        }
    }
    onChangeHandler = e => {
        console.log(e.target.files);
        this.setState({
            selectedFiles: e.target.files
        });
        console.log(this.state);

    }
    onClickHandler = () => {
        const bodyFormData = new FormData();
        if (this.state.selectedFiles) {
            let cnt = this.state.fileData.length; 
            if (this.state.fileType && this.state.quarter && this.state.year && this.state.destination) {
                for (let x = 0; x < this.state.selectedFiles.length; x++) {
                    cnt++;
                    console.log(this.state.selectedFiles[x]);
                    bodyFormData.append('file', this.state.selectedFiles[x]);
                    this.setState({
                        fileData: [...this.state.fileData, {
                            "id": cnt,
                            "fileName": this.state.selectedFiles[x].name,
                            "fileType": this.state.fileType,
                            "quarter": this.state.year+'-'+this.state.quarter,
                            "time": "10:10",
                            "status": "Success"
                        }]
                    });
                    /*axios({
                    method: 'post',
                    url: 'http://localhost:8000/upload',
                    data: bodyFormData,
                    headers: { 'Content-Type': 'multipart/form-data', }
                })
                    .then(response => {
                        console.log(response)
                    })
                    .catch(error => {
                        console.log(error)
                    });*/
                }
            } else {
                alert('please select all required fields');
            }
        } else {
            alert('please select a file');
        }
    }
    render() {
        const fileListToShow = [...FileList];
        const showSuccessRejected = (status) => {
            switch (status) {
                case 'success': {
                    this.setState({ fileData: fileListToShow.filter(file => file.status === 'Success') });
                    break;
                }
                case 'rejected': {
                    this.setState({ fileData: fileListToShow.filter(file => file.status === 'Rejected') });
                    break;
                }
                default: {
                    break;
                }
            }
        }

        const handleChange = () => {
            this.setState({ firstText: 1 });
            this.setState((prevState) => {
                return { checked: !(prevState.checked) }
            });
            console.log(this.state);
            if (this.state.checked === true) {
                showSuccessRejected('rejected');
            } else {
                showSuccessRejected('success');
            }
        }

        return (
            <div className="container" >
                <Header
                    handleSelectChange={this.handleSelectChange}
                    onChangeHandler={this.onChangeHandler}
                    onClickHandler={this.onClickHandler}
                />
                <MainBody
                    fileData={this.state.fileData}
                    checked={this.state.checked}
                    firstText={this.state.firstText}
                    handleChange={handleChange}
                    showHideError={this.showHideError}
                    deleteFileData={this.deleteFileData}
                />
            </div>
        )
    }
}
export default ContentSection;