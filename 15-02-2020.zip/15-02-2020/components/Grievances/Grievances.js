import React from 'react';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import GrievanceData from './grievancesList.json';

class Grievances extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            listToShow: null,
            filterName: null,
            venture: null,
            status: null,
            country: null,
            date: 'desc',
            ref: React.createRef(),
            grievanceList: GrievanceData.sort((a, b) => (a.date < b.date) ? 1 : ((b.date < a.date) ? -1 : 0))
        }
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.state.ref;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }
    handleClick = (id) => {
        this.props.history.push(`/grievance-details/${id}`);
    }
    countryFilter = (e) => {
        const fieldName = e.target.name;
        this.setState({ filterName: fieldName})
        this.setState({ [fieldName]: e.value });
        const listToShow = [...GrievanceData];
        this.setState({
            listToShow: listToShow.filter(item => item[fieldName] === e.value)
        });
    }
    sortDatewise = (e) => {
        this.setState({ date: e.value });
        const listToShow = [...GrievanceData];
        switch (e.value) {
            case 'asc': {
                this.setState({
                    grievanceList: listToShow.sort((a, b) => (a.date > b.date) ? 1 : ((b.date > a.date) ? -1 : 0))
                });
                break;
            }
            case 'desc': {
                this.setState({
                    grievanceList: listToShow.sort((a, b) => (a.date < b.date) ? 1 : ((b.date < a.date) ? -1 : 0))
                });
                break;
            }
            default: 
                break;            
        }
    }

    applyFilter = () => {
        if (this.state.listToShow) {
            this.setState({
                grievanceList: this.state.listToShow
            })
        }
    }
    
    render() {
        const ventureItems = [
            { label: 'Lorem Ipsum', value: 'LI1' },
            { label: 'Lorem Ipsum', value: 'LI2' },
            { label: 'Lorem Ipsum', value: 'LI3' }
        ];
        const statusItems = [
            { label: 'Investigation', value: 'Investigation' },
            { label: 'Verification', value: 'Verification' },
            { label: 'Implementation of action plan', value: 'Implementation of action plan' },
            { label: 'Monitoring Implementation', value: 'Monitoring Implementation' },
            { label: 'Completed', value: 'Completed' }
        ];
        const countryItems = [
            { label: 'Indonasia', value: 'Indonasia' },
            { label: 'Malaysia', value: 'Malaysia' }
        ];
        const filterItems = [
            { label: 'Oldest', value: 'asc' },
            { label: 'Latest', value: 'desc' },
        ];
        const dataList = this.state.grievanceList.map((data) => {
            return (
                <div className="card my-5" key={data.id}>
                    <div className="card-body">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-10">
                                    <h3 style={{ paddingBottom: '5px' }}>{data.name}</h3>
                                    <p><strong>Entity </strong><span>{data.entity}</span></p>
                                    <p><strong>Status </strong><span>{data.status}</span></p>
                                    <div className="row">
                                        <div className="col-md-3">
                                            <Button style={{ backgroundColor: '#fff', width: '100%', color: '#000', border: '1px solid black' }} label="See grievances" onClick={() => this.handleClick(data.id)} />
                                        </div>
                                        <div className="col-md-9">
                                            <a style={{ display: 'none' }} href='empty' ref={this.state.ref}>ref</a>
                                            <Button style={{ backgroundColor: '#000', width: '30%' }} label="Download statement" onClick={this.exportCSV} />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-2">
                                    <span>{data.date}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        });
        return (
            <div className="container">
                <div className="card my-4">
                    <div className="card-body">
                        <h1>Grievances overview</h1>
                        <p>Felda Global Ventures</p>
                        <div className="row align-items-center">
                            <div className="col-md-2">
                                <Dropdown value={this.state.venture} options={ventureItems} onChange={(e) => this.setState({ venture: e.value }) } name="test" placeholder="Felda Global Ventures" />
                            </div>
                            <div className="col-md-3">
                                <Dropdown value={this.state.status} options={statusItems} onChange={(e) => this.countryFilter(e) } name="status" placeholder="Status" style={{width: '100%',marginLeft: '13px'}}/>
                            </div>
                            <div className="col-md-2">
                                <Dropdown value={this.state.country} options={countryItems} onChange={(e) => this.countryFilter(e) } name="country" placeholder="Country" />
                            </div>
                            <div className="col-md-2">
                                <Dropdown value={this.state.date} options={filterItems} onChange={(e) => this.sortDatewise(e) } name="date" />
                            </div>
                            <div className="col-md-3">
                                <Button style={{ backgroundColor: 'black', width: '65%' }} onClick={() => this.applyFilter() } label="Apply Filter" />
                            </div>
                        </div>
                    </div>
                </div>
                <div>{this.state.grievanceList.length} results</div>
                {dataList}
            </div>
        )
    }
}

export default Grievances;