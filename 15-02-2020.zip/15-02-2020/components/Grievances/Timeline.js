import React from 'react';

class Timeline extends React.Component {
    render() { 
    this.statusFlag = false;
    if(this.props.timelineData.length>4)
        this.statusFlag = true;
    const reverseData = this.props.timelineData.map((data) => {
        if(this.props.status === data.text){
            this.statusFlag = false;
        } 
        return (
            <div key={data.id} className="timeline-article timeline-article-top" style={{ minHeight: this.props.timelineData.length<=4?"160px":"" }}>
                {
                (data.suspended)? ( 
                <div className="content-data">
                    <span className="author">Suspended</span>
                    <div id="circle"></div>
                    <div className="vertical-line"></div>
                </div>):('')
                }                                                
                <div className={"meta-data" + ((data.active === false || this.statusFlag === true)? "-grey" : "")} style={{cursor: this.props.timelineData.length>4?"pointer":""}} onClick={this.props.timelineData.length>4 ? () => this.props.showTooltip(data.id) : undefined }
 >                   <div className="meta-separator"></div>
                </div>
                <div className="content-title">
                    {data.text}
                </div>
                {
                ((this.props.timelineData.length>4 && this.statusFlag === false) && data.text !== 'Completed')? (    
                <div className="content-box" style={{display: data.showTooltip === true? "block":"none"}}>
                    <div style={{fontSize:'16px', textAlign: 'center'}}>Status Investigation</div>
                    <div style={{fontSize: '11px', textAlign: 'center'}}>Action Cargill has taken</div>
                    <p>{data.tooltipText}</p>
				    {/* <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod</p> */}
				</div>): ('')
                }
            </div>
        )
    })
    return (
        <div className="col-md-12 col-sm-12 col-xs-12">
            <section className={"main-timeline-section " + (this.props.timelineData.length> 4? 'top': '')} >
                <div className={"conference-center-line-bottom " + (this.props.timelineData.length> 4? 'top': '')}></div>
                <div className="conference-timeline-content">
                    {reverseData}                    
                </div>
            </section>
        </div>
    )
    }
}
export default Timeline;