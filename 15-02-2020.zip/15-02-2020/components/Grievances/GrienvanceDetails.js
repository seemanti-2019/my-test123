import React from 'react';
import Map from '../../images/map.png';
import GrievanceData from './grievancesList.json';
import Timeline from './Timeline';
import DownloadPanel from './DownloadPanel';

class GrievanceDetails extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            ref : React.createRef(),
            timelineTop : [
                {  id: 1, text: "Investigation", active: true, suspended: false, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) '},
                {  id: 2, text: "Verification", active: true, suspended: true, showTooltip: false,tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 3, text: "Implementation of action plan", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 4, text: "Monitoring Implementation", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 5, text: "Completed", active: true, suspended: false, showTooltip: false },
            ].reverse(),
            timelineBottom : [
                {  id: 1, text: "2017", active: false, suspended: false },
                {  id: 2, text: "2018", active: false, suspended: false },
                {  id: 3, text: "2019", active: false, suspended: false },
                {  id: 4, text: "2020", active: true, suspended: false }
            ].reverse()
        };
        
    }
    showTooltip = id => {
        let listData = [...this.state.timelineTop];
        listData.map(item => {
            if (item.id === id) {
                item.showTooltip = !item.showTooltip;
            } else {
                item.showTooltip = false;
            }
            return item;
        });
        return this.setState({timelineTop: listData });
    }
    render() {
        const gid = +this.props.id;
        let detailData;        
        GrievanceData.map(item => {
            if(item.id === gid){
                detailData = item;
            }
            return detailData;
        });
        
        return (
            <div className="container">
                <div className="card my-4">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-md-12">Felda Global Ventures</div>
                        </div>
                        <div className="row">
                            <div className="col-md-12 my-1">
                                <h2>{detailData.name}</h2>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-5">
                                        <div className="row">
                                            <div className="col-md-12">
                                                <h6>{detailData.subHeading}</h6>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-12">
                                                {detailData.description}
                                            </div>
                                        </div>
                                        <div className="my-5">
                                            <div className="row mt-2">
                                                <div className="col-md-4">
                                                    Grievance Entity
                                                </div>
                                                <div className="col-md-8">
                                                    {detailData.entity}
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                <div className="col-md-4">
                                                    Grievance raiser
                                                </div>
                                                <div className="col-md-8">
                                                    {detailData.raiser}
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                <div className="col-md-4">
                                                    Date raised
                                                </div>
                                                <div className="col-md-8">
                                                    {detailData.date}
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                <div className="col-md-4">
                                                    Source
                                                </div>
                                                <div className="col-md-8">
                                                    {detailData.source}
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                <div className="col-md-4">
                                                    Last Updated
                                                </div>
                                                <div className="col-md-8">
                                                    {detailData.lastUpdated}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <Timeline timelineData={this.state.timelineTop} status={detailData.status} showTooltip={this.showTooltip}/>                        
                        <div className="row">
                            <div className="col-md-12">
                                <img src={Map} width="100%" height="400" alt="map " />
                            </div>
                        </div>                        
                        <Timeline timelineData={this.state.timelineBottom}/>
                    </div>
                </div>                
                <div className="card my-5">
                    <div className="container">
                        <DownloadPanel />                        
                    </div>
                </div>
            </div>
        );
    }
}

export default GrievanceDetails;