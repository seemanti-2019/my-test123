import React from 'react';
import DownloadIcon from '../../images/download_icon.png';

class DownloadPanel extends React.Component {
    constructor(props) {
        super(props);
        this.textInput = React.createRef();
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.textInput;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }
    render() {
        return (
            <div className="row">
                <div className="col-md-3" style={{ backgroundColor: '#519230e6', height: '5rem', borderRadius: '5px 0 0 5px' }}>
                    <div className="row" style={{ paddingLeft: '40%', color: 'white', paddingTop: '2%' }}>
                        <span>Downloads</span>
                    </div>
                    <div className="row" style={{ paddingLeft: '45%', color: 'white', paddingTop: '2%' }}>
                        <img src={DownloadIcon} height="40" width="40" alt="download" />
                    </div>
                </div>
                <div className="col-md-4">
                    <a style={{ display: 'none' }} href='empty' ref={this.textInput}>ref</a>
                    <div style={{ textAlign: "center", marginTop: "22px", cursor: "pointer" }} onClick={() => this.exportCSV()}>
                        <i className="fa fa-long-arrow-down" style={{ fontSize: "15px", paddingRight: "10px", fontWeight: "800" }}></i>
                        Cargill statement
                    </div>
                </div>
                <div className="col-md-5">
                    <a style={{ display: 'none' }} href='empty' ref={this.textInput}>ref</a>
                    <div style={{ marginTop: "22px", cursor: "pointer" }} onClick={() => this.exportCSV()}>
                        <i className="fa fa-long-arrow-down" style={{ fontSize: "15px", paddingRight: "10px", fontWeight: "800" }}></i>
                        Grievance report
                    </div>
                </div>
            </div>
        )
    }
}

export default DownloadPanel;