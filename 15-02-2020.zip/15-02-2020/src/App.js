import React from 'react';
// import NavBar from './components/NavBar';
// import Footer from './components/Footer';
// import ContentSection from './components/ContentSection';
import Grievances from './components/Grievances/Grievances';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import GrievanceDetails from './components/Grievances/GrienvanceDetails';

function App() {
  return (
    <div>
      <Router>
        <Route path="/" exact strict component={Grievances} />
        <Route path="/grievance-details/:id" render={
              ({match})=> (
                  <GrievanceDetails id={match.params.id} />
              )          
            } />
        {/* <Route path='*' exact component={Grievances} />     */}
      </Router>
      {/*<Grievances />*/}
      {/* <NavBar /> 
      <ContentSection />
      <Footer />     */}
    </div>
  );
}

export default App;
