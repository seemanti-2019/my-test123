import { combineReducers } from 'redux';
import UploadReducer from './UploadReducer';
import HistoryReducer from './HistoryReducer';

export default combineReducers({
    uploaded: UploadReducer,
    history: HistoryReducer
})