import { GET_UPLOAD_DATA, GET_USER_DATA } from '../actions/types';


const INITIAL_STATE = {
    uploadedFileList: {},
    userData: '',
};

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {
        case GET_UPLOAD_DATA:
            return { ...state, uploadedFileList: action.payload };
        case GET_USER_DATA:
            return { ...state, userData: action.payload }   
        default:
            return state;
    }
}