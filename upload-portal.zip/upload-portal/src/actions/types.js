export const GET_UPLOAD_DATA = 'get_uploaded_file_list';
export const GET_URL = 'https://palmwise-upload-api.dev.dev-cglcloud.com/';
export const GET_USER_DATA = 'get_user_data';
export const GET_HISTORY_DATA = 'get_history_data';