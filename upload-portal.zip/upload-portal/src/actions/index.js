import { GET_UPLOAD_DATA, GET_URL, GET_USER_DATA, GET_HISTORY_DATA } from './types';
import Axios from 'axios';

let uploadedList = [];
let typeOfData = '';
export const getUploadedFileList = () => {
    return (dispatch) => {
        dispatch({ type: GET_UPLOAD_DATA, payload: null });
    };
};

export const uploadSelectedFiles = (selectedData, selectedFiles, username) => {
    console.log('selectedData', selectedData);
    var dest = '';
    var type = '';
    switch (selectedData.destination) {
        case 'Europe': {
            dest = 'EU'
            break;
        }
        case 'Brazil': {
            dest = 'BR'
            break;
        }
        default:
            break;
    }
    switch (selectedData.typeOfData) {
        case 'Shipment': {
            type = 'shipment';
            break;
        }
        case 'CRTT': {
            type = 'crtt';
            break;
        }
        default:
            break;
    }

    const formData = new FormData();
     formData.append('file_type',type);
     formData.append('file_quarter',selectedData.quarter);
     formData.append('file_year',selectedData.year);
     formData.append('file_dest_market',dest);
     formData.append('username', username)
    for (var i = 0; i < selectedFiles.length; i++) {
        formData.append('input_files', selectedFiles[i]);
    }


    return (dispatch) => {
        //dispatch({ type: GET_UPLOAD_DATA, payload: uploadedDetail});
        const fileUploadURL = GET_URL + "palmwise-file-upload";

        Axios.post(fileUploadURL, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(response => {
                if (response.data) {
                    dispatch({ type: GET_UPLOAD_DATA, payload: response.data })
                }
            })
            .catch(error => {
                console.log(error);
            })
    }
}

export const filterUploadedData = (param) => {
    let uploadedDetail = {};
    let list = uploadedList;

    return (dispatch) => {
        if (param !== 'All') {
            list = list.filter((item) => item.status === param)
        }

        uploadedDetail.typeOfData = typeOfData;
        uploadedDetail.list = list;

        dispatch({ type: GET_UPLOAD_DATA, payload: uploadedDetail });
    };
};

export const setUserDetail = (username) => {
    return (dispatch) => {
        dispatch({ type: GET_USER_DATA, payload:  username});
    }
}

export const getHistoryData = (uname) => {
    return (dispatch) => {
        const historyURL = GET_URL + "get-file-records";
        Axios.get(historyURL, { params: {username : uname} })
            .then(response => {
                if (response.data) {
                    dispatch({ type: GET_HISTORY_DATA, payload: response.data })
                }
            })
            .catch(error => {
                console.log(error);
            })
    }
}