import React from 'react';
import { Row, Col, Card, CardDeck, Dropdown, Image, Modal, Button } from 'react-bootstrap';
import { connect } from 'react-redux';
import history from './header/history';
import { getUploadedFileList, uploadSelectedFiles, filterUploadedData, setUserDetail } from '../actions/index';
import { FaTrashAlt } from 'react-icons/fa';


class Dashboard extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            typeOfData: null,
            year: null,
            quarter: null,
            destination: null,
            status: null,
            show: false,
            showSelectedFiles: false
        }
        this.selectedFiles = null;
        this.uploadedData = null;
    }

    componentDidMount = () => {
        this.props.getUploadedFileList();
        this.props.setUserDetail(this.props.username);
    }

    setFilter = (field, value) => {
        switch (field) {
            case "typeOfData":
                this.setState({ typeOfData: value })
                break;
            case "year":
                this.setState({ year: value })
                break;
            case "quarter":
                this.setState({ quarter: value })
                break;
            case "destination":
                this.setState({ destination: value })
                break;
            case "status":
                this.setState({ status: value })
                this.props.filterUploadedData(value);
                break;
            default:
                break;
        }
    }

    handleLogout = () => {
        history.push('/');
    }

    handleDashboard = () => {
        history.push('/dashboard/' + this.props.username);
    }
    handleFileHistory = () => {
        history.push('/filehistory/' + this.props.username);

    }

    handleUploadButtonClick = (e) => {
        if (this.state.typeOfData && this.state.quarter && this.state.destination && this.state.year) {
            return;
        } else {
            alert('Please select all mandatory fields!!');
            e.preventDefault();
            return;
        }
    }

    showModal = () => {
        this.setState({ showSelectedFiles: false });
        this.setState({ show: true });
    }

    closeModal = () => {
        this.setState({ show: false });
    }

    handleUpload = () => {
        this.props.uploadSelectedFiles(this.state, this.selectedFiles, this.props.username);
        this.setState({ isLoading: true });
        this.setState({ show: true });
    }
    handleDelete = () => {

    }
    renderFilelist = (list) => {
        var listFormat = [];
        for (var i = 0; i < list.length; i++) {
            listFormat.push(<Row key={i}><Col>{list[i].name}</Col>
            {/* <Col><FaTrashAlt style={{ cursor: 'pointer' }} onClick={() => this.handleDelete()} /></Col> */}
            </Row>)
        }
        return listFormat;
    }
    showSelectedFiles = () => {
        this.setState({ showSelectedFiles: true });
    }

    cancelSelected = () => {
        this.setState({ showSelectedFiles: false });
    }

    onFileChangeHandler = (e) => {
        e.preventDefault();
        this.selectedFiles = e.target.files;
        //this.showModal();
        this.showSelectedFiles();
    };

    render() {
        return (
            <div>
                <CardDeck>
                    <Card>
                        <Card.Body style={{ padding: '.5rem' }}>
                            <Row>
                                <Col md={2}>
                                    <div style={{ paddingLeft: '6rem' }}><Image src={require("../assets/Group_518@2x.png")} height="50" />
                                        <span style={{ paddingLeft: '.4rem', verticalAlign: 'top', position: 'absolute' }}>Palmwise Upload Portal</span>
                                    </div>
                                </Col>
                                <Col md={8}></Col>
                                <Col md={2} style={{ fontSize: '16px', paddingTop: '.5rem' }}>
                                    <Row>
                                        <Col md={2}>
                                            <div style={{ borderRadius: '50%', height: '40px', width: '40px', backgroundColor: 'black', color: "white", textAlign: "center", paddingTop: '.5rem' }}>
                                                {this.props.username.charAt(0).toUpperCase()}
                                            </div>
                                        </Col>
                                        <Col md={3} style={{ paddingTop: '.4rem' }}>{this.props.username.charAt(0).toUpperCase() + this.props.username.slice(1)}</Col>
                                        <Col md={3} style={{}}>
                                            <Dropdown>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic">
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu>
                                                    <Dropdown.Item href="/">Logout</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </CardDeck>
                <div style={{ padding: '3em 3rem 3rem 6rem', backgroundColor: '#F5F5F5' }}>
                    <Row>
                        <Col md={2} >
                            <CardDeck style={{ minHeight: '600px' }}>
                                <Card>
                                    <Card.Body>
                                        <Row style={{ marginTop: '2rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem' }}>
                                                <Image src={require('../assets/File_history.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleFileHistory()}>File history</span>
                                            </Col>
                                        </Row>
                                        <Row style={{ marginTop: '1rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem', backgroundColor: '#739900', borderBottomRightRadius: '30px', borderTopRightRadius: '30px' }}>
                                                <Image src={require('../assets/Upload_file-w.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleDashboard()}>Upload File</span>
                                            </Col>
                                        </Row>
                                        <Row style={{ marginTop: '18rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem' }}>
                                                <Image src={require('../assets/Logout.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleLogout()}>Logout</span>
                                            </Col>
                                        </Row>
                                    </Card.Body>
                                </Card>
                            </CardDeck>
                        </Col>
                        {(this.state.showSelectedFiles) ?
                            (
                                <Col md={10}>
                                    <CardDeck style={{ padding: '0 1.5em' }}>
                                        <Card style={{ padding: '2rem', height: '600px' }}>
                                            <Row>
                                                <Col>
                                                    <Row style={{ marginTop: '2rem', marginBottom: '1rem', textAlign: 'center',fontSize: '1.2rem' }}>
                                                        <Col style={{ textAlign: 'left' }}>Filename</Col>
                                                        <Col></Col>
                                                    </Row>
                                                    {(this.selectedFiles) ?
                                                        this.renderFilelist(this.selectedFiles) : ''
                                                    }
                                                </Col>
                                            </Row>
                                            <Row style={{marginTop:'400px'}}>
                                                <Col style={{textAlign:'right'}}>
                                                    <Button style={{ margin: '1rem' }} variant="dark" onClick={this.handleUpload}>Upload</Button>
                                                    <Button style={{ margin: '1rem' }} variant="outline-dark" onClick={this.cancelSelected}>Cancel</Button>
                                                </Col>
                                            </Row>
                                        </Card>
                                    </CardDeck>
                                </Col>
                            ) : (
                                <Col md={10}>
                                    <Row>
                                        <Col style={{ fontSize: '2rem' }}>Select The Fields</Col>
                                    </Row>
                                    <Row style={{ marginTop: '2rem' }} >
                                        <Col md={2} >
                                            <Dropdown onSelect={(e) => this.setFilter('typeOfData', e)}>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic"
                                                    style={{ backgroundColor: 'white', border: "1px solid lightgrey", width: '100%', color: 'grey', borderRadius: '0' }}>
                                                    {(this.state.typeOfData) ? this.state.typeOfData : 'Type Of Data'}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu style={{ width: "100%" }}>
                                                    <Dropdown.Item eventKey="Shipment" key={1}>Shipment</Dropdown.Item>
                                                    <Dropdown.Item eventKey="CRTT" key={2}>CRTT</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                        <Col md={2}>
                                            <Dropdown onSelect={(e) => this.setFilter('year', e)}>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic"
                                                    style={{ backgroundColor: 'white', border: "1px solid lightgrey", width: '100%', color: 'grey', borderRadius: '0' }}>
                                                    {(this.state.year) ? this.state.year : 'Year'}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu style={{ width: "100%" }}>
                                                    <Dropdown.Item eventKey="2019" key={1}>2019</Dropdown.Item>
                                                    <Dropdown.Item eventKey="2020" key={2}>2020</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                        <Col md={2}>
                                            <Dropdown onSelect={(e) => this.setFilter('quarter', e)}>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic"
                                                    style={{ backgroundColor: 'white', border: "1px solid lightgrey", width: '100%', color: 'grey', borderRadius: '0' }}>
                                                    {(this.state.quarter) ? this.state.quarter : 'Quarter'}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu style={{ width: "100%" }}>
                                                    <Dropdown.Item eventKey="Q1" key={1}>Q1</Dropdown.Item>
                                                    <Dropdown.Item eventKey="Q2" key={2}>Q2</Dropdown.Item>
                                                    <Dropdown.Item eventKey="Q3" key={3}>Q3</Dropdown.Item>
                                                    <Dropdown.Item eventKey="Q4" key={4}>Q4</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                        <Col md={2}>
                                            <Dropdown onSelect={(e) => this.setFilter('destination', e)}>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic"
                                                    style={{ backgroundColor: 'white', border: "1px solid lightgrey", width: '100%', color: 'grey', borderRadius: '0' }}>
                                                    {(this.state.destination) ? this.state.destination : 'Destination Market'}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu style={{ width: "100%" }}>
                                                    <Dropdown.Item eventKey="Europe" key={1}>Europe</Dropdown.Item>
                                                    <Dropdown.Item eventKey="Brazil" key={2}>Brazil</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                        <Col md={2}>
                                            <label style={{ backgroundColor: '#739900', cursor: 'pointer', width: '80%', height: '100%', paddingTop: '5px', color: '#fff', textAlign: 'center' }} variant="outline-secondary">
                                                <input type="file" name="file" accept=".xlsx, .xls"
                                                    style={{ display: "none" }} multiple onClick={(e) => this.handleUploadButtonClick(e)} onChange={(e) => { this.onFileChangeHandler(e) }} />

                                        Add File
                                    </label>
                                        </Col>
                                    </Row>
                                </Col>
                            )}
                    </Row>
                    <div className="modal-container">
                        <Modal
                            size="ls"
                            show={this.state.show}
                            onHide={() => this.closeModal()}
                            aria-labelledby="contained-modal-title"
                        >
                            {(this.props.uploadedData) ?
                                (
                                    <Modal.Body>
                                        <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '1.2em', color: 'Green' }}>
                                            File Upload Completed. To view uploaded file status please select <strong>File history tab</strong>
                                        </div>
                                    </Modal.Body>
                                ) : (
                                    <Modal.Body>
                                            <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '1.2em' }}>
                                                Upload in progress ...
                                            </div>
                                    </Modal.Body>
                                )}
                            {(this.props.uploadedData) ?
                                (
                                    <div style={{padding:'2rem',textAlign: 'right'}}>
                                        <Button variant="outline-dark" onClick={() => this.handleFileHistory()} style={{marginRight:'1rem'}}>View History</Button>
                                        <Button variant="outline-dark" onClick={() => this.closeModal()}>Close</Button>
                                    </div>
                                ) : ''
                            }
                        </Modal>
                    </div>
                </div>
            </div>
        );

    }
}

const mapStateToProps = state => {
    console.log('state', state);
    return {
        uploadedData: state.uploaded.uploadedFileList
    };
}

export default connect(mapStateToProps, { getUploadedFileList, uploadSelectedFiles, filterUploadedData, setUserDetail })(Dashboard);