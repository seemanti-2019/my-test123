import React from 'react';
import history from './header/history';
import { connect } from 'react-redux';
import { getUploadedFileList, getHistoryData } from '../actions/index';
// import { FaArrowDown, FaTrashAlt, FaCaretDown } from 'react-icons/fa';



import { Row, Col, CardDeck, Card, Image, Dropdown, Button } from 'react-bootstrap';


class Filehistory extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            username: ''
        }
    }

    componentDidMount = () => {
        this.props.getUploadedFileList();
        this.props.getHistoryData(this.props.username);
        this.setState({ username: this.props.uploadData.userData })
    }
    
    handleRefresh = () => {
        this.props.getHistoryData(this.props.username);
    }

    handleLogout = () => {
        history.push('/');
    }

    handleDashboard = () => {
        history.push('/dashboard/' + this.props.username);
    }

    handleFileHistory = () => {
        history.push('/filehistory/' + this.props.username);
    }

    render() {

        return (
            <div>
                <CardDeck>
                    <Card>
                        <Card.Body style={{ padding: '.5rem' }}>
                            <Row>
                                <Col md={2}>
                                    <div style={{ paddingLeft: '6rem' }}><Image src={require("../assets/Group_518@2x.png")} height="50" />
                                        <span style={{ paddingLeft: '.4rem', verticalAlign: 'top', position: 'absolute' }}>Palmwise Upload Portal</span>
                                    </div>
                                </Col>
                                <Col md={8}></Col>
                                <Col md={2} style={{ fontSize: '16px', paddingTop: '.5rem' }}>
                                    <Row>
                                        <Col md={2}>
                                            <div style={{ borderRadius: '50%', height: '40px', width: '40px', backgroundColor: 'black', color: "white", textAlign: "center", paddingTop: '.5rem' }}>
                                                {this.props.username.charAt(0).toUpperCase()}
                                            </div>
                                        </Col>
                                        <Col md={3} style={{ paddingTop: '.4rem' }}>{this.props.username.charAt(0).toUpperCase() + this.props.username.slice(1)}</Col>
                                        <Col md={3} style={{}}>
                                            <Dropdown>
                                                <Dropdown.Toggle variant="light" id="dropdown-basic">
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu>
                                                    <Dropdown.Item href="/">Logout</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </CardDeck>
                <div style={{ padding: '3em 3rem 3rem 6rem', backgroundColor: '#F5F5F5' }}>
                    <Row>
                        <Col md={2} >
                            <CardDeck style={{ minHeight: '600px' }}>
                                <Card>
                                    <Card.Body>
                                        <Row style={{ marginTop: '2rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem' }}>
                                                <Image src={require('../assets/File_history.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleFileHistory()}>File history</span>
                                            </Col>
                                        </Row>
                                        <Row style={{ marginTop: '1rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem', backgroundColor: '#739900', borderBottomRightRadius: '30px', borderTopRightRadius: '30px' }}>
                                                <Image src={require('../assets/Upload_file-w.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleDashboard()}>Upload File</span>
                                            </Col>
                                        </Row>
                                        <Row style={{ marginTop: '18rem' }}>
                                            <Col md={5} style={{ padding: '1rem 2rem 0 3rem' }}>
                                                <Image src={require('../assets/Logout.png')} height="30" />
                                            </Col>
                                            <Col md={7} style={{ padding: '1rem .5rem' }}>
                                                <span style={{ cursor: 'pointer' }} onClick={() => this.handleLogout()}>Logout</span>
                                            </Col>
                                        </Row>
                                    </Card.Body>
                                </Card>
                            </CardDeck>
                        </Col>
                        <Col md={10}>
                            <CardDeck style={{ padding: '0 1.5em' }}>
                                <Card style={{ width: '100%', height: '600px' }}>
                                    <Col>
                                        <Row style={{marginBottom:'0'}}>
                                            <Col md={4} style={{padding:'1.5rem 2rem 0 2rem',fontSize: '1.5rem' }}>File History</Col>
                                            <Col md={8} style={{padding:'1.5rem 2rem 0 2rem',textAlign:'right' }}><Button variant="dark" onClick={this.handleRefresh}>Refresh</Button></Col>
                                        </Row>
                                        <Row style={{ marginTop: '2rem', marginBottom: '1rem', textAlign: 'center' }}>
                                            <Col>Filename</Col>
                                            <Col>Quarter</Col>
                                            <Col>Year</Col>
                                            <Col>Type</Col>
                                            <Col>Status</Col>
                                            <Col>Date Of Upload</Col>
                                            {/* <Col>
                                                <Dropdown onSelect={(e) => this.setFilter('status', e)}>
                                                    <Dropdown.Toggle variant="light" id="dropdown-basic"
                                                        style={{ backgroundColor: 'white', border: "1px solid lightgrey", width: '100%', color: 'grey', borderRadius: '0' }}>
                                                        {(this.state.status) ? this.state.status : 'All'}
                                                    </Dropdown.Toggle>
                                                    <Dropdown.Menu style={{ width: "100%" }}>
                                                        <Dropdown.Item eventKey="All" key={4}>All</Dropdown.Item>
                                                        <Dropdown.Item eventKey="Success" key={1}>Success</Dropdown.Item>
                                                        <Dropdown.Item eventKey="Rejected" key={2}>Rejected</Dropdown.Item>
                                                        <Dropdown.Item eventKey="Progress" key={3}>Progress</Dropdown.Item>
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                            </Col> */}
                                        </Row>
                                        <div style={{float:'left',width:'100%', overflowY: 'auto',maxHeight: '450px',padding: '0 1rem'}} >
                                        {
                                        (this.props.historyData.length > 0) ? this.props.historyData.map((item, i) => {
                                            
                                            return (
                                                <CardDeck key={i} style={{ marginTop: '.5rem', textAlign: 'center' }}>
                                                    <Card>
                                                        <Row style={{ 
                                                            padding: '1rem 0'}}>
                                                            <Col>{item.file_name}</Col>
                                                            <Col>{item.file_quarter}</Col>
                                                            <Col>{item.file_year}</Col>
                                                            <Col>{item.file_type}</Col>
                                                            <Col>{item.file_status}</Col>
                                                            <Col>{item.file_upload_date}</Col>
                                                        </Row>
                                                    </Card>
                                                </CardDeck>)
                                        }) : (<CardDeck><Card>No Files Uploaded</Card></CardDeck>)
                                        }
                                        </div>
                                    </Col>
                                </Card>
                            </CardDeck>
                        </Col>
                    </Row>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    console.log('state', state);
    return {
        uploadData: state.uploaded,
        historyData: state.history.fileHistory
    };
}

export default connect(mapStateToProps, { getUploadedFileList, getHistoryData })(Filehistory);
