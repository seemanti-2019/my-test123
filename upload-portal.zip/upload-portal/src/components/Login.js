import React from 'react';
import history from './header/history'

import { Row, Col, Card,CardDeck, Button,Form, Image } from 'react-bootstrap';


class Login extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: ''
        }
        
    }
    
    handleClick = (event) => {
        console.log('event', event.target.value);

        if(this.state.username && this.state.password){
          if(this.state.username === 'user@cargill.com'){
            var name   = this.state.username.substring(0, this.state.username.lastIndexOf("@"));
            history.push('/dashboard/'+name)
          } else {
            alert('please enter correct username!!');
          }
        } else {
          alert('username and password both are required!!');
        }
        //console.log('pwd', this.state.username);
    // var apiBaseUrl = "http://localhost:4000/api/";
    // var self = this;
    // var payload={
    // "email":this.state.username,
    // "password":this.state.password
    // }
    // axios.post(apiBaseUrl+'login', payload)
    // .then(function (response) {
    // console.log(response);
    // if(response.data.code == 200){
    // console.log("Login successfull");
    // var uploadScreen=[];
    // uploadScreen.push(<UploadScreen appContext={self.props.appContext}/>)
    // self.props.appContext.setState({loginPage:[],uploadScreen:uploadScreen})
    // }
    // else if(response.data.code == 204){
    // console.log("Username password do not match");
    // alert("username password do not match")
    // }
    // else{
    // console.log("Username does not exists");
    // alert("Username does not exist");
    // }
    // })
    // .catch(function (error) {
    // console.log(error);
    // });


    }
  
    render() {
        return (
            <div style={{padding:'3em', backgroundColor:'#F5F5F5'}}>
              <CardDeck>
                <Card>
                    <Row style={{height: '780px'}}>
                      <Col style={{margin: '6rem'}}>
                          <Row>
                              <span style={{fontSize:"3.5em",padding: '0 50px'}}>Palmwise</span>
                              <span style={{fontSize:"3.5em",padding: '0 50px',lineHeight:'0.5'}}>Upload Portal</span>
                          </Row>
                          <Row>
                            <Col style={{fontSize:"2em",margin:'4rem 2rem 0 2rem'}}>
                              Welcome
                            </Col>
                          </Row>
                          <Row>
                            <Col style={{fontSize:"1em", margin: '1rem 2rem'}}>
                              To login please enter your email and password
                            </Col>
                          </Row>
                          <Row>
                            <Col style={{fontSize:"1em", margin: '1rem 2rem'}}>
                              <Form>
                                <Form.Group controlId="formBasicEmail">
                                  <Form.Label>Email</Form.Label>
                                  <Form.Control type="email" placeholder="email" onChange={(e) => this.setState({username: e.target.value})} />
                                </Form.Group>
                                <Form.Group controlId="formBasicPassword">
                                  <Form.Label>Password</Form.Label>
                                  <Form.Control type="password" placeholder="password" onChange = {(newValue,event) => this.setState({password:newValue})} />
                                </Form.Group>
                                <Button style={{backgroundColor:'#739900',border:'#739900',marginTop: '2rem'}} onClick={(e)=> this.handleClick(e)} variant="primary" type="submit">Login</Button>
                              </Form>
                            </Col>  
                          </Row>
                      </Col>
                      <Col >
                        <Image src={require("../assets/Group_489.png")} height="781"  />
                      </Col>
                    </Row>
                </Card>
              </CardDeck>    
            </div>
          );

    }
}
export default Login;
