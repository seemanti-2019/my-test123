import React from 'react';
import { Router, Switch, Route } from 'react-router-dom';
import history from './history';
import Login from '../Login';
import Dashboard from '../Dashboard';
import Filehistory from '../Filehistory';


class RootNavigator extends React.PureComponent {

  
  render() {
    return (
      <Router history={history}>
        <Switch>
          <Route exact path="/" component={Login} />
          <Route path="/dashboard/:username" render={
            ({ match }) => (
              <Dashboard username={match.params.username} />
            )
          } />
          <Route path="/filehistory/:username" render={
            ({ match }) => (
              <Filehistory username={match.params.username} />
            )
          } />
        </Switch>
      </Router>
    );
  }
}


export default RootNavigator;