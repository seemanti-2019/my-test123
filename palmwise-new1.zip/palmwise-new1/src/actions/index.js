import { FETCH_GRIEVANCES } from './types';
import GrievanceData from '../components/grievances/grievancesList.json';

export const fetchGrievances = (grievances) => {
    console.log('inside fetchPost....', grievances)
    return {
        type: FETCH_GRIEVANCES,
        grievances
    }
}

export const fetchAllGrievances = () => {
    // return dispatch => {
    //     console.log('inside dispatch...');
    //     return axios.get(apiURL)
    //     .then(response => {
    //         console.log('fetched data: ',response.data)
    //         dispatch(fetchPosts(response.data.slice(0,10)))
    //     })
    //     .catch(error => {
    //         console.log(error);
    //       throw(error);   
    //     });
    // };
    return dispatch => {
        console.log('fetched data: ', GrievanceData);

        dispatch(fetchGrievances(GrievanceData));
    }
}