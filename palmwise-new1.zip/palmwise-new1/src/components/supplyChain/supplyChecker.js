import React from 'react';
import { Card, Row, Col, Container,Image, Button } from 'react-bootstrap';
import { FaCheckCircle, FaWpexplorer, FaRegCircle, FaExclamationTriangle, FaRegAddressCard } from 'react-icons/fa';
import Map from './../../assets/map.png';


class SupplyChecker extends React.Component{
    render () {
        return (
            <div style={{paddingRight: "2rem", paddingLeft: "2rem"}}>
                <Card>
                    <Card.Body>
                        <h2>Felda Global Ventures</h2>
                        <Row>
                            <Col md={9}>
                                Group: Grower group
                            </Col>
                            <Col md={3}>
                                Present in my supply chain in 2019-20 
                                <span style={{ padding:"5px",color: "green" }}><FaCheckCircle /></span>
                            </Col>
                        </Row>
                    </Card.Body>
                </Card>
                <Card style={{marginTop: "3rem"}}>
                    <Card.Body>
                        <Container>
                            <Row>
                                <Col style={{textAlign: "center"}}>
                                    <h4>How is the supplier Connected to my supply chain</h4>
                                </Col>    
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={2}></Col>
                                <Col md={2} style={{textAlign: "center"}}>Mills</Col>
                                <Col md={3} style={{textAlign: "center"}}>Shipper</Col>
                                <Col md={3} style={{textAlign: "center"}}>Cargill destination refinery</Col>
                                <Col md={2}></Col>
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={2}></Col>
                                <Col md={2} style={{textAlign: "center"}}><FaWpexplorer size="4em" /></Col>
                                <Col md={3} style={{textAlign: "center"}}><FaWpexplorer size="4em" /></Col>
                                <Col md={3} style={{textAlign: "center"}}><FaWpexplorer size="4em" /></Col>
                                <Col md={2}></Col>
                            </Row>
                            <Card style={{marginTop: "3rem", borderRadius: "1rem"}}>
                                <Card.Body>
                                    <Row>
                                        <Col md={1}></Col>
                                        <Col md={4}>
                                            <FaRegCircle style={{background: "green",borderRadius: "100%"}} />
                                            <span style={{marginLeft: "2rem"}}>Part of Felda Global Ventures</span>
                                        </Col>
                                        <Col md={3}>
                                            <FaRegCircle />
                                            <span style={{marginLeft: "2rem"}}>Other Suppliers</span>                                            
                                        </Col>
                                        <Col md={4}>
                                            <FaExclamationTriangle color="red"/>
                                            <span style={{marginLeft: "2rem"}}>Grievance associated</span>
                                        </Col>
                                    </Row>                                    
                                </Card.Body>
                            </Card>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={3}></Col>
                                <Col md={6}>
                                    <Image src={Map} width="500" height="500" />
                                </Col>
                                <Col md={3}></Col>
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={3}></Col>
                                <Col md={6} style={{textAlign: "center"}}>This supplier has 3 active grievances</Col>
                                <Col md={3}></Col>
                            </Row>
                            <Row style={{marginTop: "1rem"}}>
                                <Col md={3}></Col>
                                <Col md={6} style={{textAlign: "center"}}><Button variant="light" style={{ border: '1px solid black', width: "40%"}} >Check Grievances</Button></Col>
                                <Col md={3}></Col>
                            </Row>
                        </Container>    
                    </Card.Body>
                </Card>
                <Card style={{marginTop: "3rem", marginBottom: "3rem", marginLeft:"1rem"}}>                  
                    <Row>
                        <Col md={2} style={{ backgroundColor: "rgba(212, 190, 38, 0.9)", height: '9rem', borderRadius: '5px 0 0 5px'}}>
                            <Row>
                                <Col style={{textAlign: "center",marginTop: "1rem",color: "#fff"}}>ID- Card</Col>
                            </Row>
                            <Row>
                                <Col style={{textAlign: "center"}}>
                                    <FaRegAddressCard size="5em" color="white"/>
                                </Col>
                            </Row>                                
                        </Col>
                        <Col md={10}>
                            <Row style={{marginTop: "2rem"}}>
                                <Col md={4} style={{textAlign: "center"}}>Location:</Col>
                                <Col md={3}>Malaysia</Col>
                                <Col md={3}>29 mills</Col>
                                <Col md={2}></Col>
                            </Row>
                            <Row style={{marginTop: "2rem"}}>
                                <Col md={4} style={{textAlign: "center"}}>Group:</Col>
                                <Col md={3}>Grower group</Col>
                                <Col md={3}>10 plantation</Col>
                                <Col md={2}></Col>
                            </Row>
                        </Col>
                    </Row>                    
                </Card>
            </div>    
        )
    }
}

export default SupplyChecker;


