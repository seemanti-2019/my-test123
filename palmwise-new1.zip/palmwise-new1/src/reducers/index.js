import { combineReducers } from 'redux';
import grievancesOverview from './grievanceOverviewReducer';

export default combineReducers({
    grievancesOverview : grievancesOverview
});
