import { FETCH_GRIEVANCES } from '../actions/types';

const GrievanceOverviewReducer = (state = [], action) => {
    switch(action.type) {
        case FETCH_GRIEVANCES:  
            console.log('inside reducer....',action);      
            return action.grievances;  
        default: 
            return state;        
    }
 
}

export default GrievanceOverviewReducer;

 