import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import GrievancesOverview from './components/grievances/grievancesOverview';
import GrievanceDetails from './components/grievances/grievanceDetails';

function App() {
  return (
    <div>
      <Router>
          <Route path="/" exact strict component={ GrievancesOverview } />
          <Route path="/grievance-details/:id" render={
            ({match})=> (
              <GrievanceDetails id={match.params.id} />
            )
          } />
      </Router>
    </div>
  );
}

export default App;
