import React from 'react';
import { connect } from 'react-redux';
import { Container, Card, Row, Col, Image } from 'react-bootstrap';
import Map from '../../assets/map.png';
import DownloadPanel from './downloadPanel';
import Timeline from './timeline';

class GrievanceDetails extends React.Component{
    constructor(props){
        super(props);
        this.gid = +this.props.id;
        this.textInput = React.createRef();
        this.state = {
            ref : React.createRef(),
            detailData : props.grievances.filter(data =>data.id === this.gid ),
            timelineTop : [
                {  id: 1, text: "Investigation", active: true, suspended: false, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) '},
                {  id: 2, text: "Verification", active: true, suspended: true, showTooltip: false,tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 3, text: "Implementation of action plan", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 4, text: "Monitoring Implementation", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
                {  id: 5, text: "Closed", active: true, suspended: false, showTooltip: false },
            ].reverse(),
            timelineBottom : [
                {  id: 1, text: "2017", active: false, suspended: false },
                {  id: 2, text: "2018", active: false, suspended: false },
                {  id: 3, text: "2019", active: false, suspended: false },
                {  id: 4, text: "2020", active: true, suspended: false }
            ].reverse()
        };
        console.log(this.state);
    }
    showTooltip = id => {
        let listData = [...this.state.timelineTop];
        listData.map(item => {
            if (item.id === id) {
                item.showTooltip = !item.showTooltip;
            } else {
                item.showTooltip = false;
            }
            return item;
        });
        return this.setState({timelineTop: listData });
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.textInput;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }
    render() {
        let detailData = this.state.detailData[0];
        return(
            <div style={{ margin: "0 2rem 0 2rem"}}>
                <Card style={{marginTop: "1rem"}}>
                    <Card.Body>
                        <Row><Col>Felda Global Ventures</Col></Row>
                        <Row><Col><h2>{detailData.name}</h2></Col></Row>
                        <Row>
                            <Col md={5}>
                                <Row><Col><h6>{detailData.subHeading}</h6></Col></Row>
                                <Row><Col>{detailData.description}</Col></Row> 
                                <Row style={{marginTop:"2rem"}}>
                                    <Col md={4}>Grievance Entity</Col>
                                    <Col md={8}>{detailData.entity}</Col>
                                </Row>
                                <Row style={{marginTop:"1rem"}}>
                                    <Col md={4}>Grievance raiser</Col>
                                    <Col md={8}>{detailData.raiser}</Col>
                                </Row>
                                <Row style={{marginTop:"1rem"}}>
                                    <Col md={4}>Date raised</Col>
                                    <Col md={8}>{detailData.date}</Col>
                                </Row>
                                <Row style={{marginTop:"1rem"}}>
                                    <Col md={4}>Source</Col>
                                    <Col md={8}>{detailData.source}</Col>
                                </Row>
                                <Row style={{marginTop:"1rem"}}>
                                    <Col md={4}>Last Updated</Col>
                                    <Col md={8}>{detailData.lastUpdated}</Col>
                                </Row>
                            </Col>
                        </Row>
                        <Row style={{paddingTop: '3rem'}}>
                            <Timeline type="timeline" timelineData={this.state.timelineTop} status={detailData.status} statusFlag="true" showTooltip={this.showTooltip} />
                        </Row>                           
                        <Row>
                            <Col><Image src={Map} width="100%" height="400"></Image></Col>
                        </Row>
                        <Row>
                            <Timeline type="year" timelineData={this.state.timelineBottom} statusFlag="false" />
                        </Row>
                    </Card.Body>
                </Card>
                <Card style={{marginTop: "2rem",marginBottom: "1rem", marginLeft: "1rem"}}>
                    <DownloadPanel textInput={this.textInput} exportCSV={this.exportCSV} />
                </Card>
            </div>
        )
    }
}

const mapStateToProps = state => {
    state.listToShow = null;
    console.log('inside mapState....', state.grievancesOverview);
    return {
        grievances: state.grievancesOverview
    };
}

export default connect(
    mapStateToProps
)(GrievanceDetails);