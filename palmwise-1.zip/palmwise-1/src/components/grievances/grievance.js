import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';


const Grievance = ({ grievance,textInput,handleClick,exportCSV }) => {
    return (
        <Card style={{ marginTop: '2rem', marginBottom: '1rem',padding: "0 1rem 0 1rem" }}>
            <Card.Body>
                <Row>
                    <Col md={10}>
                        <h3 style={{ paddingBottom: '5px' }}>{grievance.name}</h3>
                        <p style={{ marginTop: "0", marginBottom: "1rem" }}>
                            <strong>Entity </strong>
                            <span>{grievance.entity}</span>
                        </p>
                        <p style={{ marginTop: "0", marginBottom: "1rem" }}>
                            <strong>Status </strong>
                            <span>{grievance.status}</span>
                        </p>
                        <Row>
                            <Col md={3}>
                                <Button variant="light" style={{ border: '1px solid black', width: "100%" }} onClick={() => handleClick(grievance.id)}>See Grievances</Button>
                            </Col>
                            <Col md={9}>
                                <a style={{ display: 'none' }} href='empty' ref={textInput}>ref</a>
                                <Button variant="dark" onClick={()=> exportCSV()}>Download statement</Button>
                            </Col>
                        </Row>
                    </Col>
                    <Col md={2} style={{textAlign: "right"}}>
                        {grievance.date}
                    </Col>
                </Row>
            </Card.Body>
        </Card>
    )
}

export default Grievance;