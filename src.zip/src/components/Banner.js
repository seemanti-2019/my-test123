import React from 'react';

class Banner extends React.Component {
    render() {
        return (
            <div className="row align-items-center my-5">
                <div className="col-md-6">
                    <div className="custom-file">
                        <label className="custom-file-upload" style={{width:"30%"}}>
                            <input type="file" style={{ display: "none" }} />
                            Add Files
                        </label>
                    </div>
                </div>
                <div className="col-md-2">
                    <div className="dropdown">
                    <button className="btn btn-outline-secondary dropdown-toggle"
                        type="button" id="dropdownMenu1" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false" style={{width:"100%"}}>
                        File Type
                    </button>
                    <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <a className="dropdown-item" href="#!">Action</a>
                        <a className="dropdown-item" href="#!">Another action</a>
                    </div>
                    </div>
                </div>
                <div className="col-md-2">
                    <div className="dropdown">
                    <button className="btn btn-outline-secondary dropdown-toggle"
                        type="button" id="dropdownMenu1" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false" style={{width:"100%"}}>
                        Quarter
                    </button>
                    <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <a className="dropdown-item" href="#!">Action</a>
                        <a className="dropdown-item" href="#!">Another action</a>
                    </div>
                    </div>
                </div>
                <div className="col-md-2">
                    <button type="button" className="btn btn-outline-secondary" style={{width:"100%"}}>Upload</button>
                </div>
            </div>
        )
    }
}

export default Banner;