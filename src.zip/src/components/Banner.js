import React from 'react';

class Banner extends React.Component {
    render() {
        return (
            <div className="row align-items-center my-5">
                <div className="col-md-6">
                    <button type="button" className="btn btn-outline-secondary">Add Files</button>
                </div>
                <div className="col-md-2">
                    <div className="dropdown">
                    <button className="btn btn-outline-secondary dropdown-toggle"
                        type="button" id="dropdownMenu1" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        File Type
                    </button>
                    <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <a className="dropdown-item" href="#!">Action</a>
                        <a className="dropdown-item" href="#!">Another action</a>
                    </div>
                    </div>
                </div>
                <div className="col-md-2">
                    <div className="dropdown">
                    <button className="btn btn-outline-secondary dropdown-toggle"
                        type="button" id="dropdownMenu1" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Quarter
                    </button>
                    <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <a className="dropdown-item" href="#!">Action</a>
                        <a className="dropdown-item" href="#!">Another action</a>
                    </div>
                    </div>
                </div>
                <div className="col-md-2">
                    <div className="custom-file">
                        <input type="file" className="custom-file-input" id="customFile" />
                        <label className="custom-file-label" htmlFor="customFile">Upload</label>
                    </div>
                </div>
            </div>
        )
    }
}

export default Banner;