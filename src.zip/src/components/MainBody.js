import React from 'react';
import FileList from '../fileList.json';

class MainBody extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fileData: FileList,
      checked: false,
    }
    this.state.fileData.map(item => {
      item.showError = false;
      return item;
    });
    console.log(this.state);
  }

  showHideError = (id) => {
    let fileData = [...this.state.fileData];
    fileData.map(item => {
      if (item.id === id) {
        item.showError = !item.showError;
      } else {
        item.showError = false;
      }
      return item;
    });
    return this.setState({ fileData });
  }
  
  /* sorting list based on fileds like quarter*/
  /* TO BE ADDED LATER */
  sortFileList = () => {
    this.setState({
      fileData: this.state.fileData.sort((a, b) => (a.quarter > b.quarter) ? 1 : ((b.quarter > a.quarter) ? -1 : 0))
    });
  }
  
  deleteFileData = (deletePostId) => {
    let r = window.confirm("Are you sure you want to delete!");
    if (r === true) {
      this.setState({
        fileData: this.state.fileData.filter(item => item.id != deletePostId)
      })
    }
  }

  render() {
    const fileListToShow = [...FileList];
    const showSuccessRejected = (status) => {
      switch (status) {
        case 'success': {
          this.setState({ fileData: fileListToShow.filter(file => file.status === 'Success') });
          break;
        }
        case 'rejected': {
          this.setState({ fileData: fileListToShow.filter(file => file.status === 'Rejected') });
          break;
        }
        default: {
          break;
        }
      }
    }

    const handleChange = () => {
      this.setState((prevState) => {
        return { checked: !(prevState.checked) }
      });
      console.log(this.state);
      if (this.state.checked === true) {
        showSuccessRejected('rejected');
      } else {
        showSuccessRejected('success');
      }
    }
    const dataTable = this.state.fileData.map(data => {
      return (
        <div className="row my-2 card" key={data.id}>
          <div className="card-header col-sm-12">
            <div className="row">
              <div className="col-sm-2">{data.fileName}</div>
              <div className="col-sm-2">{data.fileType}</div>
              <div className="col-sm-2">{data.quarter}</div>
              <div className="col-sm-2">{data.time}</div>
              <div className={"col-sm-2 " + ((data.status === 'Rejected') ? "error-text" : "success-text")}>{data.status}</div>
              <div className="col-sm-2">
                <div className="row">
                  <div className={"col-sm-8 " + ((data.status === 'Rejected') ? "visible" : "invisible")}>
                    <a style={{ cursor: 'pointer' }} onClick={() => this.showHideError(data.id)}>
                      <i style={{ color: 'black', paddingTop: '5px' }} className={"fa " + ((data.showError === true) ? "fa-caret-up" : "fa-caret-down") + " float-right"} aria-hidden="true"></i>
                    </a>
                  </div>
                  <div className="col-sm-4">
                    <a style={{ cursor: 'pointer' }} onClick={() => this.deleteFileData(data.id)} >
                      <i style={{ color: 'black' }} className="fa fa-trash" aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {
            (data.status === 'Rejected' && data.showError === true) ? (
              <div className="card-body error-text" id={"err-div" + data.id}>
                {data.error.map((element, key) => {
                  return (
                    <div key={key}>
                      <p className="card-text">{element.errCode} : {element.errMessage}</p>
                    </div>
                  )
                })}
              </div>) : ('')
          }
        </div>
      )
    });
    return (
      <div className="container">
        <div className="row align-items-center my-5">
          <div className="col-sm-2 text-left">File name</div>
          <div className="col-sm-2 text-left">File type</div>
          <div className="col-sm-2 text-left">Querter</div>
          <div className="col-sm-2 text-left">Time</div>
          <div className="col-sm-2 text-left">Status</div>
          <div className="col-sm-2 text-left">
            <div className="custom-control custom-switch float-right">
              <input type="checkbox"
                className="custom-control-input"
                id="customSwitch1"
                checked={this.state.checked}
                onChange={() => handleChange()} />
              <label className="custom-control-label" htmlFor="customSwitch1">{this.state.checked ? 'Success' : 'Rejected'}</label>
            </div>
          </div>
        </div>
        {dataTable}
      </div>
    )
  }
}

export default MainBody;