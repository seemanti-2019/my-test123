import React from 'react';

class Footer extends React.Component {
    render() {
        return (
            <footer className="py-15 bg-light">
                <div className="container">
                </div>
            </footer>
        )
    }
}
export default Footer;