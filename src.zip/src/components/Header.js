import React from 'react';
import Banner from '../components/Banner';
import MainBody from './MainBody';

class Header extends React.Component {
  render() {
    return (
      <div>
        <Banner />
        <MainBody />
      </div>
    )
  }
}

export default Header;