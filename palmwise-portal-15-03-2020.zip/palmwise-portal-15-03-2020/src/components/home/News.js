import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card } from 'react-bootstrap';
import { getNewsData } from '../../actions/index';
import { FaRegNewspaper } from 'react-icons/fa';

class News extends React.PureComponent {

constructor(props) {
    super(props);
    this.state = {
    isLoading: false,
    }

}

componentDidMount() {
    this.props.getNewsData();
}

componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
}

    test1 = () => {
    //alert('hell')
        this.props.changeName();
}



render() {
    const newList = [{title:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ", date:'18', id:'0', url:"https://www.google.com/maps"},
  {title:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ', date:'16', id:'1', url:"https://www.linkedin.com/"},
  {title:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ', date:'14', id:'2', url:"https://www.cargill.co.in/"},
  {title:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ', date:'12', id:'3', url:"https://www.cargill.co.in/en/company-overview"},
  {title:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ', date:'10', id:'4', url:"https://www.cargill.co.in/en/history"}];
  
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <Card.Title>My News</Card.Title>
            <div style={{paddingTop:'10px'}}>
              {this.props.news.map((item, index) => (
                <div key={index}>
                <hr/>
                <Row sm={12}>
              <Col sm={2} style={{textAlign:'center'}}><div class="square"> <FaRegNewspaper size={24}/></div></Col>  
                <Col sm={10}>
                <a style={{color:'black'}} href={item.link} target="_blank">{item.name}</a> 
                </Col>  
                
                </Row>
                
                </div>
              ))}
            </div>
            <br></br>
          </Card.Body>
          </Card>
    );
}
}


const mapStateToProps = state => {
return {
    news: state.home.news,
};
}

export default connect(mapStateToProps, { getNewsData })(News);
{/* <div class="square">{item.date} <p style={{fontSize:10}}>Jan</p></div> */}