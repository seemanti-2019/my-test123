import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, CardDeck, Form, DropdownButton, Dropdown } from 'react-bootstrap';
import { changeName } from '../../actions/index';
import TracebilityWidget from './Tracebility';
import SupplierSearch from '../supplierchecker/SearchComponent';
import Grievances from '../grievances/GrievancesWidget';
import Volumes from './VolumeWidget';
import Footprints from './Footprint';
import Downloads from './Downloads';
import News from './News';
import InfoWidget from './InfoWidget';

const source = [{
  title: 'Felda Global Ventures',
},{
    title: 'Felda Global Ventures 1',
  },{
    title: 'Global Felda Ventures',
    
  }]

class Home extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }
  

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
        this.props.changeName();
  }

  userSelection = (data) => {
    alert(data.title);
  }
  


  render() {
    
    return (
        <div style={{padding:'3em', backgroundColor:'#F5F5F5'}}>
          
          <Row>
            <Col style={{paddingBottom:'1em'}}>
              <h2>Welcome Jane doe</h2>
              <div>Last login: 17-02-2020</div>
            </Col>
            <Col md="auto"></Col>
            <Col xs lg="2"><SupplierSearch content={source} handleSelection={this.userSelection}/></Col>
          </Row>
          
          <CardDeck style={{padding:'1.5em'}}>
            <TracebilityWidget/>
            <Grievances/>
            <Volumes/>
          </CardDeck>
          <CardDeck style={{padding:'1.5em'}}>
            <Footprints/>
          </CardDeck >
          <CardDeck style={{padding:'1.5em'}}>
            <News/>
            <Downloads/>
            <InfoWidget/>
          </CardDeck>
          
        </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(Home);
