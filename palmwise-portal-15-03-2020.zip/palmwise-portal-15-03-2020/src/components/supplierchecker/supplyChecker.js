import React from 'react';
import { Card, Row, Col, Container,Image, Button } from 'react-bootstrap';
import { FaCheckCircle, FaRegCircle, FaExclamationTriangle } from 'react-icons/fa';
import history from '../header/history';
import Chart from '../../assets/mill-chart.png';
import Mills from '../../assets/Mills.png';
import Shipper from '../../assets/Shipper.png';
import Refinery from '../../assets/refinery.png';
import IDCard from '../../assets/ID-CARD.png';

export default class SupplyChecker extends React.Component{
    constructor(props) {
        super(props);
        console.log(props);
    }
    handleClick = () => {
        history.push('/grievancesoverview');
    }
    render () {
        return (
            <div style={{paddingRight: "2rem", paddingLeft: "2rem"}}>
                <Card>
                    <Card.Body>
                        <h2>Felda Global Ventures</h2>
                        <Row>
                            <Col md={8}>
                                Group: Grower group
                            </Col>
                            <Col md={4}>
                                Present in my supply chain in 2019-Q3
                                <span style={{ padding:"5px",color: "green" }}>
                                    <FaCheckCircle />
                                </span>
                            </Col>
                        </Row>
                    </Card.Body>
                </Card>
                <Card style={{marginTop: "1rem"}}>
                    <Card.Body>
                        <Container>
                            <Row>
                                <Col style={{textAlign: "center"}}>
                                    <h4>How is the supplier Connected to my supply chain</h4>
                                </Col>    
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={1}></Col>
                                <Col md={3} style={{textAlign: "center"}}>Mills</Col>
                                <Col md={3} style={{textAlign: "center"}}>Shipper</Col>
                                <Col md={3} style={{textAlign: "center"}}>Cargill destination refinery</Col>
                                <Col md={2}></Col>
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={1}></Col>
                                <Col md={3} style={{textAlign: "center"}}>
                                    <Image src={Mills} width="80"/>
                                </Col>
                                <Col md={3} style={{textAlign: "center"}}>
                                    <Image src={Shipper} width="80"/>
                                </Col>
                                <Col md={3} style={{textAlign: "center"}}>
                                    <Image src={Refinery} width="80"/>
                                </Col>
                                <Col md={2}></Col>
                            </Row>
                            <Card style={{marginTop: "3rem", borderRadius: "1rem"}}>
                                <Card.Body>
                                    <Row>
                                        <Col md={1}></Col>
                                        <Col md={4}>
                                            <FaRegCircle style={{background: "green",borderRadius: "100%"}} />
                                             <span style={{marginLeft: "2rem"}}>Part of Felda Global Ventures</span>
                                        </Col>
                                        <Col md={3}>
                                            <FaRegCircle />
                                            <span style={{marginLeft: "2rem"}}>Other Suppliers</span>                                            
                                        </Col>
                                        <Col md={4}>
                                            <FaExclamationTriangle color="red"/>
                                            <span style={{marginLeft: "2rem"}}>Grievance associated</span>
                                        </Col>
                                    </Row>                                    
                                </Card.Body>
                            </Card>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={2}></Col>
                                <Col md={8} style={{textAlign: "center"}}>
                                    <Image src={Chart} width="550"/>
                                </Col>
                                <Col md={2}></Col>
                            </Row>
                            <Row style={{marginTop: "3rem"}}>
                                <Col md={3}></Col>
                                <Col md={6} style={{textAlign: "center"}}>This supplier has 3 active grievances</Col>
                                <Col md={3}></Col>
                            </Row>
                            <Row style={{marginTop: "1rem"}}>
                                <Col md={3}></Col>
                                <Col md={6} style={{textAlign: "center"}}>
                                    <Button variant="light" style={{ border: '1px solid black', width: "40%"}} onClick={()=> this.handleClick()} >Check Grievances</Button>
                                </Col>
                                <Col md={3}></Col>
                            </Row>
                        </Container>    
                    </Card.Body>
                </Card>
                <Card style={{margin: "1rem 0 1rem 1rem"}}>                  
                    <Row>
                        <Col md={2} style={{ backgroundColor: "rgba(212, 190, 38, 0.9)", height: '9rem', borderRadius: '5px 0 0 5px'}}>
                            <Row>
                                <Col style={{textAlign: "center"}}>
                                    <Image src={IDCard} />
                                </Col>
                            </Row>                                
                        </Col>
                        <Col md={10}>
                            <Row style={{marginTop: "2rem"}}>
                                <Col md={4} style={{textAlign: "center"}}>Location:</Col>
                                <Col md={3}>Malaysia</Col>
                                <Col md={3}>29 mills</Col>
                                <Col md={2}></Col>
                            </Row>
                            <Row style={{marginTop: "2rem"}}>
                                <Col md={4} style={{textAlign: "center"}}>Group:</Col>
                                <Col md={3}>Grower group</Col>
                                <Col md={3}>10 plantation</Col>
                                <Col md={2}></Col>
                            </Row>
                        </Col>
                    </Row>                    
                </Card>
            </div>    
        )
    }
}