import React from 'react';
import C3Chart from 'react-c3js';


const TotalAreaOfDeforestation = ({ chartData }) => {
    //chartData.unshift('data1');
    let chartColumn = ['data1'];
    chartData.map((item)=> {
        chartColumn.push(item)
    });
    const data = {
        columns: [
            chartData,
        ],
        color: {
            data1: 'black',
        }
    };
    const size = {
        height: 300,
        width: 400
    }
    const point = {
        r: 6,
    }
    const tooltip = {
        show: false
    }
    const legend = {
        show: false,
    }
    const padding = {
        top: 100,
    }
    const axis = {
        x: {
            label: {
                text: 'Time',
                position: 'outer-middle',
            },            
        },
        y: {
            label: {
                text: 'Surface(ha)',
                position: 'outer-middle'
            },
            tick: {
                values: [100, 150, 200, 250, 300, 350],
            },
            padding: {
                top: 150,
                bottom: 150
            },

        }
    }
    return (
        <C3Chart data={data} tooltip={tooltip} axis={axis} legend={legend} point={point} size={size} padding={padding}></C3Chart>
    );

}
export default TotalAreaOfDeforestation;

