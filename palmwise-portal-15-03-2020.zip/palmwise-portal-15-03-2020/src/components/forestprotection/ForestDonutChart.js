import React from 'react';
import C3Chart from 'react-c3js';

const ForestDonutChart = ({chartData}) => {

    let columnData = [];
    let columnNames = {};
    let colorNames = {};
    chartData.map((item, index) => {
       let i = index+1; 
       columnData.push(['data'+i,item.value]);
       columnNames['data'+i] = item.name;
       colorNames['data'+i] = item.color;
    });
    const data = {
        columns: columnData,
        names: columnNames,
        type: 'donut',
        colors: colorNames,
    };
    const tooltip = {
        show: false
    }
    const legend = {
        position: 'inset',
        inset: {
            anchor: 'top-left',
            step: chartData.length
        },
        item: {
            onclick: function () { }
        }
    }
    const donut = {
        width: 30,
        label: {
            show: false
        }
    }
    const size = {
        width: 250,
        height: 350
    }
    const padding = {
        left: 0,
        bottom: -100
    }
    const axis = {
        y: {
            padding: {
                left: 220,
                right: 0,
            }
        },
        x: {
            padding: {
                bottom: 500
            }
        }
    }

    return (
        <C3Chart data={data} tooltip={tooltip} legend={legend} donut={donut} size={size} padding={padding} axis={axis}></C3Chart>
    );
}


export default ForestDonutChart;
