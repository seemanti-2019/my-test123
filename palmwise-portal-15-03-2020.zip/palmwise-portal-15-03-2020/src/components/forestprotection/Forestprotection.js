import React from 'react';
import { connect } from 'react-redux';
import { changeName, getDeforestationFreeData, getLandCoverData, getTotalAreaOfDeforestation } from '../../actions/index';
import TotalAreaOfDeforestation from './TotalAreaOfDeforestation';
import { Row, Col, Card, Form, Button } from 'react-bootstrap';
import ForestDonutChart from './ForestDonutChart';
import { FaInfoCircle, FaCaretDown, FaCaretUp } from 'react-icons/fa';

class Forestprotection extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      divHide: false
    }

  }

  componentDidMount() {
    this.props.getDeforestationFreeData();
    this.props.getLandCoverData();
    this.props.getTotalAreaOfDeforestation();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }
  test1 = () => {
    //  this.props.changeName();
  }

  hideShow = () => {
    this.setState({divHide: !this.state.divHide});
  }
  render() {
    return (
      <div style={{ padding: '3em' }}>
        <Card style={{ width: '100%', boxShadow: "0 15px 15px -15px #111" }}>
          <Row style={{marginBottom:"-30px"}}>
            <Col md={4}>
              <Card.Body>
                <Card.Title>Deforestation-free-%of mills <FaInfoCircle></FaInfoCircle></Card.Title>
                <Form.Text className="text-muted" style={{ paddingBottom: '12px' }}>In 2019-Q3</Form.Text>
              </Card.Body>
            </Col>
            <Col md={4}>
              <Card.Body>
                <Card.Title>Land Cover <FaInfoCircle></FaInfoCircle></Card.Title>
                <Form.Text className="text-muted" style={{ paddingBottom: '12px' }}>In 2019-Q3</Form.Text>
              </Card.Body>
            </Col>
            <Col md={4}>
              <Card.Body>
                <Card.Title>Total area of deforestation  (Confirmend Alerts) <FaInfoCircle></FaInfoCircle></Card.Title>
                <Form.Text className="text-muted" style={{ paddingBottom: '12px' }}>
                  In 2019-Q3
                </Form.Text>
                </Card.Body>
            </Col>
          </Row>
          {(this.state.divHide === false)?
          (<Row style={{margin: "5px"}}>
            <Col >
              <div style={{ borderBottom: "1px solid lightgray", width: "70%", marginBottom: "1rem" }}>
                  <ForestDonutChart chartData={this.props.deforestationFreeData} />
              </div>
              <Button variant="light" style={{ border: '1px solid black', borderRadius: 0 }}>See more details</Button>
            </Col>
            <Col>
              <div style={{ borderBottom: "1px solid lightgray", width: "70%", marginBottom: "1rem" }}>
                 <ForestDonutChart chartData={this.props.landCoverData} />
              </div>
              <Button variant="light" style={{ border: '1px solid black', borderRadius: 0 }}>See more details</Button>
            </Col>
            <Col>
               <div style={{ borderBottom: "1px solid lightgray", width: "70%", marginBottom: "1rem", paddingBottom: "3rem"}}>
                  <TotalAreaOfDeforestation chartData={this.props.totalDeforestationArea} />
                </div>
                <Button variant="light" style={{ border: '1px solid black', borderRadius: 0 }}>See more details</Button>
             </Col>
          </Row>):('')}
          <div style={{ textAlign: "center",marginTop:"15px" }}>
            <Button onClick={() => this.hideShow()} variant="light" style={{ position: "absolute", marginTop: "-15px", boxShadow: "0 15px 15px -15px #111,-15px 0 15px -15px #111,15px 0 15px -15px #111" }}>
              {
                (this.state.divHide) ? (<FaCaretDown size={32} style={{ color: "grey" }}></FaCaretDown>
                ) : (<FaCaretUp size={32} style={{ color: "grey" }}></FaCaretUp>)
              }
            </Button>
          </div>
        </Card>
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
    deforestationFreeData: state.forest.deforestationFreeData,
    landCoverData: state.forest.landCoverData,
    totalDeforestationArea: state.forest.totalDeforestationArea,
  };
}

export default connect(mapStateToProps, { changeName, getDeforestationFreeData, getLandCoverData, getTotalAreaOfDeforestation })(Forestprotection);
