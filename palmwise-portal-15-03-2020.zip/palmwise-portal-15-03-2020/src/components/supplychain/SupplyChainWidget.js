import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Dropdown, ProgressBar } from 'react-bootstrap';
import { getSupplyChainWidgetData, getByCountryVolumes } from '../../actions/index';

class SupplyChainWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getSupplyChainWidgetData();
    this.props.getByCountryVolumes();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
        this.props.changeName();
  }
  


  render() {
    
    return (
            
                    <Card style={{ width: '100%' }}>
                        <Card.Body>
                            <Card.Title>My Supply Chain</Card.Title>
                            <br></br>
                            <DropdownButton style={{paddingBottom:'0.5em'}}
                            variant="outline-secondary"
                            size="sm"
                            title="In 2019-Q2"
                            id="input-group-dropdown-2"
                            >
                            <Dropdown.Item>2019-Q2</Dropdown.Item>
                            </DropdownButton>
                            
                            <p style={{fontWeight:'16', paddingBottom:'0.5em'}}>Number of mills and origin refineries in your supply chain.</p>
                            
                            <Row>
                                <Col><strong>{this.props.millcount}</strong></Col>
                                <Col><strong>24</strong></Col>
                            </Row>
                            <Row style={{paddingBottom:'0.5em'}}>
                                <Col>Mills</Col>
                                <Col>Refineries</Col>
                            </Row>
                            <p style={{fontWeight:'16'}}><strong>Volumes by country of origin</strong></p>
                            
                                <Col sm={12} style={{padding:'1em'}} >
                                {this.props.volumes.map((item, index) => (
                                  <Row style={{padding:'5px'}} key={index}>
                                      <Col md={4} style={{marginTop: '-3px'}}>{item.load_country}</Col>
                                      <Col md={{ span: 8, offset: 0 }}><ProgressBar  now={Math.round(item.volume_percent)} label={`${Math.round(item.volume_percent)}%`} /></Col>
                                  </Row>))}
                                </Col>
                            
                            
                        
                        </Card.Body>
                    </Card>
                
            
        
    );
  }
}


const mapStateToProps = state => {
  return {
    millcount: state.supplychain.millcount,
    volumes: state.supplychain.volumes
  };
}

export default connect(mapStateToProps, { getSupplyChainWidgetData, getByCountryVolumes })(SupplyChainWidget);
