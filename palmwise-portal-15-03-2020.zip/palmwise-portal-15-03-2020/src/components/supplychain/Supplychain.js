import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, CardDeck, Button } from 'react-bootstrap';
import history from '../header/history'
import { changeName } from '../../actions/index'
import TracebilityWidget from '../home/Tracebility';
import SCWidget from './SupplyChainWidget';
import SCHeader from './SupplyChainHeader';
import SPerformance from './PerformanceWidget';
import SupplierSearch from '../supplierchecker/SearchComponent';
import FilterHeader from '../filters/FilterWidget';
import SubscriptionAndFAQ from '../grievances/SubscriptionAndFAQ';

const source = [{
  title: 'Felda Global Ventures',
},{
    title: 'Felda Ventures',
  },{
    title: 'Global Ventures',
    
  }]


class SupplyChain extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      
      history.push('/');
    
       // this.props.changeName();
  }

  userSelection = (data) => {
    alert(data.title);
  }
  


  render() {
    return (
      <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
        <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
          <FilterHeader></FilterHeader>
        </CardDeck>
        <Row style={{paddingTop:'1em', paddingLeft:'2em', paddingRight: '1.5em'}}>
          <Col>
            <Row>
            <Button variant="link" style={{color: '#A5A5A5', fontSize: '18px', fontWeight: '600'}} onClick={(e)=> this.test1()}>Home</Button>
            <div style={{borderLeft: '3px solid lightgray', height: '30px', marginTop:'5px'}}></div>
            <Button variant="link" style={{color: '#000', fontSize: '18px', fontWeight: '600'}}>Supply Chain</Button></Row>
          </Col>
          <Col md="auto"></Col>
          <Col xs lg="2"><SupplierSearch content={source} handleSelection={this.userSelection}/></Col>
        </Row>
        <CardDeck style={{padding:'1.5em'}}>
          <SCHeader/>
        </CardDeck>    
        <CardDeck style={{padding:'1.5em'}}>
          <SCWidget/>
          <TracebilityWidget/>
        </CardDeck>
        <CardDeck style={{padding:'1.5em'}}>
          <SPerformance/>
        </CardDeck>
        <SubscriptionAndFAQ source="myGrievances" />
      </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(SupplyChain);
