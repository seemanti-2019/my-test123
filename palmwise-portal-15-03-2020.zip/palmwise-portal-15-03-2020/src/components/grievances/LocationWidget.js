import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history'
import { ProgressBar, Row, Col, Card, Form } from 'react-bootstrap';
import { getGrievancesLocation } from '../../actions/index';

class LocationWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesLocation();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

 
  


  render() {
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Location of grievances</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'12px'}}>
          Grievances are raised against suppliers in our supply chain. Below the breakdown of the locations of these suppliers by number of grievances.
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
          {this.props.grievances.map((item, index) => (
            <Row style={{padding:'5px'}} key={index}>
                <Col md={4} style={{marginTop: '-3px'}}>{item.COUNTRY}</Col>
                <Col md={{ span: 8, offset: 0 }}><ProgressBar  now={item.GRIEVANCES} label={`${item.GRIEVANCES}`} max={item.TOTAL_GRIEVANCES}/></Col>
            </Row>))}
        </Col>
          
          
        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.location,
  };
}

export default connect(mapStateToProps, { getGrievancesLocation })(LocationWidget);
