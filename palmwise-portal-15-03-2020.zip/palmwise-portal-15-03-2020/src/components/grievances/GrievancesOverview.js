import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Dropdown, CardDeck } from 'react-bootstrap';
import history from '../header/history'
import { getGrievancesList, getGrievancesFiltersOptions, getGrievancesSortOrder, applyGrievancesSorting, updateGrievancesFilter, applyGrievancesFilter } from '../../actions/index';
import GrievanceTile from './GrievancesTile';
import { FaSortAmountDown, FaSortAmountUp } from 'react-icons/fa';
import FilterHeader from '../filters/FilterWidget';

class GrievancesOverview extends React.PureComponent {

    constructor(props) {
        super(props);
        this.textInput = React.createRef();
        this.status = 'Status';
        this.country = 'Country';
        this.state = {
            isLoading: false
        }
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.textInput;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }
    handleClick = (id) => {
        history.push(`/grievance-details/${id}`);
    }

    setFilter = (field, value) => {
        console.log(field);
        switch(field){
            case "status" :
                this.status = value;
                break;
            case "country" :
                this.country = value;   
                break;
            default:
                break;    
        }
        this.props.updateGrievancesFilter(field, value);
    }    
    applyFilter = () => {
        this.props.applyGrievancesFilter();        
    }    
    sortDatewise = (order) => {
        this.props.applyGrievancesSorting(order);        
    }
    componentDidMount() {
        this.props.getGrievancesList();
        this.props.getGrievancesFiltersOptions();
        this.props.getGrievancesSortOrder();        
    }

    componentWillReceiveProps(nextProps) {
        //if (this.props.user != nextProps.user )
    }

    test1 = () => {
        history.push('/');
    }

    test2 = () => {
        history.push('/grievances');
    }

    renderVentureItems = () => {
        return  this.props.filterOptions.ventureItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }

    renderStatusItems = () => {
        return  this.props.filterOptions.statusItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }
    renderCountryItems = () => {
        return  this.props.filterOptions.countryItems.map((item, i) => {
            return (
                <Dropdown.Item eventKey={item.value} key={i}>{item.label}</Dropdown.Item>
            )
        })
    }
    renderSortButton = () => {
        return (this.props.sortOrder === 'desc') ?
            (
                <Button variant="outline-dark" onClick={() => this.sortDatewise('asc')}>
                    <FaSortAmountDown />
                </Button>
            ) : (
                <Button variant="outline-dark" onClick={() => this.sortDatewise('desc')}>
                    <FaSortAmountUp />
                </Button>
            )
    }
    render() {        
        return (
            <div style={{ padding: '1em', backgroundColor: '#F5F5F5' }}>
                <CardDeck style={{ paddingTop: '1em', paddingLeft: '1.4em', paddingRight: '1.3em' }}>
                    <FilterHeader></FilterHeader>
                </CardDeck>
                <Row style={{ paddingTop: '1em', paddingLeft: '2em' }}>
                    <Col>
                        <Row>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test1()}>Home</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test2()}>My grievances</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#000', fontSize: '18px', fontWeight: '600' }} >Grievances Overview</Button>
                        </Row>
                    </Col>
                </Row>
                <CardDeck style={{ padding: '1.5em' }}>
                    <Card style={{ width: '100%', padding: '1em' }}>
                        <Card.Body>
                            <h1><strong>Grievances Overview.</strong></h1>
                            <Row style={{ marginTop: "2rem" }}>
                                <Col md={3}>
                                    <Dropdown>
                                        <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%", textAlign: "left" }}>
                                            Felda Global Ventures
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                        {this.renderVentureItems()}
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                                <Col md={3}>
                                    <Dropdown onSelect={(e) => this.setFilter('status', e)}>
                                        <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: '100%', textAlign: "left" }}>
                                        {this.status}
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                        {this.renderStatusItems()}
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                                <Col md={3}>
                                    <Dropdown onSelect={(e) => this.setFilter('country', e)}>
                                        <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%", textAlign: "left" }}>
                                        {this.country}
                                        </Dropdown.Toggle>
                                        <Dropdown.Menu style={{ width: "100%" }}>
                                        {this.renderCountryItems()}
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Col>
                                <Col md={3}>
                                    <Button variant="dark" onClick={() => this.applyFilter()}>Apply Filter</Button>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </CardDeck>
                <Row style={{ paddingTop: "1rem", paddingLeft: '2em', paddingRight: '2em' }}>
                    <Col md={2}>
                        {this.props.grievanceList.length}  results
                    </Col>
                    <Col md={10} style={{ textAlign: "right" }}>
                        {this.renderSortButton()}                        
                    </Col>
                </Row>
                {
                this.props.grievanceList.map(grievance => {
                    return (
                        <CardDeck style={{ padding: '0 1.5em' }} key={grievance.id}>
                            <GrievanceTile
                                grievance={grievance}
                                key={grievance.id}
                                exportCSV={this.exportCSV}
                                textInput={this.textInput}
                                handleClick={this.handleClick}
                            />
                        </CardDeck>
                    );
                })
                }
            </div>
        );
    }
}


const mapStateToProps = state => {
    console.log('state', state);
    return {
        grievanceList: state.grievances.list,
        filterOptions: state.grievances.filterOptions,
        sortOrder: state.grievances.sortOrder
    };
}

export default connect(mapStateToProps, { getGrievancesList, getGrievancesFiltersOptions, getGrievancesSortOrder, applyGrievancesSorting, updateGrievancesFilter, applyGrievancesFilter })(GrievancesOverview);
