import React from 'react';
import { connect } from 'react-redux';
import { Col, Card, Form } from 'react-bootstrap';
import { getGrievancesStatus } from '../../actions/index';
import C3Chart from 'react-c3js';
import 'c3/c3.css';

class GrievancesStatusWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesStatus();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }


  render() {
    this.myGrievance = this.props.grievances;
    this.myGrievance.environmentalIssues.unshift('data1');
    this.myGrievance.socialIssues.unshift('data2');
    this.myGrievance.legalIssues.unshift('data3');
    this.statusNames = ['Investigation', 'Verification','Developing action plan','Monitoring implementation','Suspended','Closed'];

    const dataColumn = {
        columns: [
            this.myGrievance.environmentalIssues,
            this.myGrievance.socialIssues,
            this.myGrievance.legalIssues
        ],
        names: {
            data1: 'Environmental Issues',
            data2: 'Social Issues',
            data3: 'Legal Issues'
        },
        type: 'bar',
        groups: [
            ['data1', 'data2', 'data3']
        ],
        colors: {
            'data1': '#148280',
            'data2': '#ffa500',
            'data3': '#54822e'
        },
        
    };
    
    const gridColumn = {
        y: {
            lines: [{ value: 0 }]
        },
        
    };

    const legendColumn = {
        position: 'inset',
        inset: {
            anchor: 'top-left',
            x: 20,
            y: 10,
            step: 1
        },            
        item: {
            onclick: function () { }
        }            
    }

    const axis = {
      x: {
        show: false
      },
      y: {
        show: false
      }
    }
    const bar = {
        width: 20
    }
    const tooltipColumn = {
        show: true,
        contents: function () {
          return '<div><div style="text-align:center">Status Investigation</div><div>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</div></div>'
        }
      }
    const sizeColumn = {
        height: 500
    };    
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Status of my grievances</Card.Title>
          <Form.Text className="text-muted" style={{ paddingBottom: '12px' }}>
            We hold ourselves and our suppliers accountable to respond to grievances, set time-bound action plans to ensure progress and close the grievances in a timely manner as agreed to by the complainant. Cargill's Palm Grievances Procedure provides a transparent, open and robust process for dealing with grievances.
          </Form.Text>
          <Col sm={12} style={{ padding: '1rem 1rem 5rem 1rem' }} >
            <div style={{ width: "98%", position: "absolute", marginTop: "520px" }}>
              <div className="centerLine"></div>
              {this.statusNames.map((item, index) => (
                  <div className="bar-circle" key={index}>
                    <div className="inside-circle"></div>
                    <div className="bar-title">{item}</div>
                  </div>
                ))}
            </div>
            <C3Chart data={dataColumn} grid={gridColumn} legend={legendColumn} axis={axis} bar={bar} size={sizeColumn} tooltip={tooltipColumn} />
          </Col>
        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.status,
  };
}

export default connect(mapStateToProps, { getGrievancesStatus })(GrievancesStatusWidget);
