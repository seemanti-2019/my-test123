import React from 'react';
import { connect } from 'react-redux';
import { Col, Card, Form } from 'react-bootstrap';
import { getGrievancesSupplierInfo } from '../../actions/index';
import C3Chart from 'react-c3js';
import 'c3/c3.css';

class LocationWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
      debugger
    this.props.getGrievancesSupplierInfo();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }


  render() {

    const dataPie = {
        columns: [
            ['direct parties', this.props.grievances.directParties],
            ['indirect parties', this.props.grievances.indirectParties],
        ],
        type: 'pie',
        onclick: function (d, i) { console.log("onclick", d, i); },
        onmouseover: function (d, i) { console.log("onmouseover", d, i); },
        onmouseout: function (d, i) { console.log("onmouseout", d, i); }
    };

    const legendPie = {
        position: 'right',
        item: {
            onclick: function () { }
        }
    };
    const colorPie = {
        pattern: ['#638C1C', '#DDAA01']
    };
    const sizePie = {
        height: 240,
        width: 480
    };

    const tooltipPie = {
        show: false
    };
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Number of grievances to direct and indirect suppliers of Cargill</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'12px'}}>
            We consider greviences that are raised against our direct suppliers to be our responsibility, meaning that we will engage with them to develop action plans and monitor them actively.
          </Form.Text>
          <Col sm={12} style={{padding:'1em'}} >
            <C3Chart data={dataPie} legend={legendPie} color={colorPie} size={sizePie} tooltip={ tooltipPie} />
          </Col>
        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.pieChart,
  };
}

export default connect(mapStateToProps, { getGrievancesSupplierInfo })(LocationWidget);
