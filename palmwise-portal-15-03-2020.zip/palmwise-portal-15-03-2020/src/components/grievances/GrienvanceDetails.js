import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history'
import { Button, Row, Col, Card, Image } from 'react-bootstrap';
import { getGrievancesList, getGrievanceDetails, getTimelineTop, getTimelineBottom, showHideTimelineTooltip } from '../../actions/index';
import SubscriptionAndFAQ from './SubscriptionAndFAQ';
import DownloadPanel from './DownloadPanel';
import Timeline from './Timeline';
import Map from "../../assets/map.png"

class GrienvanceDetails extends React.PureComponent {

    constructor(props) {
        super(props);
        this.textInput = React.createRef();        
    }
    showTooltip = id => {
        this.props.showHideTimelineTooltip(id);
    }
    exportCSV = () => {
        let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
        let ref = this.textInput;
        ref.current.href = URL.createObjectURL(blob);
        ref.current.download = 'data.csv';
        ref.current.click();
    }

    componentDidMount() {
        this.props.getGrievancesList();
        this.props.getGrievanceDetails(this.props.id);
        this.props.getTimelineTop();
        this.props.getTimelineBottom();
    }

    componentWillReceiveProps(nextProps) {

    }

    test1 = () => {
        history.push('/');
    }

    test2 = () => {
        history.push('/grievances');
    }

    test3 = () => {
        history.push('/grievancesoverview');
    }

    render() {
        let detailData = this.props.grievanceDetail;
        return (
            <div style={{ margin: "0 2rem 0 2rem" }}>
                <Row style={{ paddingTop: '1em', paddingLeft: '2em' }}>
                    <Col>
                        <Row>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test1()}>Home</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test2()}>My grievances</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#A5A5A5', fontSize: '18px', fontWeight: '600' }} onClick={(e) => this.test3()}>Grievances Overview</Button>
                            <div style={{ borderLeft: '3px solid lightgray', height: '30px', marginTop: '5px' }}></div>
                            <Button variant="link" style={{ color: '#000', fontSize: '18px', fontWeight: '600' }} >Grievances Details</Button></Row>
                    </Col>
                </Row>
                <Card style={{ marginTop: "1rem" }}>
                    <Card.Body>
                        <Row><Col>Felda Global Ventures</Col></Row>
                        <Row><Col><h2>{detailData.name}</h2></Col></Row>
                        <Row>
                            <Col md={5}>
                                <Row><Col><h6>{detailData.subHeading}</h6></Col></Row>
                                <Row><Col>{detailData.description}</Col></Row>
                                <Row style={{ marginTop: "2rem" }}>
                                    <Col md={4}>Grievance Entity</Col>
                                    <Col md={8}>{detailData.entity}</Col>
                                </Row>
                                <Row style={{ marginTop: "1rem" }}>
                                    <Col md={4}>Grievance raiser</Col>
                                    <Col md={8}>{detailData.raiser}</Col>
                                </Row>
                                <Row style={{ marginTop: "1rem" }}>
                                    <Col md={4}>Date raised</Col>
                                    <Col md={8}>{detailData.date}</Col>
                                </Row>
                                <Row style={{ marginTop: "1rem" }}>
                                    <Col md={4}>Source</Col>
                                    <Col md={8}>{detailData.source}</Col>
                                </Row>
                                <Row style={{ marginTop: "1rem" }}>
                                    <Col md={4}>Last Updated</Col>
                                    <Col md={8}>{detailData.lastUpdated}</Col>
                                </Row>
                            </Col>
                        </Row>
                        <Row style={{ paddingTop: '3rem' }}>
                            <Timeline type="timeline" timelineData={this.props.timelineTop} status={detailData.status} statusFlag="true" showTooltip={this.showTooltip} />
                        </Row>
                        <Row>
                            <Col><Image src={Map} width="100%" height="400"></Image></Col>
                        </Row>
                        <Row>
                            <Timeline type="year" timelineData={this.props.timelineBottom} statusFlag="false" />
                        </Row>
                    </Card.Body>
                </Card>
                <Card style={{ marginTop: "2rem", marginBottom: "1rem", marginLeft: "1rem" }}>
                    <DownloadPanel textInput={this.textInput} exportCSV={this.exportCSV} />
                </Card>
                <SubscriptionAndFAQ source="myGrievances" />
            </div>
        )

    }
}


const mapStateToProps = state => {
    console.log(state);
    return {
        grievanceDetail: state.grievances.selectedGrievance,
        timelineTop: state.grievances.timelineTop,
        timelineBottom: state.grievances.timelineBottom,
    };
}

export default connect(mapStateToProps, { getGrievancesList, getGrievanceDetails, getTimelineTop, getTimelineBottom, showHideTimelineTooltip })(GrienvanceDetails);
