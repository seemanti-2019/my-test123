import { GET_DEFORESTATION_FREE_DATA, GET_LAND_COVER_DATA, GET_TOTAL_AREA_OF_DEFORESTATION } from '../actions/types';


const INITIAL_STATE = {
     deforestationFreeData: [
        { name: 'Deforestation-free', value: 0, color: '#568c2d'},
        { name: 'Non-deforestation-free', value: 0, color: '#a1ad1a'},
        { name: 'Unknown', value: 0, color: '#bd3f15'}
      ],  
     landCoverData : [
        { name: 'Forest', value: 0, color: '#199c7d'},
        { name: 'Peatland', value: 0, color: '#cfc021'},
        { name: 'Plantation', value: 0, color: '#a1ad1a'},
        { name: 'Other', value: 0, color: '#bd3f15'}
      ],
     totalDeforestationArea: []   
};

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {
        case GET_DEFORESTATION_FREE_DATA:
            return { ...state, deforestationFreeData: action.payload };
        case GET_LAND_COVER_DATA:
            return { ...state, landCoverData: action.payload};
        case GET_TOTAL_AREA_OF_DEFORESTATION:
            return { ...state, totalDeforestationArea: action.payload}     
        default:
            return state;
    }
}