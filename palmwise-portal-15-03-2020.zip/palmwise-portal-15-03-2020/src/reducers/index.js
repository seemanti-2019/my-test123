import { combineReducers } from 'redux';
import HomeReducer from './HomeReducer';
import FilterReducer from './FilterReducer';
import GrievancesReducer from './GrievancesReducer';
import SupplyChainReducer from './SupplyChainReducer';
import NavigationReducer from './RootReducer';
import ForestProtectionReducer from './ForestProtectionReducer';

export default combineReducers({
    home:HomeReducer,
    filters:FilterReducer,
    grievances:GrievancesReducer,
    supplychain:SupplyChainReducer,
    selection: NavigationReducer,
    forest: ForestProtectionReducer
  })