import { GET_GRIEVANCES_LOCATION, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST,
    GET_GRIEVANCES_FILTER_OPTIONS, GET_GRIEVANCES_ORDER, GET_GRIEVANCE_DETAIL, GET_TIMELINE_TOP, GET_TIMELINE_BOTTOM } from '../actions/types';


const INITIAL_STATE = {
    location: [],
    pieChart: { "directParties": 0, "indirectParties": 0 },
    status: { "environmentalIssues": [0,0,0,0,0,0], "socialIssues": [0,0,0,0,0,0], "legalIssues": [0,0,0,0,0,0] },
    list: [],
    filterOptions: {
        ventureItems: [],
        statusItems: [],
        countryItems: [],
    },
    sortOrder: 'desc',
    selectedGrievance: {},
    timelineTop: [],
    timelineBottom: []
};

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {
        case GET_GRIEVANCES_LOCATION:
            return { ...state, location: action.payload };
        case GET_GRIEVANCES_SUPPLIER_INFO:
            return { ...state, pieChart: action.payload };
        case GET_GRIEVANCES_STATUS:
            return { ...state, status: action.payload };
        case GET_GRIEVANCES_LIST:
            return { ...state, list: action.payload };
        case GET_GRIEVANCES_FILTER_OPTIONS:
            return {...state, filterOptions: action.payload };
        case GET_GRIEVANCES_ORDER:
            return {...state, sortOrder: action.payload};
        case GET_GRIEVANCE_DETAIL:
            return {...state, selectedGrievance: action.payload};  
        case GET_TIMELINE_TOP:
            return {...state, timelineTop: action.payload}; 
        case GET_TIMELINE_BOTTOM:
            return {...state, timelineBottom: action.payload};           
        default:
            return state;
    }
}