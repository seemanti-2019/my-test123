import { NAV_TAB } from '../actions/types';


const INITIAL_STATE = {
navSelection: {},
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
case NAV_TAB:
    return {...state, navSelection: action.payload };
default:
return state;

}
}