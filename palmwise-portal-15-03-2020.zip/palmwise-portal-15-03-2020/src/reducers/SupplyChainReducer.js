import { GET_RISK_PER_MILL, GET_SUPPLY_CHAIN_WIDGET, GET_COUNTRY_VOLUME } from '../actions/types';


const INITIAL_STATE = {
    risk: {},
    millCount:0,
    volumes:[],
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
    case GET_RISK_PER_MILL:
    return {...state, risk: action.payload };
    case GET_SUPPLY_CHAIN_WIDGET:
    return {...state, millcount: action.payload };
    case GET_COUNTRY_VOLUME:
    return {...state, volumes: action.payload };
default:
    return state;

}
}