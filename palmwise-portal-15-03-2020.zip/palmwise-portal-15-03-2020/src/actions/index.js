import {
  TEST, GET_FILTER_OPTIONS, GET_FILTER_WIDGET, TRACIBILITY_DATA, GET_MY_VOLUME_DATA, GET_NEWS, GET_DOWNLOADS, GET_GRIEVANCES_LOCATION,
  GET_RISK_PER_MILL, GET_SUPPLY_CHAIN_WIDGET, GET_COUNTRY_VOLUME, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST,
  NAV_TAB, GET_GRIEVANCES_FILTER_OPTIONS, GET_GRIEVANCES_ORDER, GET_GRIEVANCE_DETAIL, GET_TIMELINE_TOP, GET_TIMELINE_BOTTOM, GET_DEFORESTATION_FREE_DATA, GET_LAND_COVER_DATA, GET_TOTAL_AREA_OF_DEFORESTATION
} from './types';

let userFilterSelections = [];
let selectedObj = {};
let globalSelections = {};
let millData = [];
let volumes = [];
let grievancesSortOrder = 'desc';
let grievancesList = [];
let timelineTop = [];

export const changeName = () => {
  return (dispatch) => {
    dispatch({ type: TEST, payload: 'World' });
  };
};

export const getFiltersOptions = () => {
  return (dispatch) => {
    debugger
    let results;
    if (Object.keys(globalSelections).length === 0) {
      results = {
        product_group: [{ name: 'Palm Oil', checked: false }, { name: 'Palm Kernel Oil', checked: false }],
        rspo: [{ name: 'Mass Balance', checked: false }, { name: 'Segregated', checked: false }, { name: 'Classic', checked: false }],
        year_quater: ['2019-Q2'],
        destination: [{ name: 'Europe', checked: false }, { name: 'Brazil', checked: false }],
      };
    } else {
      results = JSON.parse(JSON.stringify(globalSelections));
    }

    userFilterSelections = [];
    dispatch({ type: GET_FILTER_OPTIONS, payload: results });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
  };
};

export const updateUserOptions = (data, selection, value, key) => {
  return (dispatch) => {
    debugger

    if (Object.keys(data).includes(key)) {
      data[key].map((item) => {
        if (item.name === selection) {
          item.checked = value
        }
      })
    }

    if (value) {
      selectedObj = {};
      selectedObj.key = key;
      selectedObj.selection = selection;
      userFilterSelections.push(selectedObj);
    } else {
      userFilterSelections = userFilterSelections.filter((item) => item.selection !== selection)
    }
    globalSelections = JSON.parse(JSON.stringify(data));


    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  };
};

export const clearUserOptions = (data) => {
  return (dispatch) => {
    Object.keys(data).map(key => {
      data[key].map(item => {
        if (item.hasOwnProperty('checked'))
          item.checked = false
      })
    })
    userFilterSelections = [];
    globalSelections = JSON.parse(JSON.stringify(data));


    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
}

export const applyUserSelections = (data) => {
  return (dispatch) => {
    debugger
    console.log(data)
    console.log(userFilterSelections)
    let searchEurope = userFilterSelections.filter(function (entry) { return entry.selection === "Europe"; })
    let searchBrazil = userFilterSelections.filter(function (entry) { return entry.selection === "Brazil"; })
    let searchMB = userFilterSelections.filter(function (entry) { return entry.selection === "Mass Balance"; })
    let searchSegregated = userFilterSelections.filter(function (entry) { return entry.selection === "Segregated"; })
    let searchClassic = userFilterSelections.filter(function (entry) { return entry.selection === "Classic"; })
    let searchPalm = userFilterSelections.filter(function (entry) { return entry.selection === "Palm Oil"; })
    let searchKernal = userFilterSelections.filter(function (entry) { return entry.selection === "Palm Kernel Oil"; })
    console.log(millData)
    let millCount = 0;
    if (searchEurope.length !== 0 && searchMB.length !== 0 && searchKernal.length !== 0) {
      millCount = 25;
    } else if (searchEurope.length !== 0 && searchClassic.length !== 0 && searchKernal.length !== 0) {
      millCount = 12;
    } else if (searchBrazil.length !== 0 && searchClassic.length !== 0 && searchPalm.length !== 0) {
      millCount = 262;
    } else if (searchEurope.length !== 0 && searchSegregated.length !== 0 && searchKernal.length !== 0) {
      millCount = 3;
    } else if (searchBrazil.length !== 0 && searchClassic.length !== 0 && searchKernal.length !== 0) {
      millCount = 257;
    } else if (searchPalm.length !== 0 && searchMB.length !== 0 && searchPalm.length !== 0) {
      millCount = 143;
    }
    else {

    }

    if (searchEurope.length != 0) {
      volumes = [
        {
          "volume_percent": "45.81708779363854",
          "load_country": "Colombia"
        },
        {
          "volume_percent": "22.99031799814339",
          "load_country": "Guatemala"
        },
        {
          "volume_percent": "17.27535174227927",
          "load_country": "Malaysia"
        },
        {
          "volume_percent": "13.91724246593881",
          "load_country": "Others"
        }
      ]
    }
    else {
      volumes = [
        {
          "volume_percent": "32.87165677160884",
          "load_country": "Indonesia"
        },
        {
          "volume_percent": "30.75625195136698",
          "load_country": "Colombia"
        },
        {
          "volume_percent": "15.43301957509228",
          "load_country": "Guatemala"
        },
        {
          "volume_percent": "20.93907170193191",
          "load_country": "Others"
        }
      ]
    }
    dispatch({ type: GET_SUPPLY_CHAIN_WIDGET, payload: millCount })
    dispatch({ type: GET_COUNTRY_VOLUME, payload: volumes });
    dispatch({ type: GET_FILTER_OPTIONS, payload: data });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });

  }
}

export const editFilters = (data) => {
  return (dispatch) => {
    debugger
    if (userFilterSelections.length === 0) {
      Object.keys(data).map(key => {
        data[key].map((item => {
          if (item.hasOwnProperty('checked'))
            item.checked = true
        }))
      })

      Object.keys(data).map(key => {
        data[key].map((item => {
          let obj = {};
          obj.key = key;
          obj.selection = item.name;
          userFilterSelections.push(obj);
        }))
      })



      globalSelections = JSON.parse(JSON.stringify(data));
      dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    }
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
}

export const getTracibilityData = () => {
  return (dispatch) => {
    let obj = { 'mills': 85, 'plantation': 48 }
    dispatch({ type: TRACIBILITY_DATA, payload: obj });
  }
}

export const getMyVolumeData = () => {
  return (dispatch) => {
    let obj = [
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "Classic",
        "Product_Certification_Net_Bl_Qty": 7728.811,
        "Volume_Percentage": 42.03874915
      },
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "MB",
        "Product_Certification_Net_Bl_Qty": 9144.246,
        "Volume_Percentage": 49.7376199
      },
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "SG",
        "Product_Certification_Net_Bl_Qty": 1511.912,
        "Volume_Percentage": 8.223630945
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "Classic",
        "Product_Certification_Net_Bl_Qty": 5050,
        "Volume_Percentage": 87.06896552
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "MB",
        "Product_Certification_Net_Bl_Qty": 750,
        "Volume_Percentage": 12.93103448
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "SG",
        "Product_Certification_Net_Bl_Qty": 750,
        "Volume_Percentage": 0
      }
    ]

    debugger
    let key = ['Classic', 'MB', 'SG'];
    let dummyKernal = obj.filter((item) => item.Product_Group !== 'Palm');
    let dummyPalm = obj.filter((item) => item.Product_Group !== 'Kernel');

    let kernal_Coll = []
    key.map(item1 => {
      dummyKernal.map((item, index) => {
        if (Object.values(item).includes(item1)) {
          kernal_Coll.push(item);
          dummyKernal.splice(index, 1);
        }
      });
    });

    console.log(kernal_Coll);


    let palm_Coll = []
    key.map(item1 => {
      dummyPalm.map((item, index) => {
        if (Object.values(item).includes(item1)) {
          palm_Coll.push(item);
          dummyPalm.splice(index, 1);
        }
      });
    });

    let filterdCollection = {};
    filterdCollection.kernal_coll = kernal_Coll;
    filterdCollection.palm_coll = palm_Coll;
    filterdCollection.kernalMT = Math.round(filterdCollection.palm_coll[0].Product_Group_Net_Bl_Qty * 10) / 10;
    filterdCollection.palmMT = Math.round(filterdCollection.kernal_coll[0].Product_Group_Net_Bl_Qty * 10) / 10;




    dispatch({ type: GET_MY_VOLUME_DATA, payload: filterdCollection });
  }
}


export const getNewsData = () => {
  return (dispatch) => {
    let obj = [{ 'link': 'https://www.cargill.com/2019/cargill-launches-independent-forest-protection-advisory-panel', 'name': 'Cargill launches independent forest protection advisory panel' },
    { 'link': 'https://www.cargill.com/2019/palm-oil-industry-to-jointly-develop-radar-monitoring-technology', 'name': 'Palm Oil Industry to Jointly Develop Radar Monitoring Technology to Detect Deforestation' },
    { 'link': 'https://www.cargill.com/2019/cargill-supports-indonesian-smallholder-farmers-with-global', 'name': 'Cargill supports Indonesian smallholder farmers with global sustainable palm oil certification' }]
    dispatch({ type: GET_NEWS, payload: obj });
  }
}

export const getDownloadData = () => {
  return (dispatch) => {
    let obj = [{ 'link': 'https://www.cargill.com/doc/1432155778288/cargill-palm-mill-list-q3-2019.pdf', 'name': 'Cargill’s Mill List' },
    { 'link': 'https://www.cargill.com/doc/1432076149492/palm-oil-policy-statement-pdf.pdf', 'name': 'Cargill’s Policy on Sustainable Palm Oil' },
    { 'link': 'https://www.cargill.com/doc/1432144706116/cargill-2018-palm-report.pdf', 'name': 'Cargill Palm Oil Annual Report' }]
    dispatch({ type: GET_DOWNLOADS, payload: obj });
  }
}

export const getGrievancesLocation = () => {
  return (dispatch) => {

    var arr = [{ "COUNTRY": "Indonesia", "GRIEVANCES": 43, "TOTAL_GRIEVANCES": 60 },
    { "COUNTRY": "Malaysia", "GRIEVANCES": 10, "TOTAL_GRIEVANCES": 60 },
    { "COUNTRY": "Papua New Guinea", "GRIEVANCES": 2, "TOTAL_GRIEVANCES": 60 },
    { "COUNTRY": "Other Countries", "GRIEVANCES": 5, "TOTAL_GRIEVANCES": 60 }]
    dispatch({ type: GET_GRIEVANCES_LOCATION, payload: arr });
  }
}

export const getRiskPerMill = () => {
  return (dispatch) => {

    var obj = { "total_low_risk_mill": 58, "total_medium_risk_mill": 104, "total_high_risk_mill": 125 }
    dispatch({ type: GET_RISK_PER_MILL, payload: obj });
  }
}

export const getSupplyChainWidgetData = () => {
  return (dispatch) => {
    millData = [
      {
        "product_group": "Kernel",
        "product_certification": "Classic",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 12,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "MB",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 25,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Palm",
        "product_certification": "Classic",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 262,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "SG",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 3,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "Classic",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 257,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Palm",
        "product_certification": "MB",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 143,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      }
    ]

    dispatch({ type: GET_SUPPLY_CHAIN_WIDGET, payload: millData[0].total_3rd_party_mill_count })
  }
}

export const getByCountryVolumes = () => {
  return (dispatch) => {
    volumes = [
      {
        "volume_percent": "32.87165677160884",
        "load_country": "Indonesia"
      },
      {
        "volume_percent": "30.75625195136698",
        "load_country": "Colombia"
      },
      {
        "volume_percent": "15.43301957509228",
        "load_country": "Guatemala"
      },
      {
        "volume_percent": "20.93907170193191",
        "load_country": "Others"
      }
    ]

    dispatch({ type: GET_COUNTRY_VOLUME, payload: volumes });
  }
}

export const getGrievancesSupplierInfo = () => {
  return (dispatch) => {

    let linkWithSuppliers = {
      "directParties": 13,
      "indirectParties": 47,
    }

    dispatch({ type: GET_GRIEVANCES_SUPPLIER_INFO, payload: linkWithSuppliers });
  }
}

export const getGrievancesStatus = () => {
  return (dispatch) => {
    let environmentalIssues = [];
    let socialIssues = [];
    let legalIssues = [];
    let actualStatusData = [
      {
        "Stage": "Investigation",
        "Environmental_Issues": 5,
        "Env_total": 51,
        "Social_Issues": 2,
        "Social_total": 9
      },
      {
        "Stage": "Verification",
        "Environmental_Issues": 0,
        "Env_total": 51,
        "Social_Issues": 0,
        "Social_total": 9
      },
      {
        "Stage": "Development of Action Plan",
        "Environmental_Issues": 5,
        "Env_total": 51,
        "Social_Issues": 0,
        "Social_total": 9
      },
      {
        "Stage": "Monitoring Implementation",
        "Environmental_Issues": 18,
        "Env_total": 51,
        "Social_Issues": 4,
        "Social_total": 9
      },
      {
        "Stage": "Suspended",
        "Environmental_Issues": 19,
        "Env_total": 51,
        "Social_Issues": 3,
        "Social_total": 9
      },
      {
        "Stage": "Closed",
        "Environmental_Issues": 4,
        "Env_total": 51,
        "Social_Issues": 0,
        "Social_total": 9
      }];
    actualStatusData.map(item => {
      environmentalIssues.push(item.Environmental_Issues);
      socialIssues.push(item.Social_Issues);
      legalIssues.push(0);
    })
    let grievanceStatus = {
      "environmentalIssues": environmentalIssues,
      "socialIssues": socialIssues,
      "legalIssues": legalIssues
    }
    // let grievanceStatus = {
    //   "environmentalIssues":
    //     [200, 200, 260, 300, 80, 100],
    //   "socialIssues":
    //     [400, 290, 170, 480, 250, 300],
    //   "legalIssues":
    //     [600, 200, 100, 80, 450, 300]
    // }

    dispatch({ type: GET_GRIEVANCES_STATUS, payload: grievanceStatus });
  }
}

export const getGrievancesList = () => {
  return (dispatch) => {
    let lst = [
      {
        "id": 1,
        "name": "Deforestation",
        "subHeading": "Issue Under Review",
        "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
        "entity": "Asian Plantation Limited(Indirect party)",
        "raiser": "Aid Environment",
        "status": "Verification",
        "date": "Jan 22,2020",
        "country": "Indonasia",
        "source": "Not available for this grievance",
        "lastUpdated": "3 days ago"
      },
      {
        "id": 2,
        "name": "Development on peat",
        "subHeading": "Issue Under Review",
        "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
        "entity": "Asian Plantation Limited(Grand performance)",
        "raiser": "Aid Environment",
        "status": "Implementation of action plan",
        "date": "Dec 12,2019",
        "country": "Malaysia",
        "source": "Not available for this grievance",
        "lastUpdated": "3 days ago"
      },
      {
        "id": 3,
        "name": "Human rights",
        "subHeading": "Issue Under Review",
        "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
        "entity": "Asian Plantation Limited(Grand performance)",
        "raiser": "Aid Environment",
        "status": "Closed",
        "date": "Jan 18,2020",
        "country": "Indonasia",
        "source": "Not available for this grievance",
        "lastUpdated": "3 days ago"
      }
    ]
    grievancesList = [...lst];
    dispatch({ type: GET_GRIEVANCES_LIST, payload: lst });
  }
}

export const navigateSelections = (selection) => {
  return (dispatch) => {
    dispatch({ type: NAV_TAB, payload: selection });
  }
}

export const getGrievancesFiltersOptions = () => {
  return (dispatch) => {
    let results;
    results = {
      ventureItems: [
        { label: 'Lorem Ipsum', value: 'LI1' },
        { label: 'Lorem Ipsum', value: 'LI2' },
        { label: 'Lorem Ipsum', value: 'LI3' }
      ],
      statusItems: [
        { label: 'Investigation', value: 'Investigation' },
        { label: 'Verification', value: 'Verification' },
        { label: 'Implementation of action plan', value: 'Implementation of action plan' },
        { label: 'Monitoring Implementation', value: 'Monitoring Implementation' },
        { label: 'Closed', value: 'Closed' }
      ],
      countryItems: [
        { label: 'Indonasia', value: 'Indonasia' },
        { label: 'Malaysia', value: 'Malaysia' }
      ]
    };
    dispatch({ type: GET_GRIEVANCES_FILTER_OPTIONS, payload: results });
  };
};

export const getGrievancesSortOrder = () => {
  return (dispatch) => {
    dispatch({ type: GET_GRIEVANCES_ORDER, payload: grievancesSortOrder });
  };
};

export const applyGrievancesSorting = (order) => {
  return (dispatch) => {
    switch (order) {
      case 'asc': {
        grievancesList.sort((a, b) => (a.date > b.date) ? 1 : ((b.date > a.date) ? -1 : 0))
        break;
      }
      case 'desc': {
        grievancesList.sort((a, b) => (a.date < b.date) ? 1 : ((b.date < a.date) ? -1 : 0))
        break;
      }
      default:
        break;
    }

    dispatch({ type: GET_GRIEVANCES_ORDER, payload: order });
    dispatch({ type: GET_GRIEVANCES_LIST, payload: grievancesList });
  };
};

export const updateGrievancesFilter = (field, value) => {
  return () => {
    grievancesList = grievancesList.filter((item) => item[field] === value)
  };
};

export const applyGrievancesFilter = () => {
  return (dispatch) => {
    dispatch({ type: GET_GRIEVANCES_LIST, payload: grievancesList });
  };
}

export const getGrievanceDetails = (id) => {
  return (dispatch) => {
    let detailData = grievancesList.filter(data => data.id === +id);
    detailData = detailData[0];
    dispatch({ type: GET_GRIEVANCE_DETAIL, payload: detailData });
  }
}

export const getTimelineTop = () => {
  return (dispatch) => {
    let timeline = [
      { id: 1, text: "Investigation", active: true, suspended: false, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) ' },
      { id: 2, text: "Verification", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
      { id: 3, text: "Implementation of action plan", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
      { id: 4, text: "Monitoring Implementation", active: true, suspended: true, showTooltip: false, tooltipText: 'Cargill reached out to FGV on the alligations (January 22-2019) Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod consectetur adipisicing elit, sed do eiusmod' },
      { id: 5, text: "Closed", active: true, suspended: false, showTooltip: false },
    ].reverse();
    timelineTop = [...timeline];
    dispatch({ type: GET_TIMELINE_TOP, payload: timeline });
  }
}

export const getTimelineBottom = () => {
  return (dispatch) => {
    let timeline = [
      { id: 1, text: "2017", active: false, suspended: false },
      { id: 2, text: "2018", active: false, suspended: false },
      { id: 3, text: "2019", active: false, suspended: false },
      { id: 4, text: "2020", active: true, suspended: false }
    ].reverse();
    dispatch({ type: GET_TIMELINE_BOTTOM, payload: timeline });
  }
}

export const showHideTimelineTooltip = (id) => {
  return (dispatch) => {
    let listData = timelineTop.map(item => {
      if (item.id === id) {
        item.showTooltip = !item.showTooltip;
      } else {
        item.showTooltip = false;
      }
      return item;
    });
    dispatch({ type: GET_TIMELINE_TOP, payload: listData });
  }
}

export const getDeforestationFreeData = () => {
  return (dispatch) => {
    let deforestationFreeData = [
      { name: 'Deforestation-free', value: 60, color: '#568c2d' },
      { name: 'Non-deforestation-free', value: 60, color: '#a1ad1a' },
      { name: 'Unknown', value: 60, color: '#bd3f15' }
    ];
    dispatch({ type: GET_DEFORESTATION_FREE_DATA, payload: deforestationFreeData });
  }
}

export const getLandCoverData = () => {
  return (dispatch) => {
    let landCoverData = [
      { name: 'Forest', value: 60, color: '#199c7d' },
      { name: 'Peatland', value: 50, color: '#cfc021' },
      { name: 'Plantation', value: 40, color: '#a1ad1a' },
      { name: 'Other', value: 30, color: '#bd3f15' }
    ];
    dispatch({ type: GET_LAND_COVER_DATA, payload: landCoverData });
  }
}

export const getTotalAreaOfDeforestation = () => {
  return (dispatch) => {
    let totalArea = [200, 210, 190, 220, 200, 240, 190, 220];
    dispatch({ type: GET_TOTAL_AREA_OF_DEFORESTATION, payload: totalArea });
  }
}



