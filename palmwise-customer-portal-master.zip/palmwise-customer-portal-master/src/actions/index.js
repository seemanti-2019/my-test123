import {TEST, GET_FILTER_OPTIONS, GET_FILTER_WIDGET, TRACIBILITY_DATA, GET_MY_VOLUME_DATA, GET_NEWS, GET_DOWNLOADS, GET_GRIEVANCES_LOCATION,
  GET_RISK_PER_MILL, GET_SUPPLY_CHAIN_WIDGET, GET_COUNTRY_VOLUME, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST,
  NAV_TAB} from './types';

let userFilterSelections=[];
let selectedObj={};
let globalSelections = {};
let millData = [];
let volumes = [];

export const changeName = () => {
    return (dispatch) => {
      dispatch({ type: TEST, payload: 'World' });
    };
  };

export const getFiltersOptions = () => {
  return (dispatch) => {
    debugger
    let results;
    if(Object.keys(globalSelections).length === 0){
       results = {
        product_group:[{name:'Palm Oil',checked:false},{name:'Palm Kernel Oil',checked:false}], 
        rspo:[{name:'Mass Balance', checked:false},{name:'Segregated', checked:false},{name:'Classic', checked:false}], 
        year_quater:['2019-Q2'], 
        destination:[{name:'Europe', checked:false},{name:'Brazil', checked:false}], 
      };
    }else{
      results = JSON.parse(JSON.stringify(globalSelections));
    }
    
    userFilterSelections=[];
    dispatch({ type: GET_FILTER_OPTIONS, payload: results });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
  };
};

export const updateUserOptions = (data, selection, value, key) => {
  return (dispatch) => {
    debugger

    if(Object.keys(data).includes(key)){
      data[key].map((item) =>{
          if(item.name === selection){
              item.checked = value
          }
      })
    }

    if(value){
      selectedObj = {};
      selectedObj.key = key;
      selectedObj.selection = selection;
      userFilterSelections.push(selectedObj);
    }else{
      userFilterSelections = userFilterSelections.filter((item) => item.selection !== selection)
    }
    globalSelections = JSON.parse(JSON.stringify(data));


    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  };
};

export const clearUserOptions = (data) => {
  return(dispatch) => {
    Object.keys(data).map(key=>{
      data[key].map(item=>{
        if(item.hasOwnProperty('checked'))
        item.checked = false
      })
    })
    userFilterSelections = [];
    globalSelections = JSON.parse(JSON.stringify(data));
    

    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
}

export const applyUserSelections = (data) => {
  return(dispatch) => {
    debugger
    console.log(data)
    console.log(userFilterSelections)
    let searchEurope = userFilterSelections.filter(function (entry) { return entry.selection === "Europe"; })
    let searchBrazil = userFilterSelections.filter(function (entry) { return entry.selection === "Brazil"; })
    let searchMB = userFilterSelections.filter(function (entry) { return entry.selection === "Mass Balance"; })
    let searchSegregated = userFilterSelections.filter(function (entry) { return entry.selection === "Segregated"; })
    let searchClassic = userFilterSelections.filter(function (entry) { return entry.selection === "Classic"; })
    let searchPalm = userFilterSelections.filter(function (entry) { return entry.selection === "Palm Oil"; })
    let searchKernal = userFilterSelections.filter(function (entry) { return entry.selection === "Palm Kernel Oil"; })
    console.log(millData)
    let millCount = 0; 
    if(searchEurope.length!==0 && searchMB.length!==0 && searchKernal.length!==0){
      millCount = 25;
    }else if(searchEurope.length!==0 && searchClassic.length!==0 && searchKernal.length!==0){
      millCount = 12;
    }else if(searchBrazil.length!==0 && searchClassic.length!==0 && searchPalm.length!==0){
      millCount = 262;
    }else if(searchEurope.length!==0 && searchSegregated.length!==0 && searchKernal.length!==0){
      millCount = 3;
    }else if(searchBrazil.length!==0 && searchClassic.length!==0 && searchKernal.length!==0){
      millCount = 257;
    }else if(searchPalm.length!==0 && searchMB.length!==0 && searchPalm.length!==0){
      millCount = 143;
    }
    else{

    } 
    
    if(searchEurope.length != 0){
      volumes = [
        {
          "volume_percent": "45.81708779363854",
          "load_country": "Colombia"
        },
        {
          "volume_percent": "22.99031799814339",
          "load_country": "Guatemala"
        },
        {
          "volume_percent": "17.27535174227927",
          "load_country": "Malaysia"
        },
        {
          "volume_percent": "13.91724246593881",
          "load_country": "Others"
        }
       ]
    }
    else{
      volumes = [
        {
          "volume_percent": "32.87165677160884",
          "load_country": "Indonesia"
        },
        {
          "volume_percent": "30.75625195136698",
          "load_country": "Colombia"
        },
        {
          "volume_percent": "15.43301957509228",
          "load_country": "Guatemala"
        },
        {
          "volume_percent": "20.93907170193191",
          "load_country": "Others"
        }
       ]
    }
    dispatch({ type: GET_SUPPLY_CHAIN_WIDGET, payload: millCount})
    dispatch({ type: GET_COUNTRY_VOLUME, payload: volumes });
    dispatch({ type: GET_FILTER_OPTIONS, payload: data });
    dispatch({ type: GET_FILTER_WIDGET, payload: false });
    
  }
}

export const editFilters = (data) => {
  return(dispatch) => {
    debugger
    if(userFilterSelections.length === 0){
      Object.keys(data).map(key=>{
        data[key].map((item=>{
          if(item.hasOwnProperty('checked'))
          item.checked = true
        }))
      })

      Object.keys(data).map(key=>{
        data[key].map((item=>{
          let obj = {};
          obj.key = key;
          obj.selection = item.name;
          userFilterSelections.push(obj);
        }))
      })

      
    
    globalSelections = JSON.parse(JSON.stringify(data));
    dispatch({ type: GET_FILTER_OPTIONS, payload: globalSelections });
  }
    dispatch({ type: GET_FILTER_WIDGET, payload: true });
  }
} 

export const getTracibilityData = () => {
  return(dispatch) => {
    let obj = {'mills':85, 'plantation':48}
    dispatch({ type: TRACIBILITY_DATA, payload: obj });
  }
} 

export const getMyVolumeData = () => {
  return(dispatch) => {
    let obj = [
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "Classic",
        "Product_Certification_Net_Bl_Qty": 7728.811,
        "Volume_Percentage": 42.03874915
      },
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "MB",
        "Product_Certification_Net_Bl_Qty": 9144.246,
        "Volume_Percentage": 49.7376199
      },
      {
        "Product_Group": "Kernel",
        "Product_Group_Net_Bl_Qty": 18384.969,
        "Product_Certification": "SG",
        "Product_Certification_Net_Bl_Qty": 1511.912,
        "Volume_Percentage": 8.223630945
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "Classic",
        "Product_Certification_Net_Bl_Qty": 5050,
        "Volume_Percentage": 87.06896552
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "MB",
        "Product_Certification_Net_Bl_Qty": 750,
        "Volume_Percentage": 12.93103448
      },
      {
        "Product_Group": "Palm",
        "Product_Group_Net_Bl_Qty": 5800,
        "Product_Certification": "SG",
        "Product_Certification_Net_Bl_Qty": 750,
        "Volume_Percentage": 0
      }
     ]

     debugger
     let key = ['Classic', 'MB', 'SG'];
     let dummyKernal = obj.filter((item) => item.Product_Group !== 'Palm');
     let dummyPalm = obj.filter((item) => item.Product_Group !== 'Kernel');

     let kernal_Coll = []
     key.map(item1 => {
      dummyKernal.map((item, index) => {
        if(Object.values(item).includes(item1)){
          kernal_Coll.push(item);
          dummyKernal.splice(index, 1);
        }
      });
     });

     console.log(kernal_Coll);
     

     let palm_Coll = []
     key.map(item1 => {
      dummyPalm.map((item, index) => {
        if(Object.values(item).includes(item1)){
          palm_Coll.push(item);
          dummyPalm.splice(index, 1);
        }
      });
     });

     let filterdCollection = {};
     filterdCollection.kernal_coll = kernal_Coll;
     filterdCollection.palm_coll = palm_Coll;
     filterdCollection.kernalMT = Math.round(filterdCollection.palm_coll[0].Product_Group_Net_Bl_Qty * 10 ) / 10;
     filterdCollection.palmMT = Math.round(filterdCollection.kernal_coll[0].Product_Group_Net_Bl_Qty * 10 ) / 10;

     


    dispatch({ type: GET_MY_VOLUME_DATA, payload: filterdCollection });
  }
} 


export const getNewsData = () => {
  return(dispatch) => {
    let obj = [{'link':'https://www.cargill.com/2019/cargill-launches-independent-forest-protection-advisory-panel', 'name':'Cargill launches independent forest protection advisory panel'},
                {'link':'https://www.cargill.com/2019/palm-oil-industry-to-jointly-develop-radar-monitoring-technology', 'name':'Palm Oil Industry to Jointly Develop Radar Monitoring Technology to Detect Deforestation'},
                {'link': 'https://www.cargill.com/2019/cargill-supports-indonesian-smallholder-farmers-with-global', 'name':'Cargill supports Indonesian smallholder farmers with global sustainable palm oil certification'}]
    dispatch({ type: GET_NEWS, payload: obj });
  }
} 

export const getDownloadData = () => {
  return(dispatch) => {
    let obj = [{'link':'https://www.cargill.com/doc/1432155778288/cargill-palm-mill-list-q3-2019.pdf', 'name':'Cargill’s Mill List'},
                {'link':'https://www.cargill.com/doc/1432076149492/palm-oil-policy-statement-pdf.pdf', 'name':'Cargill’s Policy on Sustainable Palm Oil'},
                {'link': 'https://www.cargill.com/doc/1432144706116/cargill-2018-palm-report.pdf', 'name':'Cargill Palm Oil Annual Report'}]
    dispatch({ type: GET_DOWNLOADS, payload: obj });
  }
} 

export const getGrievancesLocation = () => {
  return(dispatch) => {
    
    var arr = [{"COUNTRY": "Indonesia","GRIEVANCES":43,"TOTAL_GRIEVANCES":60},
    {"COUNTRY": "Malaysia","GRIEVANCES":10,"TOTAL_GRIEVANCES":60},
    {"COUNTRY": "Papua New Guinea","GRIEVANCES":2,"TOTAL_GRIEVANCES":60},
    {"COUNTRY": "Other Countries","GRIEVANCES":5,"TOTAL_GRIEVANCES":60}]
    dispatch({ type: GET_GRIEVANCES_LOCATION, payload: arr });
  }
} 

export const getRiskPerMill = () => {
  return(dispatch) => {
    
    var obj = {"total_low_risk_mill": 58, "total_medium_risk_mill":104 ,"total_high_risk_mill":125}
    dispatch({ type: GET_RISK_PER_MILL, payload: obj });
  }
} 

export const getSupplyChainWidgetData = () => {
  return(dispatch) => {
    millData =[
      {     
        "product_group": "Kernel",
        "product_certification": "Classic",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 12,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "MB",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 25,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Palm",
        "product_certification": "Classic",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 262,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "SG",
        "destination_market": "EUROPE",
        "cargill_owned": "No",
        "mill_count": 3,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Kernel",
        "product_certification": "Classic",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 257,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      },
      {
        "product_group": "Palm",
        "product_certification": "MB",
        "destination_market": "BRAZIL",
        "cargill_owned": "No",
        "mill_count": 143,
        "quarter": "Q2",
        "year": 2019,
        "total_3rd_party_mill_count": 297
      }
     ]

    dispatch({ type: GET_SUPPLY_CHAIN_WIDGET, payload: millData[0].total_3rd_party_mill_count})
  }
}

export const getByCountryVolumes = () => {
  return(dispatch) => {
    volumes = [
      {
        "volume_percent": "32.87165677160884",
        "load_country": "Indonesia"
      },
      {
        "volume_percent": "30.75625195136698",
        "load_country": "Colombia"
      },
      {
        "volume_percent": "15.43301957509228",
        "load_country": "Guatemala"
      },
      {
        "volume_percent": "20.93907170193191",
        "load_country": "Others"
      }
     ]
    
    dispatch({ type: GET_COUNTRY_VOLUME, payload: volumes });
  }
} 

export const getGrievancesSupplierInfo = () => {
  return(dispatch) => {

    let linkWithSuppliers = {
      "directParties" : 13,
      "indirectParties" : 47,
      }
    
    dispatch({ type: GET_GRIEVANCES_SUPPLIER_INFO, payload: linkWithSuppliers});
  }
} 

export const getGrievancesStatus = () => {
  return(dispatch) => {
    
    let grievanceStatus =  {
      "humanRights" : 
          [ 200,200,260,300,80,100],
      "developmentOnPeat" : 
          [ 400,290,170,480,250,300],
      "deforestation" : 
          [ 600,200,100,80,450,300]
  }
    
    dispatch({ type: GET_GRIEVANCES_STATUS, payload: grievanceStatus});
  }
} 

export const getGrievancesList = () => {
  return(dispatch) => {
    let lst = [
      {
          "id" : 1,
          "name" : "Deforestation",
          "subHeading": "Issue Under Review",
          "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
          "entity" : "Asian Plantation Limited(Indirect party)",
          "raiser" : "Aid Environment",
          "status" : "Verification",
          "date" : "Jan 22,2020",
          "country" : "Indonasia",
          "source" : "Not available for this grievance",
          "lastUpdated" : "3 days ago"
      },
      {
          "id" : 2,
          "name" : "Development on peat",
          "subHeading": "Issue Under Review",
          "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
          "entity" : "Asian Plantation Limited(Grand performance)",
          "raiser" : "Aid Environment",
          "status" : "Implementation of action plan",
          "date" : "Dec 12,2019",
          "country" : "Malaysia",
          "source" : "Not available for this grievance",
          "lastUpdated" : "3 days ago"
      },
      {
          "id" : 3,
          "name" : "Human rights",
          "subHeading": "Issue Under Review",
          "description": "Public accusation of deforestation of HCS forest in Asian Plantations Limited's Grand Performance concession",
          "entity" : "Asian Plantation Limited(Grand performance)",
          "raiser" : "Aid Environment",
          "status" : "Closed",
          "date" : "Jan 18,2020",
          "country": "Indonasia",
          "source" : "Not available for this grievance",
          "lastUpdated" : "3 days ago"
      }
  ]
  dispatch({ type: GET_GRIEVANCES_LIST, payload: lst});
  }
}

export const navigateSelections = (selection) => {
  return(dispatch) => {
    dispatch({type:NAV_TAB, payload:selection});
  }
}



