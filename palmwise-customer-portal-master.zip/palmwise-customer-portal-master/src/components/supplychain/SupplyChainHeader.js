import React from 'react';
import { Form, Card } from 'react-bootstrap';

function SupplyChainHeader() {
  
  return <Card style={{ width: '100%' }}>
          <Card.Body>
            <h1><strong>My Supply Chain</strong></h1>
            <Form.Text className="text-muted">
            This dashboard represent your selection from filtering.
            </Form.Text>
            </Card.Body></Card>
}
export default SupplyChainHeader;