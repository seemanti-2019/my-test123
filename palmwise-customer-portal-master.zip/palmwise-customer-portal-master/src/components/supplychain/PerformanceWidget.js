import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, CardDeck, Card,Form, Button } from 'react-bootstrap';
import { getRiskPerMill } from '../../actions/index'
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';


class PerformanceWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getRiskPerMill();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
       // this.props.changeName();
  }
  


  render() {
    
    return (
        <Card sm={12}>
            <Card.Body>
                <Card.Title style={{whiteSpace:'pre'}}>Sustainability Performance   2019-Q2</Card.Title>
                <Row sm={12} style={{padding:'1em 0 1em 0'}}>
                    <Col sm={6}>
                        <p><strong>Risk per mill</strong></p>
                        <p>Global Forest Watch classifies mills in <a href="https://www.wri.org/publication/palmriskmethodology" target="blank">risk categories</a>  that Cargill uses as priority for engagement.</p>
                        <Row sm={12}>
                            <Col sm={2}></Col>
                            <Col sm={3}>
    <div style={{width:'10em', height: '10em', borderRadius: '50%', fontSize: '14px',color: '#fff', textAlign: 'center',background: '#A22B2F', lineHeight:'10em'}}><strong>{this.props.supplychain.total_high_risk_mill}</strong></div>
                            </Col>
                            <Col sm={4}>
                                <hr style={{marginTop:'3.3em'}}></hr>
                            </Col>
                            <Col sm={3}>
                                <div style={{display:'table-cell', height:'100px',verticalAlign:'middle'}}>High</div>
                            </Col>
                        </Row>
                        <Row sm={12}>
                            <Col sm={3}></Col>
                            <Col sm={3}>
                                <div style={{width:'8em', height: '8em', borderRadius: '50%', fontSize: '14px',color: '#fff', textAlign: 'center',background: '#DDAA01', lineHeight:'8em'}}><strong>{this.props.supplychain.total_medium_risk_mill}</strong></div>
                            </Col>
                            <Col sm={3}>
                                <hr style={{marginTop:'2.8em'}}></hr>
                            </Col>
                            <Col sm={3}>
                                <div style={{display:'table-cell', height:'90px',verticalAlign:'middle'}}>Medium</div>
                            </Col>
                        </Row>
                        <Row sm={12}>
                            <Col sm={2}></Col>
                            <Col sm={3}>
                                <div style={{width:'6em', height: '6em', borderRadius: '50%', fontSize: '14px',color: '#fff', textAlign: 'center',background: '#628C1C', lineHeight:'6em'}}><strong>{this.props.supplychain.total_low_risk_mill}</strong></div>
                            </Col>
                            <Col sm={4}>
                                <hr style={{marginTop:'2.4em'}}></hr>
                            </Col>
                            <Col sm={3}>
                                <p style={{display:'table-cell', height:'75px',verticalAlign:'middle'}}>Low</p>
                            </Col>
                        </Row>
                    </Col>
                    <Col sm={6}>
                        <p><strong>Volume covered by NDPE policy</strong></p>
                        <p>We require our suppliers to have a policy on No Deforestation, No Peat, No Exploitation of people.</p>
                        <Col sm={8}  style={{ width: "18em", padding:'1em' }}>
                        <CircularProgressbarWithChildren value={93} styles={buildStyles({ pathTransition: "none", strokeLinecap: "butt",
                            pathColor: "#638C1C", })}>
                                {/* Put any JSX content in here that you'd like. It'll be vertically and horizonally centered. */}
                                <div style={{ fontSize: 18, margin: 0 }}>
                                <strong>{`${93}%`}</strong>
                                <div style={{ fontSize: 14, }}>to mills</div>
                                </div>
                            </CircularProgressbarWithChildren>
                        </Col>
                    </Col>
                </Row>
                
            </Card.Body>
            
        </Card>
      
    );
  }
}


const mapStateToProps = state => {
  return {
    supplychain: state.supplychain.risk,
  };
}

export default connect(mapStateToProps, { getRiskPerMill })(PerformanceWidget);
