import React, { Component } from 'react'
import { IconContext } from 'react-icons';
import {FaSearch} from 'react-icons/fa'
import { InputGroup, FormControl} from 'react-bootstrap';



export default class SearchExampleStandard extends Component {

  constructor(props){
    super(props)
    this.state = {
      initialItems:[],
      items:[],
      isLoading: false
    }
  }

  componentWillMount = () =>{
    this.setState({
      initialItems: this.props.content,
      items: this.props.content,
    })
  }

 filterList = (event) => {
   if(this.state.initialItems){
    let items = this.state.initialItems;
    items = items.filter((item) => {
      return item.title.toLowerCase().search(event.target.value.toLowerCase()) !== -1;
    });
    if(items.length === 0 || event.target.value.toLowerCase() === ''){
      this.setState({isLoading:false});
    }else{
      this.setState({isLoading:true});
    }
    
    this.setState({items:items});

  }
 }

 clickedItem = (item) => {
   this.props.handleSelection(item)
 }

renderResults(){
   return this.state.items.map((item, index) => { 
      return <li key={index} className="search-item" onClick={() => this.clickedItem(item)}>{item.title}</li>
    })
  }

  render() {
    return (
      <div>
        <InputGroup className="mb-3" style={{position: "relative"}}>
          <InputGroup.Prepend>
            <div style={{width:'40px', height:'38px', backgroundColor:'black', padding:'6px'}}>
            <IconContext.Provider value={{ color: "white", size:'25px', marginTop:'10px' }}>
              <div>
                <FaSearch />
              </div>
            </IconContext.Provider></div>
          </InputGroup.Prepend>
          <FormControl aria-describedby="basic-addon1" placeholder="Supplier checker" onChange={this.filterList}/>
        </InputGroup>
        {(this.state.items && this.state.items.map && this.state.isLoading) ? <div className="suggestive-search"><ul className="search-container">{this.renderResults()}</ul></div> : ""}
        
      </div>
    )
  }
}