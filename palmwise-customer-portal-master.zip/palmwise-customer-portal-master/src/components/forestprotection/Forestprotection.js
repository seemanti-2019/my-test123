import React from 'react';
import { connect } from 'react-redux';
import { changeName } from '../../actions/index';


class CoInvest extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
      //  this.props.changeName();
  }
  


  render() {
    
    return (
        <div style={{padding:'3em'}}>
          Forest Protection Page is under construction
        </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(CoInvest);
