import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Dropdown, ProgressBar, CardDeck } from 'react-bootstrap';
import history from '../header/history'
import { getGrievancesList } from '../../actions/index';
import GrievanceTile from './GrievancesTile';
import { FaSortAmountDown, FaSortAmountUp } from 'react-icons/fa';
import FilterHeader from '../filters/FilterWidget';

class GrievancesOverview extends React.PureComponent {

  constructor(props) {
    super(props);
    this.textInput = React.createRef();
    this.state = {
        listToShow: null,
        filterName: null,
        venture: null,
        status: 'Status',
        country: 'Country',
        date: 'desc',
        grievanceList: props.grievanceList.sort((a, b) => (a.date < b.date) ? 1 : ((b.date < a.date) ? -1 : 0))
    }
}
exportCSV = () => {
    let blob = new Blob(['lorem ipsum'], { type: 'application/octet-stream' })
    let ref = this.textInput;
    ref.current.href = URL.createObjectURL(blob);
    ref.current.download = 'data.csv';
    ref.current.click();
}
handleClick = (id) => {
    this.props.history.push(`/grievance-details/${id}`);
}
filterStatus = (status) => {
    this.setState({status});
    const listToShow = [...this.props.grievanceList];
    this.setState({
        listToShow: listToShow.filter(item => item.status === status)
    });
}
filterCountry = (country) => {
    this.setState({country});
    const listToShow = [...this.props.grievanceList];
    this.setState({
        listToShow: listToShow.filter(item => item.country === country)
    });
}
applyFilter = () => {
    if (this.state.listToShow) {
        this.setState({
            grievanceList: this.state.listToShow
        })
    }
}

sortDatewise = (order) => {
    this.setState({ date: order });
    const listToShow = [...this.state.grievanceList];
    switch (order) {
        case 'asc': {
            this.setState({
                grievanceList: listToShow.sort((a, b) => (a.date > b.date) ? 1 : ((b.date > a.date) ? -1 : 0))
            });
            break;
        }
        case 'desc': {
            this.setState({
                grievanceList: listToShow.sort((a, b) => (a.date < b.date) ? 1 : ((b.date < a.date) ? -1 : 0))
            });
            break;
        }
        default:
            break;
    }
}
  componentDidMount() {
    this.props.getGrievancesList();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      history.push('/');
  }

  test2 = () => {
    history.push('/grievances');
}

  render() {
    const ventureItems = [
      { label: 'Lorem Ipsum', value: 'LI1' },
      { label: 'Lorem Ipsum', value: 'LI2' },
      { label: 'Lorem Ipsum', value: 'LI3' }
    ];

    const statusItems = [
        { label: 'Investigation', value: 'Investigation' },
        { label: 'Verification', value: 'Verification' },
        { label: 'Implementation of action plan', value: 'Implementation of action plan' },
        { label: 'Monitoring Implementation', value: 'Monitoring Implementation' },
        { label: 'Closed', value: 'Closed' }
    ];

    const countryItems = [
        { label: 'Indonasia', value: 'Indonasia' },
        { label: 'Malaysia', value: 'Malaysia' }
    ];

    return (
        <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
          <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
             <FilterHeader></FilterHeader>
          </CardDeck>
          <Row style={{paddingTop:'1em', paddingLeft:'2em'}}>
            <Col>
                <Row>
                <Button variant="link" style={{color: '#A5A5A5', fontSize: '18px', fontWeight: '600'}} onClick={(e)=> this.test1()}>Home</Button>
                <div style={{borderLeft: '3px solid lightgray', height: '30px', marginTop:'5px'}}></div>
                <Button variant="link" style={{color: '#A5A5A5', fontSize: '18px', fontWeight: '600'}} onClick={(e)=> this.test2()}>My grievances</Button>
                <div style={{borderLeft: '3px solid lightgray', height: '30px', marginTop:'5px'}}></div>
                <Button variant="link" style={{color: '#000', fontSize: '18px', fontWeight: '600'}} >Grievances Overview</Button></Row>
            </Col>
          </Row>

          <CardDeck style={{padding:'1.5em'}}>
            <Card style={{ width: '100%', padding:'1em'}}>
              <Card.Body>
                  <h1><strong>Grievances Overview.</strong></h1>
                  <Row style={{marginTop: "2rem"}}>
                    <Col md={3}>
                        <Dropdown>
                            <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%",textAlign: "left" }}>
                                Felda Global Ventures
                            </Dropdown.Toggle>
                            <Dropdown.Menu style={{ width: "100%"}}>
                                {
                                    ventureItems.map(data =>
                                        <Dropdown.Item eventKey={data.value} key={data.value}>{data.label}</Dropdown.Item>
                                    )
                                }
                            </Dropdown.Menu>
                        </Dropdown>
                    </Col>
                    <Col md={3}>
                        <Dropdown onSelect={(e) => this.filterStatus(e)}>
                            <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: '100%',textAlign: "left" }}>
                                {this.state.status}
                            </Dropdown.Toggle>
                            <Dropdown.Menu style={{ width: "100%"}}>
                                {
                                    statusItems.map(data =>
                                        <Dropdown.Item eventKey={data.value} key={data.value}>{data.label}</Dropdown.Item>
                                    )
                                }
                            </Dropdown.Menu>
                        </Dropdown>
                    </Col>
                    <Col md={3}>
                        <Dropdown onSelect={(e) => this.filterCountry(e)}>
                            <Dropdown.Toggle variant="light" id="dropdown-basic" style={{ border: "1px solid black", width: "100%",textAlign: "left" }}>
                                {this.state.country}
                            </Dropdown.Toggle>
                            <Dropdown.Menu style={{ width: "100%"}}>
                                {
                                    countryItems.map(data =>
                                        <Dropdown.Item eventKey={data.value} key={data.value}>{data.label}</Dropdown.Item>
                                    )
                                }
                            </Dropdown.Menu>
                        </Dropdown>
                    </Col>
                    <Col md={3}>                                    
                        <Button variant="dark"  onClick={()=> this.applyFilter()}>Apply Filter</Button>
                    </Col>
                  </Row>
                </Card.Body>
              </Card>
          </CardDeck>

          
            <Row style={{ paddingTop: "1rem", paddingLeft: '2em', paddingRight:'2em' }}>
                      <Col md={2}>
                          {this.state.grievanceList.length}  results
                      </Col>
                      <Col md={10} style={{ textAlign: "right" }}>
                          {
                          (this.state.date === 'desc') ?
                              (
                                  <Button variant="outline-dark" onClick={() => this.sortDatewise('asc')}>
                                      <FaSortAmountDown />
                                  </Button>
                              ) : (
                                  <Button variant="outline-dark" onClick={() => this.sortDatewise('desc')}>
                                      <FaSortAmountUp />
                                  </Button>
                              )
                          }
                      </Col>
                  </Row>
                {
                    this.state.grievanceList.map(grievance => {
                        return (
                          <CardDeck style={{paddingLeft:'1.5em', padding:'1.5em'}}>
                            <GrievanceTile 
                                grievance={grievance}
                                key={grievance.id}
                                exportCSV={this.exportCSV}
                                textInput={this.textInput}
                                handleClick={this.handleClick}
                            />
                            </CardDeck>
                        );
                    })
                }
          
        </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievanceList: state.grievances.list,
  };
}

export default connect(mapStateToProps, { getGrievancesList })(GrievancesOverview);
