import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Dropdown, ProgressBar, CardDeck } from 'react-bootstrap';
import history from '../header/history'
import { changeName } from '../../actions/index';

class GrievancesHeader extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
            history.push('/grievancesoverview');
      //  this.props.changeName();
  }
  


  render() {
    
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <h1><strong>Grievances </strong></h1>
            <Form.Text className="text-muted">
            Grievances are complaints or concerns associated with Cargill's palm policy. Cargill carefully tracks and manages these grievances.
            </Form.Text>
            <div style={{padding:'10px 0px 15px 0px'}}>There are 60 grievances in your supply chain</div>
            <Button onClick={(e)=> this.test1()} variant="outline-dark"> Show Grievances </Button>
            </Card.Body></Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(GrievancesHeader);
