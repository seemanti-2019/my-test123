import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Dropdown, ProgressBar, CardDeck } from 'react-bootstrap';
import history from '../header/history'
import { changeName } from '../../actions/index';
import Header from '../grievances/GrievancesHeader';
import FilterHeader from '../filters/FilterWidget';
import LocationWidget from '../grievances/LocationWidget';
import SupplierWidget from '../grievances/SupplierWidget';
import StatusWidget from '../grievances/GrievancesStatusWidget';

class GrievancesWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
      history.push('/');
      //  this.props.changeName();
  }
  


  render() {
    
    return (
        <div style={{ padding:'1em', backgroundColor:'#F5F5F5'}}>
        <CardDeck style={{paddingTop:'1em', paddingLeft:'1.4em', paddingRight:'1.3em'}}>
          <FilterHeader></FilterHeader>
        </CardDeck>
        <Row style={{paddingTop:'1em', paddingLeft:'2em'}}>
          <Col>
            <Row>
            <Button variant="link" style={{color: '#A5A5A5', fontSize: '18px', fontWeight: '600'}} onClick={(e)=> this.test1()}>Home</Button>
            <div style={{borderLeft: '3px solid lightgray', height: '30px', marginTop:'5px'}}></div>
            <Button variant="link" style={{color: '#000', fontSize: '18px', fontWeight: '600'}}>My grievances</Button></Row>
          </Col>
          </Row>
          <CardDeck style={{padding:'1.5em'}}>
            <Header/>
          </CardDeck>
          <CardDeck style={{padding:'1.5em'}}>
            <LocationWidget />
            <SupplierWidget />
          </CardDeck>
          <CardDeck style={{padding:'1.5em'}}>
            <StatusWidget />
          </CardDeck>
        
        </div>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(GrievancesWidget);
