import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history'
import { Col, Card, Form } from 'react-bootstrap';
import { getGrievancesStatus } from '../../actions/index';
import C3Chart from 'react-c3js';
import 'c3/c3.css';

class GrievancesStatusWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getGrievancesStatus();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

 
  


  render() {
    this.myGrievance = this.props.grievances;
    this.myGrievance.humanRights.unshift('data2');
    this.myGrievance.developmentOnPeat.unshift('data1');
    this.myGrievance.deforestation.unshift('data3');

    const dataColumn = {
        columns: [
            this.myGrievance.developmentOnPeat,
            this.myGrievance.deforestation,
            this.myGrievance.humanRights,
        ],
        names: {
            data1: 'Human rights',
            data3: 'Development on peat',
            data2: 'Deforestation'
        },
        type: 'bar',
        groups: [
            ['data1', 'data3', 'data2']
        ],
        colors: {
            'data1': '#148280',
            'data3': '#ffa500',
            'data2': '#54822e'
        },
        
    };
    
    const gridColumn = {
        y: {
            lines: [{ value: 0 }]
        },
        
    };

    const legendColumn = {
        position: 'inset',
        inset: {
            anchor: 'top-left',
            x: 20,
            y: 10,
            step: 1
        },            
        item: {
            onclick: function () { }
        }            
    }

    const axis = {
        x: {
            tick: {
                centered: true
            },              
            label: {
                position: 'outer-center'
            },
            type: 'categories',
            categories: ['Investigation', 'Verification', 'Developing action plan', 'Monitor implementation', 'Suspended', 'Closed'],
        },
        y: {
            show: false
        }
    }
    const bar = {
        width: 20
    }
    const tooltipColumn = {
        show: true,
        contents: function () {
          return '<div><div style="text-align:center">Status Investigation</div><div>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</div></div>'
        }
      }
    const sizeColumn = {
        height: 500
    };
    
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Status of my grievances</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'12px'}}>
          We hold ourselves and our suppliers accountable to respond to grievances, set time-bound action plans to ensure progress and close the grievances in a timely manner as agreed to by the complainant. Cargill's Palm Grievances Procedure provides a transparent, open and robust process for dealing with grievances.
          </Form.Text>

          <Col sm={12} style={{padding:'1em'}} >
          <C3Chart data={dataColumn} grid={gridColumn} legend={legendColumn} axis={axis} bar={bar} size={sizeColumn} tooltip={tooltipColumn} />
          </Col>

        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    grievances: state.grievances.status,
  };
}

export default connect(mapStateToProps, { getGrievancesStatus })(GrievancesStatusWidget);
