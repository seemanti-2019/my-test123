import React from 'react';
import { connect } from 'react-redux';
import history from '../header/history'
import { Button, Row, Col, Card, Form } from 'react-bootstrap';
import { changeName } from '../../actions/index';

class GrievancesWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

  navToGreviences = () => {
    history.push('/grievances');
}
  


  render() {
    
    return (
        <Card style={{ width: '100%' }}>
        <Card.Body>
          <Card.Title>Grievances</Card.Title>
          <Form.Text className="text-muted" style={{paddingBottom:'12px'}}>
          Grievances are complaints or concerns associated with Cargill's palm policy. Cargill carefully tracks and manages these grievances.
          </Form.Text>
          <Row sm={12}>
            <Col style={{textAlign: 'center', cursor:'pointer'}} onClick={this.navToGreviences}><span style={{color:'#DDAA01', fontSize: '40px', paddingRight:'2em'}}>1</span> <span style={{color:'#DDAA01'}}>New</span></Col>
            
          </Row>
          <hr/>
          <Row sm={12}>
            <Col style={{textAlign: 'center', cursor:'pointer'}} onClick={this.navToGreviences}><span style={{fontSize: '40px', paddingRight:'1.6em'}}>10</span> <span style={{}}>Active</span></Col>
            
          </Row>
          <hr/>
          <Row sm={12} style={{paddingBottom:'1em'}}>
            <Col style={{textAlign: 'center', cursor:'pointer'}} onClick={this.navToGreviences} ><span style={{fontSize: '40px', paddingRight:'2em',paddingLeft:'0.4em'}}>3</span> <span style={{}}>Update</span></Col>
          </Row>
          
          <Button variant="outline-secondary" style={{marginLeft:'8.5em'}} onClick={this.navToGreviences}>Show all grievances</Button>
        </Card.Body>
        </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    name: state.home.name,
  };
}

export default connect(mapStateToProps, { changeName })(GrievancesWidget);
