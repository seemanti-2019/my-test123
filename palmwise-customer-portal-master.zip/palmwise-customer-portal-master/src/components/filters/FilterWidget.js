import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Dropdown, DropdownButton } from 'react-bootstrap';
import { getFiltersOptions, updateUserOptions, clearUserOptions, applyUserSelections, editFilters } from '../../actions/index';

class FilterWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getFiltersOptions();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
        this.props.changeName();
  }

  clearSelction = () => {
    this.props.clearUserOptions(this.props.options);
}

applyUserFilters = () => {
  this.props.applyUserSelections(this.props.options);
}

editFilters =() => {
  this.props.editFilters(this.props.options);
}

  handleCheck=(key,event) => {
   
      this.props.updateUserOptions(this.props.options, event.currentTarget.name, event.currentTarget.checked, key )
  }


  renderProductGroup(){
    return  this.props.options.product_group.map((item, i) => {
        return (
            <Row key={i} style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
              <input class="custCheck" type="checkbox" name={item.name} checked={item.checked} onChange={(e) => this.handleCheck("product_group", e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
              <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            </Row>
        )
    })
  }

  renderSelectedProductGroup(){
    return this.props.options.product_group.map((item, i) => {
      if(item.checked === true){
      return (
        <p>{item.name}</p>
      )}
  })
}

  renderRSPO(){
    return  this.props.options.rspo.map((item, i) => {
        return (
            <Row key={i} style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
              <input class="custCheck" type="checkbox" name={item.name} checked={item.checked} onChange={(e) => this.handleCheck("rspo", e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
              <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            </Row>
        )
    })
  }

  renderSelectedRSPO(){
    return  this.props.options.rspo.map((item, i) => {
      if(item.checked === true){
      return (
          <p>{item.name}</p>
      )}
  })
  }

  renderYearQuater(){
    return  this.props.options.year_quater.map((item, i) => {
        return (
            <Dropdown.Item key={i}>{item}</Dropdown.Item>
        )
    })
  }

  renderSelectedYearQuater(){
    return  this.props.options.year_quater.map((item, i) => {
      return (
      <p>{item}</p>
      )
  })
  }

  renderDestination(){
    return  this.props.options.destination.map((item, i) => {
        return (
            <Row style={{paddingLeft:'0.8em', paddingTop:'0.5em'}}>
              <input class="custCheck" type="checkbox" name={item.name} checked={item.checked} onChange={(e) => this.handleCheck("destination", e)} style={{marginTop:'0.2em',paddingRight:'1em'}}></input>
              <label style={{paddingLeft:'0.2em'}}>{item.name}</label>
            </Row>
        )
    })
  }

  renderSelectedDestination(){
    return  this.props.options.destination.map((item, i) => {
      if(item.checked === true){
      return (
          
            <p>{item.name}</p>
          
      )}
  })
  }
  
  renderFilterLayer(){
    if (this.props.widgetStatus === true){
      return(
        <div>  
        <Row style={{margin:'0px'}}>
            <Col sm={2} style={{padding:'0px',margin:'0px',borderTopLeftRadius: '10px', height:'110px',backgroundColor:'#638C1C'}}>
                    <p style={{color:'#fff', padding:'0.8em'}}><strong>Cargill Supply Chain</strong></p>
            </Col>
            <Col sm={10} >
                <Row>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Product Group</strong>
                    {this.renderProductGroup()}
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>RSPO Certification</strong>
                    {this.renderRSPO()}
                </Col>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Year Quater</strong>
                    <DropdownButton
                        variant="outline-secondary"
                        size="sm"
                        title="In 2019-Q2"
                        id="input-group-dropdown-2"
                        style={{paddingTop:'0.5em'}}
                        >
                        {this.renderYearQuater()}
                    </DropdownButton>
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Destination Market</strong>
                    {this.renderDestination()}
                </Col>
                </Row>
            </Col>                                   
        </Row>
        <Row style={{paddingBottom:'1em'}}>
            <Col sm={8}></Col>
            <Col sm={2}>  
                <Button variant="dark" style={{width:'135px'}} onClick={this.clearSelction}>Clear</Button>
            </Col>
            <Col sm={2}>
                <Button variant="dark" style={{width:'135px'}} onClick={this.applyUserFilters}>Apply Filters</Button>
            </Col>
        </Row>
        </div>

      )
    }else{
        return(
          <div>
            <Row>
              <Col sm={2}>
                    <p style={{ padding:'0.8em'}}><strong>Cargill Supply Chain</strong></p>
            </Col>
            <Col sm={10} >
                <Row>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Product Group</strong>
                    {this.renderSelectedProductGroup()}
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>RSPO Certification</strong>
                    {this.renderSelectedRSPO()}
                </Col>
                <Col sm={2} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Year Quater</strong>
                   
                        {this.renderSelectedYearQuater()}
  
                </Col>
                <Col sm={3} style={{paddingTop:'0.8em', paddingLeft:'1em'}}>
                    <strong>Destination Market</strong>
                    {this.renderSelectedDestination()}
                </Col>
                </Row>
            </Col>              
            </Row>
            <Row style={{paddingBottom:'1em'}}>
              <Col sm={10}></Col>
              <Col sm={2}>  
                  <Button variant="dark" style={{width:'135px'}} onClick={this.editFilters}>Edit Filters</Button>
              </Col>
            </Row>
          </div>
        )
    }
  }


  render() {
    
    return (
            
                    <Card style={{ width: '100%', borderRadius: '10px' }}>
                        <Card.Body style={{padding:'0px'}}>
                             {this.renderFilterLayer()}
                        </Card.Body>
                    </Card>
                
            
        
    );
  }
}


const mapStateToProps = state => {
  return {
    options: state.filters.options,
    widgetStatus: state.filters.filterWidget,
  };
}

export default connect(mapStateToProps, { getFiltersOptions, updateUserOptions, clearUserOptions, applyUserSelections, editFilters })(FilterWidget);
