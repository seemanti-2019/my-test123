import React from 'react';
import { connect } from 'react-redux';
import {Router, Switch, Route, Link } from 'react-router-dom';
import history from './history'
import { Navbar, Nav, Image, Col, Row} from 'react-bootstrap';
import Home from '../home/Home';
import SupplyChain from '../supplychain/Supplychain';
import Grievances from '../grievances/Grievances';
import OverView from '../grievances/GrievancesOverview';
import CoInvest  from '../coinvest/CoInvest';
import ForestProtection from '../forestprotection/Forestprotection';
import GrievanceDetails from '../grievances/GrienvanceDetails';
import { navigateSelections } from '../../actions/index';
  

class RootNavigator extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      home: 'hrActive',
      sply:'hrInactive',
      grivn:'hrInactive',
      coIn:'hrInactive',
          fp:'hrInactive',
    }

  }

    componentDidMount(){
      debugger
      //this.props.navigateSelections();
      this.setState({
        home: 'hrActive',
      sply:'hrInactive',
      grivn:'hrInactive',
      coIn:'hrInactive',
          fp:'hrInactive',
      })
    }

    handleIncrement = event =>{
      //alert(event.target.pathname)
      if(event.target.pathname === '/supplychain'){
        this.setState({
          home: 'hrInactive',
          sply:'hrActive',
          grivn:'hrInactive',
          coIn:'hrInactive',
          fp:'hrInactive',
        })
      }
      else if(event.target.pathname === '/grievances'){
        this.setState({
          home: 'hrInactive',
          sply:'hrInactive',
          grivn:'hrActive',
          coIn:'hrInactive',
          fp:'hrInactive',
        })
      }else if(event.target.pathname === '/coinvest'){
        this.setState({
          home: 'hrInactive',
          sply:'hrInactive',
          grivn:'hrInactive',
          coIn:'hrActive',
          fp:'hrInactive'
        })
      }else if(event.target.pathname === '/forestprotection'){
        this.setState({
          home: 'hrInactive',
          sply:'hrInactive',
          grivn:'hrInactive',
          coIn:'hrInactive',
          fp:'hrActive',
        })
      }else{
        this.setState({
          home: 'hrActive',
          sply:'hrInactive',
          grivn:'hrInactive',
          coIn:'hrInactive',
          fp:'hrInactive',
        })
      }
    }

    render() {
    return (
        <Router history={history}>
        <Navbar expand="lg" style={{backgroundColor: 'white !important'}}>
        <Navbar.Brand >
        < Image src={require("../../assets/Logo-2.png")} style={{marginLeft:'1.7em'}}/>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav" >
          <Nav className="ml-auto" >
            <Link className="custTag cust1" to="/" onClick={this.handleIncrement} >Home<hr className={this.state.home}></hr></Link>
            <Link className="custTag cust1" to="/supplychain" onClick={this.handleIncrement}>My Supply Chain<hr className={this.state.sply}></hr></Link>
            <Link className="custTag cust1" to="/grievances" onClick={this.handleIncrement}>My Grievances<hr className={this.state.grivn}></hr></Link>
            <Link className="custTag cust1" to="/forestprotection" onClick={this.handleIncrement}>Forest Protection<hr className={this.state.fp}></hr></Link>
            <Link className="custTag cust1" href="#">Human Rights</Link>
            <Link className="custTag cust1" to="/coinvest" onClick={this.handleIncrement}>Co-Invest<hr className={this.state.coIn}></hr></Link>
          </Nav>
        </Navbar.Collapse>
        </Navbar>
        <Switch>
            <Route exact path="/" component={Home}/>
            <Route path="/supplychain" component={SupplyChain}/> 
            <Route path="/grievances" component={Grievances}/>
            <Route path="/grievancesoverview" component={OverView}/>
            <Route path="/coinvest" component={CoInvest}/>
            <Route path="/forestprotection" component={ForestProtection}/>
            <Route path="/grievance-details/:id" render={
            ({match})=> (
              <GrievanceDetails id={match.params.id} />
            )
          } />
        </Switch>
        </Router>
    );
  }
}
  

  const mapStateToProps = state => {
    return {
      selection: state.selection.navSelection,
    };
  }
  
  export default connect(mapStateToProps, { navigateSelections })(RootNavigator);