import React from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card } from 'react-bootstrap';
import { getDownloadData } from '../../actions/index';
import { FaDownload } from 'react-icons/fa';

class Footprint extends React.PureComponent {

constructor(props) {
    super(props);
    this.state = {
    isLoading: false,
    }

}

componentDidMount() {
    this.props.getDownloadData();
}

componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
}

test1 = () => {
    const element = document.createElement("a");
    const file = new Blob(['Hello Palm Peeps, I just got downloaded. How do you like this ?'], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "PalmWise.txt";
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
}


//onClick={(e)=>this.test1()}

render() {
    const downloads = [{title:'Lorem ipsum dolor sit amet', id:'0'},{title:'Lorem ipsum dolor sit amet', id:'1' },{title:'Lorem ipsum dolor sit amet', id:'2'},{title:'Lorem ipsum dolor sit amet', id:'3' },{title:'Lorem ipsum dolor sit amet', id:'4' },{title:'Lorem ipsum dolor sit amet', id:'4' }];
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <Card.Title>Downloads</Card.Title>
            <div style={{paddingTop:'10px'}}>
              {this.props.downloads.map((item, index) => (
                <div key={index} style={{paddingBottom:'6px'}}>
                <hr/>
                <Row sm={12}  style={{cursor: 'pointer'}}> 
              <Col sm={2}><FaDownload size={30}/></Col>  
                <Col sm={10}>
              <div><a style={{color:'black'}} href={item.link} target="blank">{item.name}</a></div>
                </Col>  
                
                </Row>
                
                </div>
              ))}
            </div>
            <br></br>
          </Card.Body>
          </Card>
    );
}
}


const mapStateToProps = state => {
return {
    downloads: state.home.downloads,
};
}

export default connect(mapStateToProps, { getDownloadData })(Footprint);
