import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Image, ProgressBar } from 'react-bootstrap';
import { changeName } from '../../actions/index';
import history from '../header/history';

class Infowidget extends React.PureComponent {

constructor(props) {
    super(props);
    this.state = {
    isLoading: false,
    }

}

componentDidMount() {
    
}

componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
}

    test1 = () => {
        history.push('/coinvest');
}



render() {
    
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <Card.Title style={{paddingBottom:'15px'}}>How is Cargill taking action</Card.Title>
            <div style={{padding:'1em'}}>
                <Image src={require("../../assets/image.jpg")} thumbnail />
            </div>
            <p style={{paddingTop:'10px'}}>Tackling deforestation through Landscape Approaches. Cargill and other key players in the industry take targeted action on the ground to combat deforestation through a new landscape initiative.</p>
            <p>Read more about our work and opportunities to <p style={{cursor:'pointer', color:'#1F65BA'}}  onClick={this.test1}>co-invest.</p></p>
          </Card.Body>
          </Card>
    );
}
}


const mapStateToProps = state => {
return {
    name: state.home.name,
};
}

export default connect(mapStateToProps, { changeName })(Infowidget);
