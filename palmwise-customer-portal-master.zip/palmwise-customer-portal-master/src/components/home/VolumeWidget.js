import React from 'react';
import { connect } from 'react-redux';
import { Image, Row, Col, Card, Form, DropdownButton, Dropdown, ProgressBar } from 'react-bootstrap';
import { getMyVolumeData } from '../../actions/index';
import { route } from 'next/dist/next-server/server/router';

class VolumeWidget extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getMyVolumeData();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

   test1 = () => {
      //alert('hell')
        this.props.changeName();
  }
  
  renderPalm(){
    return this.props.volumes.palm_coll.map((item, i) => {
      return (
        <div style={{paddingTop:'0.5em', paddingBottom:'0.5em'}}>
          <ProgressBar key={i} className="rotProgress" now={item.Volume_Percentage} />
        </div>
      )}
    )
  }

  renderKernal(){
    return this.props.volumes.kernal_coll.map((item, i) => {
      return (
        <div style={{paddingTop:'0.5em', paddingBottom:'0.5em'}}>
          <ProgressBar key={i}  now={item.Volume_Percentage} />
        </div>
      )}
  )
}



  render() {
    
    return (
        <Card style={{ width: '100%' }}>
          <Card.Body>
            <Card.Title>My Volumes</Card.Title>
            <Form.Text className="text-muted" style={{paddingBottom:'10px'}}>
            The proportion of volumes sold to you by Cargill by RSPO certification types.
            </Form.Text>
            
            <DropdownButton
              variant="outline-secondary"
              size="sm"
              title="In 2019-Q2"
              id="input-group-dropdown-2"
            >
              <Dropdown.Item>2019-Q2</Dropdown.Item>
            </DropdownButton>
           
            <Row style={{paddingTop:'0.1em'}}>
              <Col style={{textAlign:'center'}} sm={5}>
                <Image src={require("../../assets/Palm-2.png")}/>
              </Col>
              <Col sm={2}></Col>
              <Col style={{textAlign:'center'}} sm={5}>
              <Image src={require("../../assets/Palm-1.png")}/>
              </Col>
            </Row>
            <Row>
                <Col style={{textAlign:'center'}} sm={5}>
                  <p style={{fontSize:18, fontWeight:'bold'}}>Palm</p>
                  <p style={{fontSize:10}}>{this.props.volumes.palmMT} MT</p>
                  </Col>
                <Col sm={2}></Col>
                <Col style={{textAlign:'center'}} sm={5}>
                  <p style={{fontSize:18, fontWeight:'bold'}}>Kernel</p>
                  <p style={{fontSize:10}}>{this.props.volumes.kernalMT} MT</p>
                </Col>
              </Row>
            <Row>
              <Col sm={4} style={{textAlign:'center'}}>
                {this.renderPalm()}
              </Col>
              <Col sm={4} style={{textAlign:'center'}}>
                <div style={{marginTop:'-4px'}}>Classic</div>
                
                <div style={{marginTop:'13px'}}>RSPO MB</div>
             
                <div style={{marginTop:'15px'}}>RSPO SG</div>
              </Col>
              <Col sm={4} style={{textAlign:'center'}}>
                {this.renderKernal()}
              </Col>
            </Row>
            
          </Card.Body>
          </Card>
    );
  }
}


const mapStateToProps = state => {
  return {
    volumes: state.home.volumes,
  };
}

export default connect(mapStateToProps, { getMyVolumeData })(VolumeWidget);
