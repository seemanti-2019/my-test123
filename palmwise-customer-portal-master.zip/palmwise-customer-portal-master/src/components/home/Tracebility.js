import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Col, Card, Form, DropdownButton, Dropdown } from 'react-bootstrap';
import { changeName, getTracibilityData } from '../../actions/index';
import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
import history from '../header/history';
import 'react-circular-progressbar/dist/styles.css';
import { easeQuadInOut } from "d3-ease";
import ChangingProgressProvider from './ChangingProgressProvider';

class Tracebility extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    }

  }

  componentDidMount() {
    this.props.getTracibilityData();
  }

  componentWillReceiveProps(nextProps) {
    //if (this.props.user != nextProps.user )
  }

  navigateToSupplyChain = () => {
    history.push('/supplychain');
  }
  


  render() {
    
    return (
           
          <Card style={{ width: '100%' }}>
          <Card.Body>
            <Card.Title>My Tracebility</Card.Title>
            <Form.Text className="text-muted">
            The traceability scores to mill and plantation level based on volume calculation. Cargill aims to the plantation level in <a href="https://www.cargill.com/page/traceability" target="blank">high risk area.</a>
            </Form.Text>
            <br></br>
            <DropdownButton
              variant="outline-secondary"
              size="sm"
              title="In 2019-Q2"
              id="input-group-dropdown-2"
            >
              <Dropdown.Item>2019-Q2</Dropdown.Item>
            </DropdownButton>
            
            <Row style={{padding:'0.8em'}} >

            <Col sm={5}  style={{ width: "10em", padding:'1em' }}>
            <ChangingProgressProvider
                    valueStart={0}
                    valueEnd={this.props.tracibility.mills}
                    duration={1.4}
                    easingFunction={easeQuadInOut}
                    
                >
                    {value => {
                    const roundedValue = Math.round(value);
                    return (
                
                <CircularProgressbarWithChildren value={value} styles={buildStyles({ pathTransition: "none", strokeLinecap: "butt",
                pathColor: "#638C1C", })}>
                    {/* Put any JSX content in here that you'd like. It'll be vertically and horizonally centered. */}
                    <div style={{ fontSize: 18, margin: 0 }}>
                    <strong>{`${roundedValue}%`}</strong>
                    <div style={{ fontSize: 14, }}>to mills</div>
                    </div>
                </CircularProgressbarWithChildren>
                 )}}
                 </ChangingProgressProvider>
            </Col>
            <Col sm={1}></Col>
            <Col sm={5} class=" ml-auto" style={{ width: "10em", padding:'1em' }}>
            <ChangingProgressProvider
                    valueStart={0}
                    valueEnd={48}
                    duration={1.4}
                    easingFunction={easeQuadInOut}
                    
                >
                    {value => {
                    const roundedValue = Math.round(value);
                    return (
                
                <CircularProgressbarWithChildren value={value} styles={buildStyles({ pathTransition: "none", strokeLinecap: "butt",
                pathColor: "#DDAA01", })}>
                    {/* Put any JSX content in here that you'd like. It'll be vertically and horizonally centered. */}
                    <div style={{ fontSize: 18, margin:0 }}>
                    <div style={{marginLeft:'1em'}}>
                    <strong>{`${roundedValue}%`}</strong>
                    </div>
                    <div style={{ fontSize: 14, }}>to plantation</div>
                    </div>
                </CircularProgressbarWithChildren>
                 )}}
                 </ChangingProgressProvider>
            </Col>
            
            </Row>
            <br></br>
            <Button variant="outline-secondary" style={{marginLeft:'6.5em'}} onClick={(e)=> this.navigateToSupplyChain()}>Read more about traceability</Button>
            
          </Card.Body>
          </Card>
        
            
        
    );
  }
}


const mapStateToProps = state => {
  return {
    tracibility: state.home.tracibility,
  };
}

export default connect(mapStateToProps, { changeName, getTracibilityData })(Tracebility);
