import React, { useState, useEffect } from "react"
import { geoEqualEarth, geoPath } from "d3-geo"
import { feature } from "topojson-client"
import { Card  } from 'react-bootstrap';



const cities = [
  
  { name: "Jakarta",        coordinates: [106.8650,-6.1751],  population: 10539000 },
  { name: "Kuala Lampur",   coordinates: [103.143258,2.526644],  population: 10123000 },
  { name: "Jakarta",        coordinates: [114.261421,3.228878],  population: 10539000 },
  { name: "Sao Paulo",      coordinates: [-46.6333,-23.5505], population: 10365000 },
  { name: "Jakarta",        coordinates: [119.908394,-2.415668],  population: 10539000 },
  
  { name: "Buenos Aires",   coordinates: [-58.3816,-34.6037], population: 10122000 },
  { name: "germany",       coordinates: [12.076761,50.784889],  population: 10084000 },
  { name: "Shenzhen",       coordinates: [5.750543,52.289181],  population: 10084000 },
  { name: "Rio de Janeiro", coordinates: [-43.1729,-22.9068], population: 10727000 },
  { name: "Kinshasa",       coordinates: [142.806234,-6.334823],   population: 11587000 },
  { name: "Guatemala",        coordinates: [-90.2308,15.7835],  population: 10920000 },
  { name: "Paris",          coordinates: [2.3522,48.8566],    population: 10858000 },
  { name: "Cambodia",        coordinates: [106.192163,12.839990], population: 10750000 },
]

const projection = geoEqualEarth()
  .scale(160)
  .translate([ 800 / 2, 450 / 2 ])

const Footprint = () => {
  const [geographies, setGeographies] = useState([])

  useEffect(() => {
    fetch("/world-110m.json")
      .then(response => {
        if (response.status !== 200) {
          console.log(`There was a problem: ${response.status}`)
          return
        }
        response.json().then(worlddata => {
          setGeographies(feature(worlddata, worlddata.objects.countries).features)
        })
      })
  }, [])

  const handleCountryClick = countryIndex => {
   // setGeographies(feature(mapJson, mapJson.objects.countries).features)
    console.log("Clicked on country: ", geographies[countryIndex])
  }

  const handleMarkerClick = i => {
    console.log("Marker: ", cities[i])
  }

  return (
    <Card style={{ width: '100%', height: '450px' }}>
          <Card.Body>
            <Card.Title>My Footprint</Card.Title>
          
    <svg width={ '100%' } height={ 450 } viewBox="0 0 800 500">
      <g className="countries">
        {
          geographies.map((d,i) => (
            <path
              key={ `path-${ i }` }
              d={ geoPath().projection(projection)(d) }
              className="country"
              fill={ `rgba(38,50,56,${ 1 / geographies.length * i})` }
              stroke="#FFFFFF"
              strokeWidth={ 0.5 }
              onClick={ () => handleCountryClick(i) }
            />
          ))
        }
      </g>
      <g className="markers">
        {
          cities.map((city, i) => (
            <circle
              key={ `marker-${i}` }
              cx={ projection(city.coordinates)[0] }
              cy={ projection(city.coordinates)[1] }
              r={ city.population / 3000000 }
              fill="#E91E63"
              stroke="#FFFFFF"
              className="marker"
              onClick={ () => handleMarkerClick(i) }
            />
          ))
        }
      </g>
    </svg>
    </Card.Body>
          </Card>
  )
}

export default Footprint