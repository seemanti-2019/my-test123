import { GET_GRIEVANCES_LOCATION, GET_GRIEVANCES_SUPPLIER_INFO, GET_GRIEVANCES_STATUS, GET_GRIEVANCES_LIST } from '../actions/types';


const INITIAL_STATE = {
location: [],
pieChart:{"directParties":0,"indirectParties":0},
status:{"humanRights" : [], "developmentOnPeat" : [], "deforestation" : []},
list:[],
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
case GET_GRIEVANCES_LOCATION:
    return {...state, location: action.payload };
case GET_GRIEVANCES_SUPPLIER_INFO:
    return {...state, pieChart: action.payload };
case GET_GRIEVANCES_STATUS:
    return {...state, status: action.payload };
    case GET_GRIEVANCES_LIST:
        return {...state, list: action.payload };
default:
return state;

}
}