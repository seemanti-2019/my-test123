import { TEST, TRACIBILITY_DATA, GET_MY_VOLUME_DATA, GET_NEWS, GET_DOWNLOADS } from '../actions/types';


const INITIAL_STATE = {
name: 'Hello',
tracibility:{'mills':10, 'plantation':0},
volumes:{'palm_coll':[],'kernal_coll':[],'kernalMT':'','palmMT':''},
news:[],
downloads: [],
};

export default (state = INITIAL_STATE, action) => {

switch (action.type) {
case TEST:
 return {...state, name: action.payload };
 case TRACIBILITY_DATA:
 return {...state, tracibility: action.payload };
 case GET_MY_VOLUME_DATA:
 return {...state, volumes: action.payload };
 case GET_NEWS:
 return {...state, news: action.payload };
 case GET_DOWNLOADS:
 return {...state, downloads: action.payload };
default:
return state;

}
}