import React from 'react';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import ReduxThunk from 'redux-thunk';
import reducers from './reducers/index';
import RootNavigator from './components/header/RootNavigator'

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class App extends React.Component {
  render() {
    return (
      <div >
      <Provider store={createStore(reducers, {}, applyMiddleware(ReduxThunk))}>
        <RootNavigator/>
      </Provider>
      </div>
    );
  }
}