import React from 'react';

class Header extends React.Component {
  
  render() {
    return (
      <div className="row align-items-center my-5">
        <div className="col-md-4">
          <div className="custom-file">
            <label className="custom-file-upload" style={{ width: "50%" }}>
              <input type="file" style={{ display: "none" }} multiple onChange={this.props.onChangeHandler} />
              Add Files
            </label>
          </div>
        </div>
        <div className="col-md-2">
          <div className="dropdown">
            <button className="btn btn-outline-secondary dropdown-toggle"
              type="button" id="dropdownMenu1" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false" style={{ width: "100%" }} >
              File Type
            </button>
            <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
              <a className="dropdown-item" href="#!">Type 1</a>
              <a className="dropdown-item" href="#!">Type 2</a>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="dropdown">
            <button className="btn btn-outline-secondary dropdown-toggle"
              type="button" id="dropdownMenu1" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false" style={{ width: "100%" }}>
              Quarter
            </button>
            <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
              <a className="dropdown-item" href="#!">2020-Q1</a>
              <a className="dropdown-item" href="#!">2020-Q2</a>
              <a className="dropdown-item" href="#!">2020-Q3</a>
              <a className="dropdown-item" href="#!">2020-Q4</a>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="dropdown">
            <button className="btn btn-outline-secondary dropdown-toggle"
              type="button" id="dropdownMenu1" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false" style={{ width: "100%" }} >
              Date
            </button>
            <div className="dropdown-menu" aria-labelledby="dropdownMenu1">
              <a className="dropdown-item" href="#!">Lorem Ipsum</a>
              <a className="dropdown-item" href="#!">Lorem Ipsum</a>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <button type="button" className="btn btn-outline-secondary" style={{ width: "100%" }} onClick={this.props.onClickHandler}>Upload</button>
        </div>
      </div>
    )
  }
}

export default Header;