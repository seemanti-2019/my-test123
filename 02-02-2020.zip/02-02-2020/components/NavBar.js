import React from 'react';
import logo from '../images/Cargill_logo.svg';

class NavBar extends React.Component{
    render(){
        return (
            <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top nav-underline">
                <div className="container">
                    <a className="navbar-brand" href="/#">
                        <img className="navbar-brand logo" src={logo} alt="logo" />
                    </a>
                    <span className="navbar-heading-text">Palmwise Upload Portal</span>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon "></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarResponsive">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="/#">
                                    <i className="fa fa-user-circle" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        )
    }
}

export default NavBar;